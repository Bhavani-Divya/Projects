package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/runquery")
public class JIRAserviceDoQuery {

	@POST
	public Response getissues(@FormParam("query") String query, @Context HttpHeaders headers) {

		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.out.println(str);
			}
		}
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();
		System.out.println("Stat Time" + timestamp.getTime());
		WebResource webResource = client.resource("https://agilectb.atlassian.net/rest/api/2/search");
		String input = query;
		System.out.println("log " + input);
		ClientResponse response = webResource.header("Content-Type", "application/json")
				.header("Cookie",authStringEnc).post(ClientResponse.class, input);

		String output = response.getEntity(String.class);
		System.out.println("End Time" + timestamp.getTime());
		client.destroy();
		return Response.status(200).entity(output.toString()).header("Content-Type", "application/json").build();

	}
}
