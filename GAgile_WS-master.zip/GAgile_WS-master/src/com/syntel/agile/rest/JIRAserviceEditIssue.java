package com.syntel.agile.rest;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.FormParam;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/edit")
public class JIRAserviceEditIssue {

	@PUT

	@Path("/{pkey}")

	public Response createissue(@PathParam("pkey") String issueKey, @FormParam("lables") String lables,
			@FormParam("storypoints") String storypoints, @FormParam("acc_cr") String acceptanceCriteria,
			@FormParam("type") String issueType, @FormParam("summary") String summary,
			@FormParam("priority") String priority, @FormParam("description") String description,
			@FormParam("it_team") String itTeam, @FormParam("itKey") String itKey,
			@FormParam("assignee") String assignee, @FormParam("fixVersions") String fixVersions,
			@FormParam("reporter") String reporter, @Context HttpHeaders headers) {
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}

		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();
		if (itTeam == null) {
			String input = "{\"fields\": {\"customfield_10200\": " + storypoints + ",\"summary\": \"" + summary
					+ "\",	\"labels\": [\"" + lables + "\"],\"issuetype\": {\"id\": \"" + issueType
					+ "\"},\"priority\": {\"name\": \"" + priority + "\"}," + "	\"description\": \"" + description
					+ "\",\"customfield_10400\": \"" + acceptanceCriteria + "\", \"assignee\": {\"name\": \"" + assignee
					+ "\"},  \"fixVersions\": [{ \"id\": \"" + fixVersions + "\"}], \"reporter\": {\"name\": \""
					+ reporter + "\"} }} ";
			System.out.println("Input" + input);
			WebResource webResource = client.resource("https://agilectb.atlassian.net/rest/api/2/issue/" + issueKey);// issueKey=13044
			System.out.println("webResource" + webResource);
			ClientResponse response = webResource.header("Content-Type", "application/json")
					.header("Cookie",authStringEnc).put(ClientResponse.class, input);
			System.out.println("response" + response);
			client.destroy();
			return Response.status(200).entity(response.toString()).header("Content-Type", "application/json").build();
		} // if itTeam is not null, itTeam and itKey values are stored
		else {

			String input = "{\"fields\": {\"customfield_10200\": " + storypoints + ",\"summary\": \"" + summary
					+ "\",	\"labels\": [\"" + lables + "\"],\"issuetype\": {\"id\": \"" + issueType
					+ "\"},\"priority\": {\"name\": \"" + priority + "\"}," + "	\"description\": \"" + description
					+ "\",\"customfield_10400\": \"" + acceptanceCriteria + "\",\"" + itKey + "\": {\"id\": \"" + itTeam
					+ "\"}, \"assignee\": {\"name\": \"" + assignee + "\"},  \"fixVersions\": [{ \"id\": \""
					+ fixVersions + "\"}], \"reporter\": {\"name\": \"" + reporter + "\"} }} ";
			WebResource webResource = client.resource("https://agilectb.atlassian.net/rest/api/2/issue/" + issueKey);
			System.out.println("webResource" + webResource);
			ClientResponse response = webResource.header("Content-Type", "application/json")
					.header("Cookie",authStringEnc).put(ClientResponse.class, input);
			System.out.println("response" + response);
			client.destroy();
			return Response.status(200).entity(response.toString()).header("Content-Type", "application/json").build();
		}
	}
}
