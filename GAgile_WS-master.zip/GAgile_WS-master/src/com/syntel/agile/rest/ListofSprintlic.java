package com.syntel.agile.rest;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/listofsprintlic")

public class ListofSprintlic {

	@GET
	@Path("/{id}/{projectKey}")
	public Response getListofSprint(@PathParam("id") String boardId, @PathParam("projectKey") String projectKey,
			@Context HttpHeaders headers) {

		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {

			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
		}

		String authStringEnc = credentialMap.get("Cookie");

		Client client = Client.create();

		WebResource webResource = client.resource(
				"https://agilectb.atlassian.net/rest/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId="
						+ boardId + "&selectedProjectKey=" + projectKey + "");// boardId=15 and projectKey=AIEM
		ClientResponse response = webResource.header("Content-Type", "application/json")
				.header("Cookie",authStringEnc).get(ClientResponse.class);
		String responseString = response.getEntity(String.class);
		System.out.println("Response " + response);
		System.out.println("ResponseStr " + responseString);
		JSONObject objresponseString;
		objresponseString = new JSONObject(responseString);
		System.out.println(objresponseString);

		WebResource webResource1 = client.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/sprintquery/"
				+ boardId + "?includeHistoricSprints=false&includeFutureSprints=false");// boardId=15

		ClientResponse response1 = webResource1.header("Content-Type", "application/json")
				.header("Cookie",authStringEnc).get(ClientResponse.class);

		String responseString1 = response1.getEntity(String.class);
		System.out.println("Response " + response1);
		System.out.println("ResponseStr " + responseString1);
		JSONObject objresponseString1;
		objresponseString1 = new JSONObject(responseString1);
		System.out.println(objresponseString1);
		System.out.println("Output from Server .... \n" + objresponseString1);
		client.destroy();
		return Response.status(200).entity(objresponseString1.toString()).header("Content-Type", "application/json")
				.build();
	}

}
