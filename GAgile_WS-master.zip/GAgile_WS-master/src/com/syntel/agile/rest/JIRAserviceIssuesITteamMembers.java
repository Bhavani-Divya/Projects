package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/BoardITTeamMemberslic")

public class JIRAserviceIssuesITteamMembers {

	@GET
	@Path("/{projkey}")
	public Response getTotalStoryPointsIssues(@PathParam("projkey") String projectKey, @Context HttpHeaders headers) {

		headers.getRequestHeaders().keySet();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {

			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
		}
		ArrayList<JSONObject> listFinal = new ArrayList<>();
		JSONArray jsonarraySet = new JSONArray();
		String customkey = null;
		String authStringEnc = credentialMap.get("Cookie");
		System.out.println(authStringEnc);
		new Timestamp(System.currentTimeMillis());

		Client client = Client.create();
		WebResource webResource = client
				.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/rapidviews/viewsData?");

		ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc)
				.get(ClientResponse.class);
		String responseString = response.getEntity(String.class);
		JSONObject objResponseString = new JSONObject(responseString);
		JSONArray viewsArray = objResponseString.getJSONArray("views");
		System.out.println("1Outside For loop");
		for (int i = 0; i < viewsArray.length(); i++) {
			System.out.println("1Inside For loop");
			JSONObject viewsRow = (JSONObject) viewsArray.get(i);
			System.out.println("viewsRow" + viewsRow);
			boolean projFlag = (boolean) viewsRow.get("isSimpleQueryBoard");
			System.out.println("projFlag" + projFlag);
			JSONObject filterProj = (JSONObject) viewsRow.get("filter");
			System.out.println("filterProj" + filterProj);
			JSONObject objFilterProject = new JSONObject(filterProj);
			System.out.println(objFilterProject);
			JSONObject queryProject = (JSONObject) filterProj.get("queryProjects");
			System.out.println("queryProj" + queryProject);
			JSONArray projectArray = queryProject.getJSONArray("projects");
			System.out.println("projectArray" + projectArray);
			System.out.println("2outside For loop");

			for (int k = 0; k < projectArray.length(); k++) {
				JSONObject projectRow = (JSONObject) projectArray.get(k);
				String projectRowKey = (String) projectRow.get("key");
				System.out.println("2Inside For loop");
				System.out.println("projRowKeyFinal" + projectRowKey);
				System.out.println("projkeyFinal" + projectKey);
				if (projectRowKey.equals(projectKey) && projFlag == true) {

					System.out.println("Inside if loop");
					System.out.println("projRowKey is" + projectRowKey);
					System.out.println("Inside if loop");
					int boardId = viewsRow.getInt("id");
					System.out.println("id is" + boardId);
					System.out.println(projectKey);
					WebResource webResource2 = client.resource("https://agilectb.atlassian.net/rest/agile/latest/board/"
							+ boardId + "/issue?jql=Project=" + projectRowKey + "&startAt=0&maxResults=1");
					ClientResponse response2 = webResource2.header("Content-Type", "application/json")
							.header("Cookie", authStringEnc).get(ClientResponse.class);

					String responseString1 = response2.getEntity(String.class);
					JSONObject objResponseString1 = new JSONObject(responseString1);
					System.out.println("response :" + objResponseString1);
					JSONArray issueArray = objResponseString1.getJSONArray("issues");
					System.out.println("Befor IF loop  NO issue is present");
					if (issueArray == null || issueArray.length() == 0) {
						String error;
						error = "NO issue is present";
						JSONObject finalErrorResponse = new JSONObject();
						finalErrorResponse.put("Error", error);
						System.out.println("NO issue is present");

						return Response.status(200).entity(finalErrorResponse.toString())
								.header("Content-Type", "application/json").build();
					}
					String boardKey = null;
					for (int j = 0; j < issueArray.length(); j++) {
						JSONObject zerorow = (JSONObject) issueArray.get(j);
						boardKey = (String) zerorow.get("key");
					}

					WebResource webResource1 = client
							.resource("https://agilectb.atlassian.net/rest/api/2/issue/" + boardKey + "/editmeta");
					ClientResponse response1 = webResource1.header("Content-Type", "application/json")
							.header("Cookie", authStringEnc).get(ClientResponse.class);
					System.out.println("2nd webservice REsp" + response1.toString());
					System.out.println("response1" + response1);
					String responseString2 = response1.getEntity(String.class);
					JSONObject objResponseString2 = new JSONObject(responseString2);

					JSONObject objFields = objResponseString2.getJSONObject("fields");
					java.util.Iterator<String> iterator = objFields.keys();

					while (iterator.hasNext()) {
						String key = iterator.next();

						if (key.contains("customfield")) {
							JSONObject objKey = (JSONObject) objFields.get(key);
							jsonarraySet.put(key);
							String name = (String) objKey.get("name");
							if (name.contains("team") || name.contains("Team") && objKey.has("allowedValues")) {

								customkey = key;
								JSONArray objAllowedValues = (JSONArray) objKey.get("allowedValues");

								for (int l = 0; l < objAllowedValues.length(); l++) {
									JSONObject jsonvalue = new JSONObject();
									JSONObject objAllowedValuesRow = (JSONObject) objAllowedValues.get(l);
									String value = (String) objAllowedValuesRow.get("value");
									jsonvalue.put("name", value);
									String id = (String) objAllowedValuesRow.get("id");
									jsonvalue.put("id", id);
									listFinal.add(jsonvalue);
								}
								System.out.println(key);
							}
							System.out.println(objFields.get(key));
							System.out.println(listFinal);

						}

					}

					JSONObject objFinalList = new JSONObject();
					JSONObject finalResponse = new JSONObject();
					objFinalList.put("TeamName", listFinal);
					objFinalList.put("Customfield", customkey);
					finalResponse.put("ITTeam", objFinalList);
					return Response.status(200).entity(finalResponse.toString())
							.header("Content-Type", "application/json").build();

				}
			}
		}
		return null;

	}

}
