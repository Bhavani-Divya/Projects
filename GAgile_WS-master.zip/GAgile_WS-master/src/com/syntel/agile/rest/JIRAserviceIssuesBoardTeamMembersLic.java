package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/BoardTeamMemberslic")

public class JIRAserviceIssuesBoardTeamMembersLic {

	@GET
	@Path("/{projkey}")
	public Response getTotalStoryPointsIssues(@PathParam("projkey") int projkey, @Context HttpHeaders headers) {
		// public Response getissues(@Context HttpHeaders headers) {

		headers.getRequestHeaders().keySet();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {

			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		System.out.println(authStringEnc);
		ArrayList<JSONObject> finalResponselist = new ArrayList<>();
		// ArrayList<JSONObject> finalAvatarlist=new ArrayList<>();
		new Timestamp(System.currentTimeMillis());

		Client client = Client.create();
		System.out.println(projkey);
		WebResource webResource = client.resource("https://agilectb.atlassian.net/rest/agile/latest/board/" + projkey
				+ "/issue?jql=&startAt=0&maxResults=1");

		ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc)
				.get(ClientResponse.class);
		System.out.println("1st webservice REsp" + response);
		String respStr = response.getEntity(String.class);
		System.out.println("String Response" + respStr);
		JSONObject ob = new JSONObject(respStr);
		System.out.println("response :" + ob);
		JSONArray issuearray = ob.getJSONArray("issues");
		System.out.println("Befor IF loop  NO issue is present");
		if (issuearray == null || issuearray.length() == 0) {
			String error;
			error = "NO issue is present";
			JSONObject finalErrorResponse = new JSONObject();
			finalErrorResponse.put("Error", error);
			System.out.println("NO issue is present");

			return Response.status(200).entity(finalErrorResponse.toString()).header("Content-Type", "application/json")
					.build();
		}
		String boardKey = null;
		for (int i = 0; i < issuearray.length(); i++) {

			JSONObject zerorow = (JSONObject) issuearray.get(i);
			boardKey = (String) zerorow.get("key");

		}

		WebResource webResource1 = client
				// .resource("http://172.25.31.76:8081/rest/api/2/search?jql=project="+projectkey);
				.resource("https://agilectb.atlassian.net/rest/api/latest/user/assignable/search?issueKey=" + boardKey
						+ "&username=");
		// .resource("http://172.25.31.76:8081/rest/agile/latest/board/"+projkey+"/issue");
		// .resource("https://agilectb.atlassian.net/rest/api/2/myself");
		// System.out.println(webResource);

		// ClientResponse response1 = webResource1.header("Content-Type",
		// "application/json").header("Authorization", "Basic
		// Z3VuaW5kZXJfYmhhdGlhOnN5bnRlbDEyMyQ=").get(ClientResponse.class);
		ClientResponse response1 = webResource1.header("Content-Type", "application/json")
				.header("Cookie", authStringEnc).get(ClientResponse.class);
		System.out.println("2nd webservice REsp" + response1.toString());
		System.out.println("response1" + response1);
		String respStr1 = response1.getEntity(String.class);
		// JSONObject object = new JSONObject(respStr1);
		System.out.println("respStr1" + respStr1);
		int newresp = response1.getStatus();
		if (newresp == 404) {
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(respStr1);
			while (sc.hasNext()) {
				String line = sc.next();
				if (line.contains("Unauthorised user")) {
					return Response.status(200).entity("Unauthorised user").build();
				}
				break;
			}
		}

		String firstcar = respStr1.substring(0);
		String lastcar = respStr1.substring(respStr1.length() - 1);
		if (!"[".equals(firstcar) && !"]".equals(lastcar)) {

			respStr1 = "[" + respStr1 + "]";
		}
		JSONArray membersList = new JSONArray(respStr1);
		// JSONArray membersList = object.getJSONArray("respStr1");
		/*
		 * String responseBoard = responseBoardDetails.getEntity(String.class);
		 * JSONObject object = new JSONObject(responseBoard);
		 * 
		 * 
		 * for (int j = 0; j < issuearray.length(); j++) {
		 * 
		 * if (j == 0) { JSONObject zerorow = (JSONObject) issuearray.get(j); JSONObject
		 * newrzeroeportorfields = zerorow.getJSONObject("fields"); JSONObject
		 * newreportor = newrzeroeportorfields.getJSONObject("reporter"); AssignedSM =
		 * (String) newreportor.get("name"); }
		 */
		// System.out.println(respStr1);
		for (int j = 0; j < membersList.length(); j++) {
//			String emailStr = "atlassian.com";
			JSONObject row = (JSONObject) membersList.get(j);
			JSONObject avatar = (JSONObject) row.get("avatarUrls");
			String avatarUrl = (String) avatar.get("24x24");
			String displayName = (String) row.get("displayName");
//			String emailAddr = (String) row.get("emailAddress");
//			int len = emailAddr.length();
//			String emailSubStr = emailAddr.substring(emailAddr.length() - 13);
//			System.out.println(emailSubStr);
//			if (!emailStr.equals(emailSubStr)) {
			JSONObject finalResponse = new JSONObject();

			/*
			 * finalAvatarlist.(displayName); finalAvatarlist.add(avatarUrl);
			 */
			finalResponse.put("TeamMembers", displayName);
			finalResponse.put("Avatar", avatarUrl);

			finalResponselist.add(finalResponse);
//			}

		}

		return Response.status(200).entity(finalResponselist.toString()).header("Content-Type", "application/json")
				.build();

	}

}
