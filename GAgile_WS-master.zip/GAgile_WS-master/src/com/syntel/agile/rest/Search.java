package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

//import org.apache.log4j.Logger; //na
import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/search")
public class Search {

	
	@GET
	@Path("/{key}/{value}")
	public Response getSearch(@PathParam("key") String key,@PathParam("value") String value) {
	Client client = Client.create();
	 
	WebResource webResource = client
			//.resource("http://172.25.43.200:8081/rest/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId="+ id +"&selectedProjectKey="+ projectKey +""); 
			  .resource("https://agilectb.atlassian.net/rest/api/2/search?jql="+key+"="+value+""); //AIEM //15
	
	ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", "Basic R3Vlc3Q6c3ludGVsMTIzJA==").get(ClientResponse.class); //Z3VuaW5kZXJfYmhhdGlhQHN5bnRlbGluYy5jb206c3ludGVsMTIzJA==
 	 
	String respStr = response.getEntity(String.class);
	System.out.println("Response " + response);
	System.out.println("ResponseStr " + respStr);
	JSONObject ob;
	ob = new JSONObject(respStr);
	System.out.println(ob);
	
	/*JSONObject finalResponse = new JSONObject();
	finalResponse.put("Search Response",ob);*/
	//String output = response.getEntity(String.class);
	 
	//System.out.println("Output from Server .... \n" + finalResponse);
	System.out.println("Output from Server .... \n" + ob);
	client.destroy();
	//return Response.status(200).entity(output.toString()).header("Content-Type", "application/text").build();
	//return Response.status(200).entity(finalResponse.toString()).build();
	return Response.status(200).entity(ob.toString()).build();
	 
	}
	
}
