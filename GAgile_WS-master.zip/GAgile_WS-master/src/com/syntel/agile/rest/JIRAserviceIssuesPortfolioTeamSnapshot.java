package com.syntel.agile.rest;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

//import org.apache.log4j.Logger; //1
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

//import org.apache.log4j.PropertyConfigurator; //2
//import com.sun.istack.logging.Logger;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/getportfoliotable")

public class JIRAserviceIssuesPortfolioTeamSnapshot {
	String errorMsg;

	@GET
	@Path("/{projkey}")
	public Response getTotalStoryPointsIssues(@PathParam("projkey") String projectKey, @Context HttpHeaders headers)
			throws JSONException, ParseException {

		String assignedName = null;
		String displayName = null;

		List<JSONObject> finalResponselist = new ArrayList<>();
		Set<String> finalResponseset = new TreeSet<String>();
		headers.getRequestHeaders().keySet();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {

			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();

		WebResource webResource = client

				.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/rapidviews/viewsData?");

		ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc)
				.get(ClientResponse.class);
		System.out.println("Before Log$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		System.out.println("After Log$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		String respStr = response.getEntity(String.class);
		JSONObject ob = new JSONObject(respStr);
		JSONArray viewsArray = ob.getJSONArray("views");

		System.out.println("1Outside For loop");
		for (int i = 0; i < viewsArray.length(); i++) {
			System.out.println("1Inside For loop");
			JSONObject viewsRow = (JSONObject) viewsArray.get(i);
			System.out.println("viewsRow" + viewsRow);

			boolean projectFlag = (boolean) viewsRow.get("isSimpleQueryBoard");
			String boardName = (String) viewsRow.get("name");

			System.out.println("projFlag" + projectFlag);
			JSONObject filterProj = (JSONObject) viewsRow.get("filter");
			System.out.println("filterProj" + filterProj);
			JSONObject obb = new JSONObject(filterProj);
			System.out.println(obb);
			JSONObject queryProject = (JSONObject) filterProj.get("queryProjects");
			System.out.println("queryProj" + queryProject);
			JSONArray projectArray = queryProject.getJSONArray("projects");
			System.out.println("projectArray" + projectArray);
			System.out.println("2outside For loop");

			for (int k = 0; k < projectArray.length(); k++) {

				JSONObject projectRow = (JSONObject) projectArray.get(k);

				String projectRowKey = (String) projectRow.get("key");
				System.out.println("2Inside For loop");
				System.out.println("K is:  " + k);
				System.out.println("projRowKeyFinal" + projectRowKey);
				System.out.println("projkeyFinal" + projectKey);

				if (projectRowKey.equals(projectKey)) {

					String teamName = boardName;
					System.out.println("Inside if loop");
					System.out.println("projRowKey is" + projectRowKey);
					System.out.println("Inside if loop");
					int boardId = viewsRow.getInt("id");
					System.out.println("id is" + boardId);

					WebResource webResourceBoardDetails = client

							.resource("https://agilectb.atlassian.net/rest/agile/1.0/board/" + boardId
									+ "/issue?jql=Project=" + projectRowKey + "&startAt=0&maxResults=1");// boardId=81
					ClientResponse responseBoardDetails = webResourceBoardDetails
							.header("Content-Type", "application/json").header("Cookie", authStringEnc)
							.get(ClientResponse.class);

					String responseBoard = responseBoardDetails.getEntity(String.class);
					JSONObject object = new JSONObject(responseBoard);
					JSONArray issuearray = object.getJSONArray("issues");

					for (int j = 0; j < issuearray.length(); j++) {

						JSONObject zeroRow = (JSONObject) issuearray.get(j);
						JSONObject newrZeroreporterFields = zeroRow.getJSONObject("fields");
						JSONObject newReporter = newrZeroreporterFields.getJSONObject("reporter");
						assignedName = (String) newReporter.get("name");
						displayName = (String) newReporter.get("displayName");
					}

					JSONObject finalResponse = new JSONObject();
					finalResponse.put("teamName", teamName);
					finalResponse.put("boardRapidid", boardId);
					System.out.println("teamname" + teamName);
					finalResponse.put("AssignedSM", assignedName);
					finalResponse.put("displayName", displayName);
					finalResponse.put("projkey", projectKey);
					System.out.println("AssignedSM" + assignedName + ", DisplayName" + displayName);
					finalResponse.put("Location", finalResponseset);
					System.out.println();
					finalResponselist.add(finalResponse);
				}

				System.out.println(
						"2 No boards are present***********************************************************************");
			}
			System.out.println(
					"3 No boards are present***********************************************************************");
		}
		return Response.status(200).entity(finalResponselist.toString()).header("Content-Type", "application/json")
				.build();

	}

}
