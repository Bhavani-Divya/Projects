package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Scanner;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

class BugsIdVal {
	String bugid;
	String description;	
	String assignedto;
	Double estimatedtime;
	
	String openedsince;
	String releaseversion;
	
	String priorityname;
	String statusname;
	String statuscolor;
	
	//bud id,description,opened since,assigned to ,estimated time 
	
	public BugsIdVal(String bugid, String description, Double estimatedtime, String openedsince, 	String assignedto, String releaseversion,String priorityname,String statusname,String statuscolor) {  //,String key //, 	Integer estimatedtime
		super();
		this.bugid = bugid;
		this.description = description;
		this.openedsince = openedsince;
		this.assignedto = assignedto;
		this.releaseversion = releaseversion;
		this.priorityname = priorityname;
		this.statusname = statusname;
		this.statuscolor = statuscolor;
		this.estimatedtime = estimatedtime;
			
	}

	public void setBugid(String bugid) {
		this.bugid = bugid;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public void setopenedsince(String openedsince) {
		this.openedsince = openedsince;
	}
	
	public void setAssignedto(String assignedto) {
		this.assignedto = assignedto;
	}
	
	public void setReleaseversion(String releaseversion) {
		this.releaseversion = releaseversion;
	}
	
	public void setPriorityname(String priorityname) {
		this.priorityname = priorityname;
	}
	
	public void setStatusname(String statusname) {
		this.statusname = statusname;
	}
	public void setStatuskey(String statuscolor) {
		this.statuscolor  = statuscolor;
	}
	//String priorityname
	public void setEstimatedtime(Double estimatedtime) {
		this.estimatedtime = estimatedtime;
	}
		
	public String toString() {
        return "BugDetails [bugid=" + bugid + ", description=" + description + ", openedsince=" + openedsince + ", assignedto=" + assignedto + ", releaseversion=" +releaseversion+ ", priorityname=" +priorityname+ " ,statusname=" +statusname+ " ,statuscolor=" +statuscolor+",estimatedtime=" + estimatedtime + "]"; //, estimatedtime=" + estimatedtime + "
    }
	
	void display() {
		System.out.println( bugid + " " + description + "" + openedsince + "" + assignedto + "" + releaseversion + " " + priorityname + " " + statusname + " " + statuscolor + " " +estimatedtime);  //+ " " + key // + "" + estimatedtime
	}
}


@Path("/getBugIdDetail")

public class BugId {
	
	@GET
	@Path("/{id}/{projectKey}")
	public Response getActiveBugsandImpediments(@PathParam("id") String id,@PathParam("projectKey") String projectKey,@Context HttpHeaders headers) throws JSONException {
	 Set<String> headerKeys = headers.getRequestHeaders().keySet();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.err.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		
	Client client = Client.create();
	 
	WebResource webResource = client
								.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId="+ id +"&selectedProjectKey="+ projectKey +""); //AIEM //15
	ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc).get(ClientResponse.class);

	

	List<BugsIdVal> BugsIdVal1 = new LinkedList<BugsIdVal>();
	int listsize = 0;
	GsonBuilder gsonBuilder = new GsonBuilder();
    Gson gson = gsonBuilder.create();
    String Errormsg ="There are no bugs" ;
	
	String bugid = null;String description = null; 
	String openedsince = null; String releaseversion = null;
	String priorityname = null; double estimatedtime = 0;String assignedto = null;
	String statusname = null; String statuscolor = null;Integer pid = 0;
	String pid2 = null;  Integer idvalue =0; //String name = null;
	
	
	JSONObject finalResponse = new JSONObject();
	double bugs = 0;
	double impediment = 0;
	String respStr = response.getEntity(String.class);
	System.out.println("Response " + response);
	System.out.println("ResponseStr " + respStr);
	JSONObject ob;
	ob = new JSONObject(respStr);
	System.out.println(ob);
	
	JSONArray issues = (JSONArray) ob.get("issues");
	
	
	
	/*JSONArray projects = (JSONArray) ob.get("projects");
	for(int p=0;p<projects.length();p++){
		JSONObject projectvalue = (JSONObject) projects.get(p);
		 pid =(Integer) projectvalue.get("id") ;
		 pid2= Integer.toString(pid);
	}*/ 
	
	for(int k=0;k<issues.length();k++){
	JSONObject value = (JSONObject) issues.get(k);
	Integer projectId = (Integer) value.get("projectId") ; //Integer  String
	String projectIds = String.valueOf(projectId) ;
	JSONObject versionData = (JSONObject) ob.get("versionData");
	JSONObject versionsPerProject = (JSONObject) versionData.get("versionsPerProject");
	JSONArray idval =(JSONArray) versionsPerProject.get(projectIds) ;
	
	for(int p=0;p<idval.length();p++){
		JSONObject projectvalue = (JSONObject) idval.get(p);
		 idvalue = (Integer) projectvalue.get("id");
		
		 
		 JSONArray fixVersions = (JSONArray) value.get("fixVersions");
			String fixversionval =  String.valueOf(fixVersions) ;//fixVersions.toString();
			System.out.println("fixversionval"+fixversionval);
			String Val = (String) fixversionval;
			System.out.println("Val:"+Val);
	        String v1 = Val.replace("[","");
	        System.out.println("v1:"+v1);
	        String v2 = v1.replace("]","");
	        System.out.println("v2:"+v2);
	        if(v2!=""){
	        	
	        	int fixversionvalint = Integer.parseInt(v2);
	        	if(fixversionvalint==idvalue){
					releaseversion = (String) projectvalue.get("name");
				}
	        }
	        else{
	        	releaseversion = null;
	        }
			
			
	}
	
	HashMap<String, String> bugss = new HashMap<String, String>();
	String typeName = (String) value.get("typeName");
	System.out.println(typeName);
	Boolean done = (Boolean) value.get("done");
	System.out.println(done);
	if((typeName.equals("Bug")) &&  (done.equals(false))){
	bugs++;
	bugid =(String) value.get("key");
	description =(String) value.get("summary"); //
	assignedto = (String) value.get("assigneeName");
	JSONObject estimateStatistic = (JSONObject) value.get("estimateStatistic"); 
	JSONObject statFieldValue = (JSONObject) estimateStatistic.get("statFieldValue");
	estimatedtime = (Double) statFieldValue.get("value");
	
	openedsince = ""; //"" null
	priorityname = (String) value.get("priorityName"); 
	statusname = (String) value.get("statusName");
	JSONObject status = (JSONObject) value.get("status");
	JSONObject statusCategory = (JSONObject) status.get("statusCategory");
	statuscolor = (String) statusCategory.get("colorName") ;
	
	/*JSONArray fixVersions = (JSONArray) value.get("fixVersions");
	String fixversionval =  String.valueOf(fixVersions) ;//fixVersions.toString();
	System.out.println("fixversionval"+fixversionval);
	int fixversionvalint = Integer.parseInt(fixversionval);
	
	if(fixversionvalint==idvalue){
		
	}*/
	
	BugsIdVal BugsIdVal2 = new BugsIdVal(bugid, description, estimatedtime,  openedsince,  assignedto,releaseversion,priorityname,statusname,statuscolor); //,  estimatedtime
	BugsIdVal1.add(BugsIdVal2);
    System.out.println("JSON Object List "+gson.toJson(BugsIdVal1)); //BugsIdVal1
    listsize = BugsIdVal1.size();
	
	
	}
	/*if((typeName.equals("Impediment")) &&  (done.equals(false)))
		impediment++;*/
	 
	}
 
	if(listsize!=0){
		
		System.out.println("Output from Server .... \n" + BugsIdVal1);
		client.destroy();
		return Response.status(200).entity(gson.toJson(BugsIdVal1).toString()).header("Content-Type", "application/json").build();
	}
	else{
		finalResponse = new JSONObject();
		finalResponse.put("Error msg",Errormsg);
		System.out.println("There are no bugs");
		client.destroy();
		return Response.status(200).entity(finalResponse.toString()).header("Content-Type", "application/json").build();
	
	}

	}

}
