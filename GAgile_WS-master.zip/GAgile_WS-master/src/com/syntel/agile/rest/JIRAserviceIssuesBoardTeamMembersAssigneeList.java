package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/getBoardTeamMembersassignee")

public class JIRAserviceIssuesBoardTeamMembersAssigneeList {

	@GET
	@Path("/{projkey}")
	public Response getTotalStoryPointsIssues(@PathParam("projkey") String projectKey, @Context HttpHeaders headers) {
		headers.getRequestHeaders().keySet();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {

			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		System.out.println(authStringEnc);
		ArrayList<JSONObject> finalResponselist = new ArrayList<>();
		new Timestamp(System.currentTimeMillis());

		Client client = Client.create();
		System.out.println(projectKey);

		WebResource webResource = client
				.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/rapidviews/viewsData?");

		ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc)
				.get(ClientResponse.class);
		String responseString = response.getEntity(String.class);
		JSONObject ob = new JSONObject(responseString);
		JSONArray viewsArray = ob.getJSONArray("views");
		System.out.println("1Outside For loop");
		for (int i = 0; i < viewsArray.length(); i++) {
			System.out.println("1Inside For loop");
			JSONObject viewsRow = (JSONObject) viewsArray.get(i);
			System.out.println("viewsRow" + viewsRow);
			// boolean projFlag=(boolean) viewsRow.get("isSimpleQueryBoard");
			boolean projFlag = (boolean) viewsRow.get("isSimpleQueryBoard");
			String boardName = (String) viewsRow.get("name");

			System.out.println("projFlag" + projFlag);
			JSONObject filterProj = (JSONObject) viewsRow.get("filter");
			System.out.println("filterProj" + filterProj);
			JSONObject obb = new JSONObject(filterProj);
			System.out.println(obb);
			JSONObject queryProj = (JSONObject) filterProj.get("queryProjects");
			System.out.println("queryProj" + queryProj);
			JSONArray projectArray = queryProj.getJSONArray("projects");
			System.out.println("projectArray" + projectArray);
			System.out.println("2outside For loop");

			for (int k = 0; k < projectArray.length(); k++) {
				// JSONObject projRow = (JSONObject) projectArray.get(k);
				JSONObject projRow = (JSONObject) projectArray.get(k);
				// JSONObject projRow = (JSONObject) projectArray.get(index);
				String projRowKey = (String) projRow.get("key");
				System.out.println("2Inside For loop");
				System.out.println("projRowKeyFinal" + projRowKey);
				System.out.println("projkeyFinal" + projectKey);
				if (projRowKey.equals(projectKey) && projFlag == true) {

					System.out.println("Inside if loop");
					System.out.println("projRowKey is" + projRowKey);
					System.out.println("Inside if loop");
					int iid = viewsRow.getInt("id");
					System.out.println("id is" + iid);

					WebResource webResource2 = client.resource("https://agilectb.atlassian.net/rest/agile/latest/board/"
							+ iid + "/issue?jql=Project=" + projRowKey + "&startAt=0&maxResults=1");
					ClientResponse response2 = webResource2.header("Content-Type", "application/json")
							.header("Cookie", authStringEnc).get(ClientResponse.class);
					System.out.println("1st webservice REsp" + response);
					String responseString2 = response2.getEntity(String.class);
					System.out.println("String Response" + responseString);
					JSONObject ob1 = new JSONObject(responseString2);
					System.out.println("response :" + ob);
					JSONArray issuearray = ob1.getJSONArray("issues");
					System.out.println("Befor IF loop  NO issue is present");
					if (issuearray == null || issuearray.length() == 0) {
						String error;
						error = "NO issue is present";
						JSONObject finalErrorResponse = new JSONObject();
						finalErrorResponse.put("Error", error);
						System.out.println("NO issue is present");

						return Response.status(200).entity(finalErrorResponse.toString())
								.header("Content-Type", "application/json").build();
					}
					String boardKey = null;
					for (int l = 0; l < issuearray.length(); l++) {

						JSONObject zerorow = (JSONObject) issuearray.get(l);
						boardKey = (String) zerorow.get("key");

					}

					WebResource webResource1 = client
							.resource("https://agilectb.atlassian.net/rest/api/latest/user/assignable/search?issueKey="
									+ boardKey + "&username=");
					ClientResponse response1 = webResource1.header("Content-Type", "application/json")
							.header("Cookie", authStringEnc).get(ClientResponse.class);
					System.out.println("2nd webservice REsp" + response1.toString());
					System.out.println("response1" + response1);
					String responseString1 = response1.getEntity(String.class);
					System.out.println("respStr1" + responseString1);
					int newresp = response1.getStatus();
					if (newresp == 404) {
						@SuppressWarnings("resource")
						Scanner sc = new Scanner(responseString1);
						while (sc.hasNext()) {
							String line = sc.next();
							if (line.contains("Unauthorised user")) {
								return Response.status(200).entity("Unauthorised user").build();
							}
							break;
						}
					}

					String firstcar = responseString1.substring(0);
					String lastcar = responseString1.substring(responseString1.length() - 1);
					if (!"[".equals(firstcar) && !"]".equals(lastcar)) {

						responseString1 = "[" + responseString1 + "]";
					}
					JSONArray membersList = new JSONArray(responseString1);
					for (int j = 0; j < membersList.length(); j++) {
//						String emailStr = "atlassian.com";
						JSONObject row = (JSONObject) membersList.get(j);
						String userName = (String) row.get("name");
						String displayName = (String) row.get("displayName");
//						String emailAddr = (String) row.get("emailAddress");
//
//						String emailSubStr = emailAddr.substring(emailAddr.length() - 13);
//						System.out.println(emailSubStr);
//						if (!emailStr.equals(emailSubStr)) {
						JSONObject finalResponse = new JSONObject();

						finalResponse.put("userNames", userName);
						finalResponse.put("displayNames", displayName);
						finalResponselist.add(finalResponse);
//						}

					}

					JSONObject jsonResult = new JSONObject();
					jsonResult.put("assigneeList", finalResponselist);

				}
			}
		}
		return Response.status(200).entity(finalResponselist.toString()).header("Content-Type", "application/json")
				.build();

	}
}
