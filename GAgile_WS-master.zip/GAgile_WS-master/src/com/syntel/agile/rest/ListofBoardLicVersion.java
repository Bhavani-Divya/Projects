package com.syntel.agile.rest;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/listofBoardLicVersion")

public class ListofBoardLicVersion {

	@GET
	@Path("/{projkey}")
	public Response getListofBoardLicVersion(@PathParam("projkey") String projectKey, @Context HttpHeaders headers)
			throws JSONException, ParseException {

		List<JSONObject> finalResponselist = new ArrayList<>();
		JSONObject jsonfinalres = new JSONObject();

		headers.getRequestHeaders().keySet();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {

			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
		}

		String authStringEnc = credentialMap.get("Cookie");

		Client client = Client.create();
		WebResource webResource = client
				.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/rapidviews/viewsData?");
		ClientResponse response = webResource.header("Content-Type", "application/json")
				.header("Cookie",authStringEnc).get(ClientResponse.class);

		String respStr = response.getEntity(String.class);
		JSONObject ob = new JSONObject(respStr);
		JSONArray viewsArray = ob.getJSONArray("views");

		System.out.println("1Outside For loop");
		for (int i = 0; i < viewsArray.length(); i++) {
			System.out.println("1Inside For loop");
			JSONObject viewsRow = (JSONObject) viewsArray.get(i);
			System.out.println("viewsRow" + viewsRow);

			boolean projFlag = (boolean) viewsRow.get("isSimpleQueryBoard");
			String boardName = (String) viewsRow.get("name");

			System.out.println("projFlag" + projFlag);
			JSONObject filterProj = (JSONObject) viewsRow.get("filter");
			System.out.println("filterProj" + filterProj);
			JSONObject obb = new JSONObject(filterProj);
			System.out.println(obb);
			JSONObject queryProj = (JSONObject) filterProj.get("queryProjects");
			System.out.println("queryProj" + queryProj);
			JSONArray projectArray = (JSONArray) queryProj.getJSONArray("projects");
			System.out.println("projectArray" + projectArray);
			System.out.println("2outside For loop");

			for (int k = 0; k < projectArray.length(); k++) {

				JSONObject projRow = (JSONObject) projectArray.get(k);
				String projRowKey = (String) projRow.get("key");
				System.out.println("2Inside For loop");
				System.out.println("projRowKeyFinal" + projRowKey);
				System.out.println("projkeyFinal" + projectKey);
				if (projRowKey.equals(projectKey)) {

					String teamname = boardName;
					System.out.println("Inside if loop");
					System.out.println("projRowKey is" + projRowKey);
					System.out.println("Inside if loop");
					int boardId = viewsRow.getInt("id");
					System.out.println("id is" + boardId);

					JSONObject finalResponse = new JSONObject();

					finalResponse.put("name", teamname);
					finalResponse.put("id", boardId);
					System.out.println("name" + teamname);
					System.out.println("id" + boardId);
					finalResponselist.add(finalResponse);
					jsonfinalres.put("values", finalResponselist);
					System.out.println("jsonfinalres" + jsonfinalres);

				}

			}

		}

		return Response.status(200).entity(jsonfinalres.toString()).header("Content-Type", "application/json").build();

	}

}
