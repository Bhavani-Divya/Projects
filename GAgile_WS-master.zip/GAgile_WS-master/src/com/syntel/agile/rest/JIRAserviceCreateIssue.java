package com.syntel.agile.rest;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/create")
public class JIRAserviceCreateIssue {

	@POST

	@Path("/{pkey}")

	public Response createissue(@PathParam("pkey") String issueKey, @FormParam("summary") String summary,
			@FormParam("descr") String description, @FormParam("type") String issueType,
			@FormParam("acc_cr") String acceptanceCriteria, @FormParam("it_team") String itTeam,
			@FormParam("itKey") String itKey, @FormParam("assignee") String assignee,
			@FormParam("fixVersions") String fixVersions, @FormParam("reporter") String reporter,
			@Context HttpHeaders headers) {
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.out.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();

		System.out.println(
				"  " + issueKey + "  " + summary + "  " + description + "  " + issueType + "   " + acceptanceCriteria);
		if (itTeam == null) {

			String input = "{\"fields\": {   \"project\":   {       \"key\": \"" + issueKey
					+ "\"   },  \"issuetype\": {      \"name\": \"" + issueType + "\"   } ,  \"summary\": \"" + summary
					+ "\",   \"description\": \"" + description + "\" , \"customfield_10400\": \"" + acceptanceCriteria
					+ "\" , \"assignee\": {\"name\": \"" + assignee + "\"},  \"fixVersions\": [{ \"id\": \""
					+ fixVersions + "\"}], \"reporter\": {\"name\": \"" + reporter + "\"} }} ";
			WebResource webResource = client.resource("https://agilectb.atlassian.net/rest/api/2/issue");
			ClientResponse response = webResource.header("Content-Type", "application/json")
					.header("Cookie",authStringEnc).post(ClientResponse.class, input);
			String output = response.getEntity(String.class);
			System.out.println("Output from Server .... \n" + output);
			client.destroy();
			return Response.status(200).entity(output.toString()).header("Content-Type", "application/json").build();
		} // if itTeam is not null, itTeam and itKey values are stored
		else {

			String input = "{\"fields\": {   \"project\":   {       \"key\": \"" + issueKey
					+ "\"   },  \"issuetype\": {      \"name\": \"" + issueType + "\"   } ,  \"summary\": \"" + summary
					+ "\",   \"description\": \"" + description + "\" , \"customfield_10400\": \"" + acceptanceCriteria
					+ "\" ,    \"" + itKey + "\": {\"id\": \"" + itTeam + "\"}, \"assignee\": {\"name\": \"" + assignee
					+ "\"},  \"fixVersions\": [{ \"id\": \"" + fixVersions + "\"}], \"reporter\": {\"name\": \""
					+ reporter + "\"} }} ";

			WebResource webResource = client.resource("https://agilectb.atlassian.net/rest/api/2/issue");
			ClientResponse response = webResource.header("Content-Type", "application/json")
					.header("Cookie",authStringEnc).post(ClientResponse.class, input);

			String output = response.getEntity(String.class);

			System.out.println("Output from Server .... \n" + output);
			client.destroy();
			return Response.status(200).entity(output.toString()).header("Content-Type", "application/json").build();
		}

	}
}
