package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/versionlistdetails")

public class VersionListDetails {

	@GET
	@Path("/{id}/{projectKey}")
	public Response getProjectVersionList(@PathParam("id") String boardId, @PathParam("projectKey") String projectKey,
			@Context HttpHeaders headers) {

		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.err.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");

		Client client = Client.create();
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		System.out.println(timestamp.getTime());

		WebResource webResource = client.resource(
				"https://agilectb.atlassian.net/rest/api/2/project/" + projectKey + "?_=" + timestamp.getTime());
		ClientResponse response = webResource.header("Content-Type", "application/json")
				.header("Cookie",authStringEnc).get(ClientResponse.class);

		String output = response.getEntity(String.class);
		System.out.println("Output from Server .... \n" + output);
		client.destroy();
		return Response.status(200).entity(output.toString()).header("Content-Type", "application/json").build();

	}

}
