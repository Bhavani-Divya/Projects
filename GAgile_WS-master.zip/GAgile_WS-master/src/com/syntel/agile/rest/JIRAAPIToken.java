package com.syntel.agile.rest;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/token")

public class JIRAAPIToken {
	@GET
	public Response getapitoken(@Context HttpHeaders headers) {
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.out.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();
		WebResource webResource = client.resource(
				"https://agilectb.atlassian.net/rest/api/latest/serverInfo?jwt=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJxc2giOiIzN2Y3N2ViZWZlZmYwNmM4YzUyNmE2ZDY0M2ViZjQ3OGNjYzEwNjJjMDEwMTIxNjc3ODRlNmZiNGI5ODZmYTM3IiwiaXNzIjoiYXRsYXNzaWFuLWNvbm5lY3QtYWRkb24iLCJleHAiOjE1NjMxOTAzNzcsImlhdCI6MTU2MzE5MDE5N30.4fqiXM3SXa6u1BuconwLg-Sew-HbuMOhwTj2C_RoaUE");
		ClientResponse response = webResource.header("Content-Type", "application/json")
				.header("Cookie",authStringEnc).get(ClientResponse.class);
		String responseString = response.getEntity(String.class);
		return Response.status(200).entity(responseString.toString()).header("Content-Type", "application/json")
				.build();
		}
	}
