package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

//import org.apache.log4j.Logger; //na
import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/searchdetails")

public class searchdetails {

	@GET
	@Path("/{key}/{operator}/{value}")
	public Response getSearch(@PathParam("key") String key,@PathParam("value") String value,@PathParam("operator") String operator,@Context HttpHeaders headers) {
	
		 Set<String> headerKeys = headers.getRequestHeaders().keySet();
			Map<String, String> credentialMap = new LinkedHashMap<String, String>();
			for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
				System.out.println("Key" + entry.getKey());
				if (entry.getKey().equals("cookie")) {
					credentialMap.put("Cookie", entry.getValue().get(0));
				}
				for (String str : entry.getValue()) {
					System.err.println(str);
				}
			}

			String authStringEnc = credentialMap.get("Cookie");
	
		
	Client client = Client.create();
	 
	WebResource webResource = client
			//.resource("http://172.25.43.200:8081/rest/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId="+ id +"&selectedProjectKey="+ projectKey +""); 
			  .resource("https://agilectb.atlassian.net/rest/api/2/search?jql="+key+""+operator+""+value+""); //AIEM //15
	
	ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc).get(ClientResponse.class); //Z3VuaW5kZXJfYmhhdGlhQHN5bnRlbGluYy5jb206c3ludGVsMTIzJA==
	//"Authorization", "Basic R3Vlc3Q6c3ludGVsMTIzJA=="
	
	
	String respStr = response.getEntity(String.class);
	System.out.println("Response " + response);
	System.out.println("ResponseStr " + respStr);
	
	String keyval1 = "issuetype", keyval2 = "issuekey";
	
	JSONObject ob;
	ob = new JSONObject(respStr);
	System.out.println(ob);	
	int a = ob.length();
	int len = 0;
	
	if(a!=2){
		
	JSONArray issues = (JSONArray) ob.get("issues"); 
	len = issues.length();
	int len2 = 0;
	
	for(int k=0;k<issues.length();k++){
		JSONObject isuesvalue = (JSONObject) issues.get(k);
		len2 = issues.length();
	}
	
	JSONObject finalResponse = new JSONObject();
	if(len!=0){
		finalResponse.put("total count",len);
		finalResponse.put("Search details",ob);
	}
	else{
		String textvalue = "No issues were found to match your search";
		finalResponse.put("warningMessages",textvalue);
	}

	System.out.println("Output from Server .... \n" + ob);
	client.destroy();
	return Response.status(200).entity(finalResponse.toString()).header("Content-Type", "application/json").build();
	
	//{"errorMessages":["The value 'AgileOnGO' does not exist for the field 'issuetype'."],"warningMessages":[]}
	}else{
		JSONObject finalResponse = new JSONObject();
		
		//String errorMessages = "An issue with key '" +value+ "' does not exist";
		
		String errorMessages =null; //[\"The value '"+value+"\'does not exist for the field '"+key+" '.]
			
		if(key==keyval1){
			errorMessages ="An issue with key '" +value+ "' does not exist";
			System.out.println("err msg:"+errorMessages);
			//finalResponse.put("errorMessages",errorMessages);
		}
		
		if(key==keyval2){
			errorMessages ="The value '" +value+ "' does not exist";
			//finalResponse.put("errorMessages",errorMessages);
			System.out.println("err msg:"+errorMessages);
		}
		
		String warningMessages = "No issues were found to match your search"; // []
		finalResponse.put("errorMessages",errorMessages);
		finalResponse.put("warningMessages",warningMessages);
		System.out.println("Output from Server .... \n" + ob); //finalResponse
		client.destroy();
		return Response.status(200).entity(ob.toString()).header("Content-Type", "application/json").build();
		
	}
	}
	
	
}
