package com.syntel.agile.rest;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

class WbdcDetail {
	int overalltimespent;
	String name;

	public WbdcDetail(int overalltimespent, String name) {
		super();
		this.name = name;
		this.overalltimespent = overalltimespent;

	}

	public void setYt(String name) {
		this.name = name;
	}

	public void setOveralltimespent(int overalltimespent) {
		this.overalltimespent = overalltimespent;
	}

	public String toString() {
		return "WbdcDetails [assigneename=" + name + ", overalltimespent=" + overalltimespent + "]";
	}

	void display() {
		System.out.println(+overalltimespent + " " + name);
	}
}

@Path("/wbdcslics")

public class WbdcsLics {

	@GET
	@Path("/{id}/{projectKey}")
	public Response getWbdcTrial(@PathParam("id") Integer rapidViewId, @PathParam("projectKey") String projectKey,
			@Context HttpHeaders headers) throws JSONException, ParseException {

		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {

			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
		}

		String authStringEnc = credentialMap.get("Cookie");

		Client client = Client.create();
		try {
			WebResource webResource = client.resource(
					"https://agilectb.atlassian.net/rest/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId="
							+ rapidViewId + "&selectedProjectKey=" + projectKey + "");// rapidViewId=15 &
																						// projectkey=AIEM

			ClientResponse response = webResource.header("Content-Type", "application/json")
					.header("Cookie",authStringEnc).get(ClientResponse.class);

			String responseString = response.getEntity(String.class);
			System.out.println("Response " + response);
			System.out.println("ResponseStr " + responseString);
			Integer id = 0;// id inside the filter
			Integer boardId = 0;
			String stringEmpty = null;

			int t;
			String[] assignee = new String[10];
			int n;
			Double[] hr = new Double[10];
			ArrayList<String> nameList = new ArrayList<String>();
			ArrayList<Double> hoursList = new ArrayList<Double>();
			int overalltimespent, timeSpentWeek, timeSpentDay, timeSpentHours;

			List<WbdcDetail> wbdcDetailsList = new LinkedList<WbdcDetail>(); // WbdcDetails
			int listsize = 0;
			GsonBuilder gsonBuilder = new GsonBuilder();
			Gson gson = gsonBuilder.create();
			WebResource webResource8 = client
					.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/rapidviews/viewsData?");
			ClientResponse response1 = webResource8.header("Content-Type", "application/json")
					.header("Cookie",authStringEnc).get(ClientResponse.class);
			String responseString1 = response1.getEntity(String.class);
			System.out.println("Response " + response1);
			System.out.println("ResponseStr " + responseString1);
			JSONObject objResponseString1 = new JSONObject(responseString1);
			JSONArray views = (JSONArray) objResponseString1.get("views");
			int viewslength = views.length();
			for (int i = 0; i < viewslength; i++) {
				JSONObject view = (JSONObject) views.get(i);
				boardId = (Integer) view.get("id");
				JSONObject filter = (JSONObject) view.get("filter");
				if (rapidViewId == boardId) {
					id = (Integer) filter.get("id");
					System.out.println("id1:" + id);
				}
			}

			WebResource webResource1 = client.resource(
					"https://agilectb.atlassian.net/rest/chartplugin/1.0/workloadpie/generate?projectOrFilterId=filter-"
							+ id + "&statistictype=assignees"); // id=10503

			ClientResponse response2 = webResource1.header("Content-Type", "application/json")
					.header("Cookie",authStringEnc).get(ClientResponse.class);

			String responseString2 = response2.getEntity(String.class);
			System.out.println("Response1 " + response1);
			System.out.println("ResponseStr1 " + responseString2);
			JSONObject objResponseString2;
			objResponseString2 = new JSONObject(responseString2);

			String imageMap = (String) objResponseString2.get("imageMap");
			System.out.println("imageMap = " + imageMap);

			JSONObject finalResponse = new JSONObject();

			for (int i = -1; (i = imageMap.indexOf("alt=\"", i + 1)) != -1; i++) {
				System.out.println(i);
				// for full name from complete, ex:alt=\"Priya Shanmugam: 2d (100%)\
				String imageMapName = imageMap.substring(i, imageMap.indexOf("%)\"", i));
				System.out.println("x :" + imageMapName);
				String name = imageMapName.substring(5, imageMapName.indexOf(": "));
				System.out.println("yt :" + name);
				String imageMapAltvalue = imageMapName.substring(imageMapName.indexOf(": ") + 2,
						imageMapName.indexOf(" ("));// just for hours ex:3h
				System.out.println("z :" + imageMapAltvalue);

				// Considering the assignee and calculating the hrs spent by assignee in a day
				t = 0;
				++t;
				for (n = 0; n < t; n++) {

					assignee[n] = name;
					nameList.add(assignee[n]);
					System.out.println("Assignee are:" + nameList);

					int hoursDay = imageMapAltvalue.indexOf('d');

					if (hoursDay != -1) {
						String hoursDayValue = imageMapAltvalue.substring(hoursDay - 1, hoursDay);

						int hoursDayIntValue = Integer.parseInt(hoursDayValue);

						timeSpentDay = hoursDayIntValue * 6;
						System.out.println(timeSpentDay);

					} else {
						timeSpentDay = 0;
						System.out.println(timeSpentDay);
					}
					// Considering the assignee and calculating the hrs spent by assignee in a week
					int hoursWeek = imageMapAltvalue.indexOf('w');
					if (hoursWeek != -1) {
						String hoursWeekValue = imageMapAltvalue.substring(hoursWeek - 1, hoursWeek);
						int hoursWeekIntValue = Integer.parseInt(hoursWeekValue);
						timeSpentWeek = hoursWeekIntValue * 6 * 5;
						System.out.println(timeSpentWeek);
					} else {
						timeSpentWeek = 0;
						System.out.println(timeSpentWeek);
					}

					// Considering the assignee and calculating the total hrs spent by assignee

					int hour = imageMapAltvalue.indexOf('h');
					if (hour != -1) {
						String hoursValue = imageMapAltvalue.substring(hour - 1, hour);
						int hoursIntValue = Integer.parseInt(hoursValue);
						timeSpentHours = hoursIntValue;
						System.out.println(timeSpentHours);
					} else {
						timeSpentHours = 0;
						System.out.println(timeSpentHours);
					}
					// Total Hours
					overalltimespent = timeSpentWeek + timeSpentDay + timeSpentHours;
					System.out.println("overalltimespent =" + overalltimespent);

					hr[n] = (double) overalltimespent;
					hoursList.add(hr[n]);
					System.out.println("hr are:" + hoursList);

					// WbdcDetails
					WbdcDetail wbdcDetails1 = new WbdcDetail(overalltimespent, name);
					wbdcDetailsList.add(wbdcDetails1);
					System.out.println("JSON Object List " + gson.toJson(wbdcDetailsList));
				}
			}

			listsize = wbdcDetailsList.size();

			if (listsize != 0) {
				finalResponse.put("Assignee are", nameList);
				finalResponse.put("overalltimespent", hoursList);
				System.out.println("Output from Server .... \n" + finalResponse);
				client.destroy();
				return Response.status(200).entity(gson.toJson(wbdcDetailsList).toString())
						.header("Content-Type", "application/json").build();
			} else {
				stringEmpty = "but value is empty";
				finalResponse.put("Work break down chart is available:", stringEmpty);
				client.destroy();
				return Response.status(200).entity(finalResponse.toString()).header("Content-Type", "application/json")
						.build();

			}

		} catch (Exception e) {
			String val = "Not Available";
			JSONObject finalResponse = new JSONObject();
			finalResponse.put("No Work break down chart is", val);
			client.destroy();
			return Response.status(200).entity(finalResponse.toString()).header("Content-Type", "application/json")
					.build();
		}
	}

}
