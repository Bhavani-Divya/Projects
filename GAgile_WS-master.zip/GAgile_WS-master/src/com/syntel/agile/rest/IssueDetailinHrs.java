package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Scanner;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
//import org.json.simple.parser.JSONParser;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import java.text.ParseException;  
import java.text.SimpleDateFormat;  
import java.util.Date;  
import java.util.Locale;

@Path("/issueDetailinHrs")

public class IssueDetailinHrs{

	@GET
	@Path("/{rid}/{projectKey}")
	public Response getAllsprintidIssuevalue(@PathParam("rid") String rid,@PathParam("projectKey") String projectKey,@PathParam("activeSprints") String activeSprints,@Context HttpHeaders headers) throws JSONException, ParseException {
	
		Set<String> headerKeys = headers.getRequestHeaders().keySet();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.err.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();
		
		/*ActiveBugsandImpediments bugval  = new ActiveBugsandImpediments();
		double bug =(Double) bugval.bugs();
		*/
		WebResource webResource1 = client
				.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/sprintquery/"+ rid +"");
		
		ClientResponse response1 = webResource1.header("Content-Type", "application/json").header("Cookie",authStringEnc).get(ClientResponse.class);

		//ClientResponse response1 = webResource1.header("Content-Type", "application/json").header("Authorization", "Basic R3Vlc3Q6c3ludGVsMTIzJA==").get(ClientResponse.class); //Z3VuaW5kZXJfYmhhdGlhQHN5bnRlbGluYy5jb206c3ludGVsMTIzJA==
		
		//ClientResponse response1 = webResource1.header("Content-Type", "application/json").header("Authorization", "Basic Z3VuaW5kZXJfYmhhdGlhOnN5bnRlbDEyMyQ=").get(ClientResponse.class);
	
		double bugs=0; double totalbug =0.0,bughr =0.0;
		
		double btotalhrs = 0.0; double bval = 0.0,obval = 0.0;
		double bvals = 0.0, bvalss =0.0,bvalhr = 0.0;
		
		Double bsb =0.0,bsb1=0.0,bsb2=0.0;
		HashMap<String, Boolean> allstory = new HashMap<String, Boolean>();
		List<Double> totalremainingstoryhr = new ArrayList<Double>();
		List<Double> donestoryhr = new ArrayList<Double>();
		
		
		Double valueval = 0.0,nvalueval = 0.0,valueval1 = 0.0;	
		Double overallval = 0.0,noverallval = 0.0,toverallval = 0.0,overallval1 = 0.0,allval = 0.0;
		Double totalval = 0.0, dsoverallval = 0.0, dstotaldonevalhr =0.0;
		Double totaldonevalhr = 0.0,ntotaldonevalhr = 0.0,ttotaldonevalhr = 0.0,alltotalvalhr = 0.0;
		
		Double svalueval = 0.0,soverallval = 0.0,stotaldonevalhr =0.0, sttotaldonevalhr = 0.0;
		Double dsvalueval = 0.0;
		Double snvalueval = 0.0,snoverallval = 0.0,sntotaldonevalhr = 0.0, stoverallval = 0.0;
		
		Double storypointval =0.0, sthr=0.0;
		Double nstorypointval=0.0,nsthr=0.0;
		Double tspval=0.0, tsthr=0.0;
		
		String respStr1 = response1.getEntity(String.class);
		System.out.println("Response " + response1);
		System.out.println("ResponseStr " + respStr1);
		JSONObject ob1;
		ob1 = new JSONObject(respStr1);
					
		JSONArray sprintnew= (JSONArray) ob1.get("sprints");
		JSONArray issuesNotCompletedInCurrentSprint;
		JSONArray issuesNotCompletedInCurrentSprint1;
		int sprintnewlength = sprintnew.length();
		
		System.out.println("sprintlength"+sprintnewlength);
	    
		int count = sprintnewlength; 
		System.out.println("count"+count);	
		
		double alltotalvalhrarr[]  = new double[sprintnewlength] ;
		double toverallvalarr[] = new double[sprintnewlength] ;
		double stoverallvalarr[] = new double[sprintnewlength];
		double dstoverallvalarr[] = new double[sprintnewlength];
		double tstoverallvalar[] = new double[sprintnewlength];
		
		double totalhrs = 0.0,totalhrs6; //215
		double overalltotalhrs,overalltotalhrs6; //216
		double donevalue,donevalue6; //215
		
		double donecount = 0 ,donecount6 =0;
		double[] donecountval;
		double donevallen , donevallen6;
		double[] donestry = new double[count];// get totalCount of all jsonObjects
						
		String[] str = new String[count]; 
		
		double totalcount = 0 ;
		double[] spenthrs = new double[count],spenthrs6 = new double[count];
		double[] remaininghrs = new double[count],remaininghrs6 = new double[count];
		String[] keyval; 
		
		Set<Double> set = new HashSet<Double>();
		Set<Double> set1 = new HashSet<Double>();
		Set<Double> set11 = new HashSet<Double>();
		Set<Double> set16 = new HashSet<Double>();
		Set<String> set2 = new HashSet<String>();
		Set<String> set3 = new HashSet<String>();		
		double[] ds = new double[count],ts = new double[count];
		List<Double> donestory = new ArrayList<Double>();//
		List<Double> totalstory = new ArrayList<Double>();
		//double /*da = 0.0 ,*//*da1 = 0.0 *//*da2 = 0.0*/;
		List<Double> totalremainingstory = new ArrayList<Double>();
		List<Double> tsval = new ArrayList<Double>();				
		List<Double> list = new ArrayList<Double>();
		List<Double> list1 = new ArrayList<Double>();		
		List<Double> list11 = new ArrayList<Double>();
		List<Double> list16 = new ArrayList<Double>();		
		List<String> list2 = new ArrayList<String>();		
		List<Double> nofinals = new ArrayList<Double>();
		List<String> namefinals = new ArrayList<String>();
		
		double[] nofinalval = new double[count];
		
		double nofinalvallen = 0.0; //496
		
		String[] namefinalval = new String[count]; 
		
		String strdate; String enddate = null; String strDate1 = null,strDateSprint,endDateSprintfinal;
		Integer sequence = 0 ; String name; String strDate2 = null ;String strDate3 = null;
		
		Date currentday = null;Date startdatefinal = null; Date enddatefinal = null;
		Date d1 = null; Date d2 = null;
		
		boolean val = false; Integer projectId1 = null;
		
		int seq = 0; String strdt1 = null ,enddt1 = null ;String relstrdt1 = null , relenddate = null;
		Integer idvalfinal = 0;String namefinal = null;
		int idvalfinals[] = new int[count]; //683
		Integer projectId = 0;
		double doneEstimate; double donetotalhr;double totaldonehrs = 0;
		
		String enddatefinalval = null; String startdatefinalval = null; String  currentdayfinalval = null; 
		
	    if(sprintnewlength!=0){   	  		    	
	    	 
	    	WebResource webResource = client
	    			  .resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId="+ rid +"&selectedProjectKey="+ projectKey +""); //AIEM //15
	    	
	    	ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie",authStringEnc).get(ClientResponse.class); 
	    	
	    	String respStr = response.getEntity(String.class);
	    	System.out.println("Response " + response);
	    	System.out.println("ResponseStr " + respStr);
	    	JSONObject ob;
	    	ob = new JSONObject(respStr);
	    	System.out.println(ob);	    	
	    	JSONArray issues1 = (JSONArray) ob.get("issues");	    	 
	    	for(int k=0;k<issues1.length();k++){
	    	JSONObject value = (JSONObject) issues1.get(k);	    	 
	    	HashMap<String, String> bugss = new HashMap<String, String>();
	    	String typeName = (String) value.get("typeName");
	    	System.out.println(typeName);
	    	Boolean done = (Boolean) value.get("done");
	    	System.out.println(done);
	    	if((typeName.equals("Bug")) &&  (done.equals(false))){
	    	bugs++;
	    	
	    	JSONObject estimateStatistic =(JSONObject) value.get("estimateStatistic");
	    	JSONObject statFieldValue = (JSONObject) estimateStatistic.get("statFieldValue");
	    	
	    	if(statFieldValue.has("value")){
	    		Double bugval = (Double) statFieldValue.get("value");
	    		totalbug += bugval;
	    	}
	    	}
	    	}
	    	
	    	//bughr = totalbug*6;
	    	
	    	WebResource webResource3 = client
					.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId="+ rid +"&selectedProjectKey="+ projectKey +"");
			
	    	ClientResponse response3 = webResource3.header("Content-Type", "application/json").header("Cookie", authStringEnc).get(ClientResponse.class);
	   	
	    	//ClientResponse response3 = webResource3.header("Content-Type", "application/json").header("Authorization", "Basic R3Vlc3Q6c3ludGVsMTIzJA==").get(ClientResponse.class); //Z3VuaW5kZXJfYmhhdGlhQHN5bnRlbGluYy5jb206c3ludGVsMTIzJA==
	    	
			//ClientResponse response3 = webResource3.header("Content-Type", "application/json").header("Authorization", "Basic Z3VuaW5kZXJfYmhhdGlhOnN5bnRlbDEyMyQ=").get(ClientResponse.class);		    
			String respStr3 = response3.getEntity(String.class);
			System.out.println("Response " + response3);
			System.out.println("ResponseStr " + respStr3);
			JSONObject ob3;
			ob3 = new JSONObject(respStr3);
			JSONArray issues = (JSONArray) ob3.get("issues");
			int issueslen = issues.length();
			
			JSONArray projects = (JSONArray) ob3.get("projects");
			int projectslen = issues.length();
			
			for(int i=0;i<1;i++){
				JSONObject proj = (JSONObject) projects.get(i);
				projectId =(Integer)proj.get("id");
				System.out.println();
			}
						
			for(int i=0;i<issueslen;i++){
				JSONObject val1 = (JSONObject) issues.get(i);
				//System.out.println("val is:"+val1);
				projectId =(Integer)val1.get("projectId");
				System.out.println("proj id is:"+projectId);
				//fixVersions
			}
			
			JSONObject versionData =(JSONObject) ob3.get("versionData");
		    
		    System.out.println("version Data"+versionData);
		    
		    String projidval = null;
			
			if(projectId != 0){
			
	    	 projidval=Integer.toString(projectId);
	    	 System.out.println("projidval"+projidval);
			}
			
			else{
				
				projidval=Integer.toString(projectId1);
				System.out.println("projidval"+projidval);
			}
		    
			JSONObject versionsPerProject =  (JSONObject) versionData.get("versionsPerProject");
			
			System.out.println("versionsPerProject"+versionsPerProject);
			
			JSONArray valuesarray2 = versionsPerProject.getJSONArray(projidval);
			
			JSONArray rel = versionsPerProject.getJSONArray(projidval);
						
			//JSONArray rel = (JSONArray) versionsPerProject.get("10200");
		    
		    int rellength = rel.length();
			
		    JSONObject versionStats;
		    System.out.println("rellength"+rellength);
			
		    if(rellength!=0){
		    	
		    	for(int rli=0 ; rli< rellength; rli++){   // iterate through jsonArray 
			    	JSONObject jsonObject1 = (JSONObject) rel.get(rli);  // get jsonObject @ i position 
			    	System.out.println("jsonObject " + rli + ": " + jsonObject1+"size>>"+jsonObject1.length());
			    	
			    	if( jsonObject1.has("releaseDateFormatted")){
			    	    String	releaseDateFormatted = (String)jsonObject1.get("releaseDateFormatted");
			    	    	System.out.println("rel date"+releaseDateFormatted);
			    	    }
			    				    	
			    	Set keys1 = jsonObject1.keySet();
			    	    Iterator a1 = keys1.iterator();
			    	    while(a1.hasNext()) {
			    	    String key1 = (String)a1.next();
			    	        // loop to get the dynamic key
			    	        if(key1.equalsIgnoreCase("released"))
			    	        {
			    	        boolean value = (Boolean) jsonObject1.get(key1);
			    	        if(!value)
			    	        {
			    	        	System.out.println("!value = "+!value);
			    	        val	= !value;
			    	        System.out.println("val = "+val);
			    	        sequence = (Integer)jsonObject1.get("sequence");
			    	        name = (String)jsonObject1.get("name");
			    	        String releaseDateFormatted =null;String startDateFormatted = null;
			    	        if(jsonObject1.has("releaseDateFormatted") && jsonObject1.has("startDateFormatted") ){
			    	        
			    	         releaseDateFormatted = (String)jsonObject1.get("releaseDateFormatted");
			    	         startDateFormatted = (String)jsonObject1.get("startDateFormatted");
			    	        System.out.println("\n seq>>"+sequence+" and nam"+name);
			    	        System.out.println("\n startDateFormatted>>"+startDateFormatted+" and releaseDateFormatted"+releaseDateFormatted);			    	        
			    	        
			    	        Date date = new Date(); 
			    	        
			    	        LocalDateTime datetime1 = LocalDateTime.now();  
			    	        DateTimeFormatter format = DateTimeFormatter.ofPattern("MM/dd/yy");
			    	        
			    	        String formatDateTime = datetime1.format(format);   
			    	        System.out.println(formatDateTime);
			    	            	          	        
			    	        SimpleDateFormat formatter = new SimpleDateFormat("dd/MMM/yy");
							SimpleDateFormat formatterCustom = new SimpleDateFormat("MM/dd/yy"); //dd/MM
							Date startDate = formatter.parse((String)jsonObject1.get("startDateFormatted").toString());
			    	        //Date startDAteFormated = formatter.parse((String)sprints.get("startDate").toString());
						    System.out.println(startDate);
						    strDate1 = formatterCustom.format(startDate);
						    System.out.println("startDate"+startDate);
			    	        
						    SimpleDateFormat formatter1 = new SimpleDateFormat("dd/MMM/yy");
							SimpleDateFormat formatterCustom1 = new SimpleDateFormat("MM/dd/yy"); //dd/MM
							Date endDate = formatter.parse((String)jsonObject1.get("releaseDateFormatted").toString());
			    	        //Date startDAteFormated = formatter.parse((String)sprints.get("startDate").toString());
						    System.out.println("endDate" +endDate);
						    enddate = formatterCustom.format(endDate);
						    System.out.println("enddate"+enddate);
						    
						    SimpleDateFormat formatterCustomnew3 = new SimpleDateFormat("MMM yy");
						    Date startDAteFormated2 = formatter.parse((String)jsonObject1.get("startDateFormatted").toString());
						    System.out.println(startDAteFormated2);
						    strDate2 = formatterCustomnew3.format(startDAteFormated2);
						    System.out.println(strDate2);
						    
						    Date startDAteFormated3 = formatter.parse((String)jsonObject1.get("releaseDateFormatted").toString());
						    System.out.println(startDAteFormated3);
						    strDate3 = formatterCustomnew3.format(startDAteFormated3);
						    System.out.println(strDate3);
						    
						    String today = formatDateTime;
			    	        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
						    enddatefinal = endDate;
						    System.out.println("enddatefinal"+enddatefinal);
						    startdatefinal = startDate ;
						    System.out.println("startdatefinal"+startdatefinal);
						    
						    currentday = sdf.parse(today);
						    System.out.println("currentday"+currentday);
						    
						    System.out.println("enddatefinal : " + sdf.format(enddatefinal));
						    System.out.println("startdatefinal : " + sdf.format(startdatefinal));
						    System.out.println("currentday : " + sdf.format(currentday));
						    
						    enddatefinalval = sdf.format(enddatefinal);
						    System.out.println("enddatefinalval"+enddatefinalval);
						    startdatefinalval = sdf.format(startdatefinal);
						    currentdayfinalval = sdf.format(currentday);
						    
						    if (startdatefinal.compareTo(currentday) <= 0 && enddatefinal.compareTo(currentday) >=0 ) {					    	
						    	 d1 = startdatefinal;
						    	 d2 = enddatefinal;
						    	 System.out.println("Date is"+strDate1+"-"+enddate);
						    	 System.out.println("Release :"+sequence);
						    	 System.out.println("startdate is:"+strDate2);
					    	     System.out.println("enddate is:"+strDate3);
					    	     
					    	     relstrdt1 = strDate1;
					    	     relenddate = enddate;
					    	     
					    	     seq = sequence;
					    	     strdt1 = strDate2;
					    	     enddt1 = strDate3;
					    	     System.out.println("spent hr is :"+set);
					    	     System.out.println("rem hr is :"+set1);
					    		 System.out.println("sprint name is :"+set3);
					    		 
					    		 versionStats = (JSONObject)jsonObject1.get("versionStats"); 
					    	        System.out.println("versionStats"+versionStats);
					    	        doneEstimate =(Double) versionStats.get("doneEstimate") ;
					    	        System.out.println("doneEstimate"+doneEstimate);
					    	        
					    	        donetotalhr = doneEstimate * 6;
					    	        System.out.println("donetotalhr"+donetotalhr);
					    	        totaldonehrs =  donetotalhr;
					    	        System.out.println("totaldonehrs"+totaldonehrs);
					    		 
						    }else {
						        System.out.println("no release date is there");
						    }
						    
			    	        }else{
			    	        	System.out.println("no current release setup");
			    	        }						    
			    	        }			    	        
			    	        else{			    	        	
			    	        	System.out.println("release date are not available not set up yet");
			    	        }
			    	        }
			    	    }
			    	}
		    }	    	
	    	
	    for(int i=0 ; i< sprintnewlength; i++){
	    	
	    	JSONObject jsonObject = (JSONObject) sprintnew.get(i);  // get jsonObject @ i position 
	    	System.out.println("\n jsonObject " + i + ": " + jsonObject+"size>>"+jsonObject.length());
	    	Set keys = jsonObject.keySet();
	    	    Iterator a = keys.iterator();
	    	    int keyValue;
	    	    String nameValue;	    	   	    	   
	    	    while(a.hasNext()) {	    	    
	    	    String key = (String)a.next();
	    	    System.out.print("\n key : "+key);	    	       
	    	    if(key.equalsIgnoreCase("id"))
	    	    {
	    	    keyValue = (Integer)jsonObject.get("id");
	    	    System.out.println("\n keyValue>>"+keyValue);
	    	    donestry[i]=300;
	    	    totalcount = totalcount + donestry[i];
	    	    System.out.println("id:"+keyValue+" && Donestory :"+totalcount);	    	    
	    	    if(key.equalsIgnoreCase("name")){	    	    
	    	    nameValue = (String)jsonObject.get("name");
	    	    System.out.println("\n nameValue>>"+nameValue);	            	    	    
	    	    }	    	    
	    	    WebResource webResource2 = client
						.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/rapid/charts/sprintreport?rapidViewId="+ rid +"&sprintId="+ keyValue +"");	    	    
	    	    ClientResponse response2 = webResource2.header("Content-Type", "application/json").header("Cookie",authStringEnc).get(ClientResponse.class);
	    	    
	    	    //ClientResponse response2 = webResource2.header("Content-Type", "application/json").header("Authorization", "Basic R3Vlc3Q6c3ludGVsMTIzJA==").get(ClientResponse.class); //Z3VuaW5kZXJfYmhhdGlhQHN5bnRlbGluYy5jb206c3ludGVsMTIzJA==	    		
	    	   // ClientResponse response2 = webResource2.header("Content-Type", "application/json").header("Authorization", "Basic Z3VuaW5kZXJfYmhhdGlhOnN5bnRlbDEyMyQ=").get(ClientResponse.class);
				
				String respStr2 = response2.getEntity(String.class);
				System.out.println("Response2 " + response2);
				System.out.println("ResponseStr2 " + respStr2);
				JSONObject ob2;
				ob2 = new JSONObject(respStr2);
				
				JSONObject sprintval3 = (JSONObject)ob2.get("sprint") ;
				String nameval =(String) sprintval3.get("name");
				Integer idval =(Integer) sprintval3.get("id");
				
				System.out.println("nameval" + nameval);
				System.out.println("idval" + idval);  //contents
				
				JSONObject contents = (JSONObject)ob2.get("contents") ;
				//JSONObject completedIssuesEstimateSum =  (JSONObject) (issues.getJSONObject(i).get("estimateStatistic"));
				System.out.println("contents" + contents);	
				
				JSONArray completedIssues = (JSONArray) contents.get("completedIssues")  ;
				System.out.println("completedIssues" + completedIssues);
				
				double completedIssueslength= completedIssues.length() ;
				
				System.out.println("completedIssueslength"+completedIssueslength);
				
				for(int si=0;si<completedIssues.length();si++){					
					
					JSONObject value = (JSONObject) completedIssues.get(si);
					//JSONObject value = (JSONObject) completedIssues.get(i);
					if(value.getString("statusName").equals("Done") && (value.getString("typeName").equals("Story"))){						
						String donekey=(String) value.get("key") ;
						System.out.println("donekey = "+donekey);						 						
						//donecount++;
						donecount = donecount + 1;
						System.out.println("donevalue = "+donecount);
						double[] donecountval1 = new double[si];
						 donecountval = donecountval1;
						// System.out.println("donecountval = "+donecountval);
						 donevallen = donecountval.length;
						 System.out.println("done value = " +donevallen);
						//set2.add(donecount[si]); 					 
						 double donelengthvalue = donevallen + 1 ;
						 System.out.println("donelengthvalue" +donelengthvalue);
					}					
				}				
				JSONObject completedIssuesEstimateSum = (JSONObject)contents.get("completedIssuesEstimateSum") ;
				System.out.println("completedIssuesEstimateSum" + completedIssuesEstimateSum);
				double cieslen=completedIssuesEstimateSum.length();
				System.out.println("cieslen = "+cieslen);
				JSONObject sprintdateval = (JSONObject) ob2.get("sprint");
				System.out.println("Sprintvalue"+sprintdateval);
				String startDatesprint;
				String endDatesprint;					
				if(cieslen <=1){					
					System.out.println("No done Story are current in sprint");
					donevalue = 0 ;/*bvals = 0;
					bvalhr = bvalss * 6 ;*/
					totalhrs = donevalue * 6;
					//overalltotalhrs = 1500 - totalhrs;
					overalltotalhrs = totaldonehrs - totalhrs;
					System.out.println("spent hrs"+totalhrs);
					System.out.println("remaining hrs"+overalltotalhrs);		    	    
					startDatesprint = (String) sprintdateval.get("startDate") ;
					System.out.println("startdate = " +startDatesprint);
					endDatesprint   = (String) sprintdateval.get("endDate");
					System.out.println("enddate = " +endDatesprint);					
					 SimpleDateFormat formatter5 = new SimpleDateFormat("dd/MMM/yy");
					 SimpleDateFormat formatterCustom5 = new SimpleDateFormat("MM/dd/yy"); //dd/MM
					 Date startDate = formatter5.parse((String)sprintdateval.get("startDate").toString());
		    	     System.out.println(startDate);
					 strDateSprint = formatterCustom5.format(startDate);
					 System.out.println("strDateSprint"+ strDateSprint);					 
					 SimpleDateFormat formatter6 = new SimpleDateFormat("dd/MMM/yy");
					 SimpleDateFormat formatterCustom6 = new SimpleDateFormat("MM/dd/yy"); //dd/MM
					 Date endDateSprint = formatter6.parse((String)sprintdateval.get("endDate").toString());
		    	     System.out.println(endDateSprint);
					 endDateSprintfinal = formatterCustom5.format(endDateSprint);
					 System.out.println("endDateSprint"+ endDateSprintfinal);					 
					 	System.out.println("startDate & End date"+startDate+""+endDateSprint);		 
					 	System.out.println("relDate"+d1+""+d2);	
					  // if (strDateSprint.compareTo(relstrdt1) <= 0 && endDateSprintfinal.compareTo( relenddate) >=0 ) {	       
					 	if(d1!=null && d2 !=null){					 		
					 	//}				 	
					 	if (d1.compareTo(startDate) <= 0 && d2.compareTo(endDateSprint) >=0 ) {	 
						 idvalfinal = (Integer) sprintdateval.get("id");
						 System.out.println("idval ="+idvalfinal);
						 namefinal = (String) sprintdateval.get("name");
						 System.out.println("nameval ="+namefinal);
						 nofinalval[i] = idvalfinal;
						 namefinalval[i] = namefinal;
						 nofinals.add(nofinalval[i]);
						 System.out.println("nofinalval ="+nofinals);
					     namefinals.add(namefinalval[i]);
					     System.out.println("namefinalval ="+namefinals);
					     
					     nofinalvallen =nofinalval.length ;
					     
					     System.out.println("nofinalvallen"+nofinalvallen);
					     
					     WebResource webResource6 = client
									.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/rapid/charts/sprintreport?rapidViewId="+ rid +"&sprintId="+ idvalfinal +"");
				    	    
					     	ClientResponse response6 = webResource6.header("Content-Type", "application/json").header("Cookie", authStringEnc).get(ClientResponse.class);
				    	    
					     	//ClientResponse response6 = webResource6.header("Content-Type", "application/json").header("Authorization", "Basic R3Vlc3Q6c3ludGVsMTIzJA==").get(ClientResponse.class); //Z3VuaW5kZXJfYmhhdGlhQHN5bnRlbGluYy5jb206c3ludGVsMTIzJA==
					    	
				    	    //ClientResponse response6 = webResource6.header("Content-Type", "application/json").header("Authorization", "Basic Z3VuaW5kZXJfYmhhdGlhOnN5bnRlbDEyMyQ=").get(ClientResponse.class);
							
							String respStr6 = response6.getEntity(String.class);
							System.out.println("Response6 " + response6);
							System.out.println("ResponseStr6 " + respStr6);
							JSONObject ob6;
							ob6 = new JSONObject(respStr6);
							
							JSONObject sprintval6 = (JSONObject)ob6.get("sprint") ;
							String nameval6 =(String) sprintval6.get("name");
							Integer idval6 =(Integer) sprintval6.get("id");
							
							System.out.println("nameval is:" + nameval6);
							System.out.println("idval is:" + idval6);  //contents
							
							JSONObject contents6 = (JSONObject)ob6.get("contents") ;
							//JSONObject completedIssuesEstimateSum =  (JSONObject) (issues.getJSONObject(i).get("estimateStatistic"));
							System.out.println("contents6" + contents6);
							
							
							JSONArray completedIssues6 = (JSONArray) contents6.get("completedIssues")  ;
							System.out.println("completedIssues6" + completedIssues6);
							
							double completedIssueslength6= completedIssues6.length() ;
							
							for(int si=0;si<completedIssues6.length();si++){
								
							}						

							JSONObject completedIssuesEstimateSum6 = (JSONObject)contents6.get("completedIssuesEstimateSum") ;
							System.out.println("completedIssuesEstimateSum" + completedIssuesEstimateSum6);
							double cieslen6=completedIssuesEstimateSum6.length();
							System.out.println("cieslen6 = "+cieslen6);
							
							if(cieslen6 <=1){
								
								System.out.println("No done Story are current in sprint");
								donevalue6 = 0 ;
								totalhrs6 = donevalue6 * 6;
								overalltotalhrs6 = totaldonehrs - totalhrs6;
								System.out.println("spent hrs"+totalhrs6);
								System.out.println("remaining hrs"+overalltotalhrs6);
								
								if(i==0){
									 spenthrs6[i] = totalhrs6;
									 remaininghrs6[i] = overalltotalhrs6;
									}
									 
									else{
										spenthrs6[i] = totalhrs6+spenthrs6[i-1];
										 remaininghrs6[i] = overalltotalhrs6;
									}
								

								 System.out.println("spent hrs"+spenthrs6[i]);
								 System.out.println("remaining hrs"+remaininghrs6[i]);
								 set11.add(spenthrs6[i]);
						         set16.add(remaininghrs6[i]);
						         list11.add(spenthrs6[i]);
						         list16.add(remaininghrs6[i]);
							}
							else{
								donevalue6 = (Double) completedIssuesEstimateSum6.get("value");
								
								 totalhrs6 = donevalue6 * 6;
								 overalltotalhrs6 = totaldonehrs - totalhrs6;
								
								System.out.println("spent hrs"+totalhrs6);
								System.out.println("remaining hrs"+overalltotalhrs6);
					    	    
								 
								if(i==0){
									 spenthrs6[i] = totalhrs6;
									 remaininghrs6[i] = overalltotalhrs6;
									}
									 
									else{
										spenthrs6[i] = totalhrs6+spenthrs6[i-1];
										 remaininghrs6[i] = overalltotalhrs6;
									}
								
								 System.out.println("spent hrs"+spenthrs6[i]);
								 System.out.println("remaining hrs"+remaininghrs6[i]);
								 set11.add(spenthrs6[i]);
						         set16.add(remaininghrs6[i]);
						         list11.add(spenthrs6[i]);
						         list16.add(remaininghrs6[i]);
							}
							
					 }
				}
				       if(i==0){
							 spenthrs[i] = totalhrs;
							 remaininghrs[i] = overalltotalhrs;
							}
							 
							else{
								spenthrs[i] = totalhrs+spenthrs[i-1];
								 remaininghrs[i] = overalltotalhrs;
							}				       
				       
					 System.out.println("spent hrs"+spenthrs[i]);
					 System.out.println("remaining hrs"+remaininghrs[i]);
					 set.add(spenthrs[i]);
			         set1.add(remaininghrs[i]);
			         list.add(spenthrs[i]);
			         list1.add(remaininghrs[i]);
				}
				
				else{
				 donevalue = (Double) completedIssuesEstimateSum.get("value");
				
				 totalhrs = donevalue * 6;
				 overalltotalhrs = totaldonehrs - totalhrs;
				
				System.out.println("spent hrs"+totalhrs);
				System.out.println("remaining hrs"+overalltotalhrs);    	    		
				if(i==0){
					 spenthrs[i] = totalhrs;
					 remaininghrs[i] = overalltotalhrs;
					}					 
					else{
						spenthrs[i] = totalhrs+spenthrs[i-1];
						 remaininghrs[i] = overalltotalhrs;
					}				 
				 startDatesprint = (String) sprintdateval.get("startDate") ;
				 System.out.println("startdate = " +startDatesprint);
				 endDatesprint   = (String) sprintdateval.get("endDate");
				 System.out.println("enddate = " +endDatesprint);				 
				 
				 SimpleDateFormat formatter5 = new SimpleDateFormat("dd/MMM/yy");
				 SimpleDateFormat formatterCustom5 = new SimpleDateFormat("MM/dd/yy"); //dd/MM
				 Date startDate = formatter5.parse((String)sprintdateval.get("startDate").toString());
	    	     System.out.println(startDate);
				 strDateSprint = formatterCustom5.format(startDate);
				 System.out.println("strDateSprint"+ strDateSprint);
				 
				 SimpleDateFormat formatter6 = new SimpleDateFormat("dd/MMM/yy");
				 SimpleDateFormat formatterCustom6 = new SimpleDateFormat("MM/dd/yy"); //dd/MM
				 Date endDateSprint = formatter6.parse((String)sprintdateval.get("endDate").toString());
	    	     System.out.println(endDateSprint);
				 endDateSprintfinal = formatterCustom5.format(endDateSprint);
				 System.out.println("endDateSprint"+ endDateSprintfinal);
				 
				 System.out.println("relstrdt1 :" +relstrdt1);	
				 System.out.println("relenddate :"+relenddate);				 
				 
				 System.out.println("startDate & End date"+startDate+""+endDateSprint);		 
				 System.out.println("relDate"+d1+""+d2);
				 
				 if(d1!=null && d2 !=null){
				 System.out.println(startDate.compareTo(d1)+"sd<d1");
				 System.out.println(endDateSprint.compareTo(d2)+"ed<d2");
								 
				// if (strDateSprint.compareTo(relstrdt1) <= 0 && endDateSprintfinal.compareTo( relenddate) >=0 ) {
				 if (d1.compareTo(startDate) <= 0 && d2.compareTo(endDateSprint) >=0 ) {
				 //if (startDate.compareTo(d1) <= 0 && endDateSprint.compareTo(d2) <=0 ) {	 	 
					 idvalfinal = (Integer) sprintdateval.get("id");
					 System.out.println("idval ="+idvalfinal);
					 namefinal = (String) sprintdateval.get("name");
					 System.out.println("nameval ="+namefinal);
					 nofinalval[i] = idvalfinal;
					 namefinalval[i] = namefinal;
					 nofinals.add(nofinalval[i]);
					 System.out.println("nofinalval ="+nofinals);
				     namefinals.add(namefinalval[i]);
				     System.out.println("namefinalval ="+namefinals);		     
				     
				     nofinalvallen =nofinalval.length ;
				     
				     System.out.println("nofinalvallen"+nofinalvallen);
				       idvalfinals[i] = idvalfinal;
				     
				     WebResource webResource6 = client
								.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/rapid/charts/sprintreport?rapidViewId="+ rid +"&sprintId="+ idvalfinal +"");
			    	    
				     	ClientResponse response6 = webResource6.header("Content-Type", "application/json").header("Cookie", authStringEnc).get(ClientResponse.class);
			    	   	
				     	//ClientResponse response6 = webResource6.header("Content-Type", "application/json").header("Authorization", "Basic R3Vlc3Q6c3ludGVsMTIzJA==").get(ClientResponse.class); //Z3VuaW5kZXJfYmhhdGlhQHN5bnRlbGluYy5jb206c3ludGVsMTIzJA==
				    	
			    	   // ClientResponse response6 = webResource6.header("Content-Type", "application/json").header("Authorization", "Basic Z3VuaW5kZXJfYmhhdGlhOnN5bnRlbDEyMyQ=").get(ClientResponse.class);
						
						String respStr6 = response6.getEntity(String.class);
						System.out.println("Response6 " + response6);
						System.out.println("ResponseStr6 " + respStr6);
						JSONObject ob6;
						ob6 = new JSONObject(respStr6);
						
						JSONObject sprintval6 = (JSONObject)ob6.get("sprint") ;
						String nameval6 =(String) sprintval6.get("name");
						Integer idval6 =(Integer) sprintval6.get("id");
						
						System.out.println("nameval" + nameval6);
						System.out.println("idval" + idval6);  //contents
						
						JSONObject contents6 = (JSONObject)ob6.get("contents") ;
						//JSONObject completedIssuesEstimateSum =  (JSONObject) (issues.getJSONObject(i).get("estimateStatistic"));
						System.out.println("contents" + contents6);
						
						
						JSONArray completedIssues6 = (JSONArray) contents6.get("completedIssues")  ;
						System.out.println("completedIssues" + completedIssues6);
						
						double completedIssueslength6= completedIssues6.length() ;
						
						for(int si=0;si<completedIssues6.length();si++){
							
							JSONObject value6 = (JSONObject) completedIssues6.get(si);
							//JSONObject value6 = (JSONObject) completedIssues6.get(i);
							if(value6.getString("statusName").equals("Done") && (value6.getString("typeName").equals("Story"))){
								
								String donekey6=(String) value6.get("key") ;
								System.out.println("donekey = "+donekey6);
								 						
								//donecount++;
								donecount6 = donecount6 + 1;
								System.out.println("donevalue6 = "+donecount6);
								double[] donecountval6 = new double[si];
								 donecountval6 = donecountval6;
								// System.out.println("donecountval = "+donecountval);
								 donevallen6 = donecountval6.length;
								 System.out.println("done value = " +donevallen6);
								//set2.add(donecount[si]); 
								 
								 double donelengthvalue6 = donevallen6 + 1 ;
								 System.out.println("donelengthvalue6" +donelengthvalue6);								 
								 
							}
							if(value6.getString("statusName").equals("Done") && (value6.getString("typeName").equals("Story"))){															
								JSONObject currentEstimateStatistic = (JSONObject) value6.get("currentEstimateStatistic") ;								
								JSONObject statFieldValue = (JSONObject) currentEstimateStatistic.get("statFieldValue") ;								
								System.out.println("statFieldValue is:"+statFieldValue);
								
								valueval = (Double) statFieldValue.get("value");
								
								System.out.println("valueval :"+valueval);
												
								overallval +=  valueval;
								System.out.println("overallval is :"+overallval);
								
								totaldonevalhr = overallval * 6;
								System.out.println("totaldonevalhr is :"+totaldonevalhr);
					
								
								toverallval = overallval  ; // + noverallval
								ttotaldonevalhr = toverallval * 6;
								System.out.println("ttotaldonevalhr:"+ttotaldonevalhr);
								toverallvalarr[i] = ttotaldonevalhr;
								System.out.println("toverallvalarr" +toverallvalarr);
								
								
								String donekey6=(String) value6.get("key") ;
								System.out.println("donekey = "+donekey6);
								 						
								//donecount++;
								donecount6 = donecount6 + 1;
								System.out.println("donevalue6 = "+donecount6);
								double[] donecountval6 = new double[si];
								 donecountval6 = donecountval6;
								// System.out.println("donecountval = "+donecountval);
								 donevallen6 = donecountval6.length;
								 System.out.println("done value = " +donevallen6);
								//set2.add(donecount[si]); 
								 
								 double donelengthvalue6 = donevallen6 + 1 ;
								 System.out.println("donelengthvalue6" +donelengthvalue6);							 

							}
							if((value6.getString("typeName").equals("Story"))){
							// value6.getString("statusName").equals("Done") &&
							
								String Key = (String) value6.get("key") ;
								
								
								allstory.put(Key, false);					
								System.out.println("allstory size:"+allstory.size());
								
								
								System.out.println("allstory"+allstory);
								
								JSONObject currentEstimateStatistic = (JSONObject) value6.get("currentEstimateStatistic") ;
								
								JSONObject statFieldValue = (JSONObject) currentEstimateStatistic.get("statFieldValue") ;
								
								if(statFieldValue.has("value"))
								svalueval = (Double) statFieldValue.get("value");
								storypointval += svalueval;
								soverallval +=  svalueval;
								
								System.out.println("soverallval is :"+soverallval);
								
								stotaldonevalhr = soverallval * 6;
								//storypointval += svalueval;
								sthr = storypointval*6;
								System.out.println("stotaldonevalhr is :"+stotaldonevalhr);					
								
							}
							
							//bug added
							
							if(value6.getString("statusName")!=("Done")&&(value6.getString("typeName").equals("Bug"))){				
								JSONObject currentEstimateStatistic = (JSONObject) value6.get("currentEstimateStatistic") ;
								
								JSONObject statFieldValue = (JSONObject) currentEstimateStatistic.get("statFieldValue") ;
								
								if(statFieldValue.has("value"))
								bsb = (Double) statFieldValue.get("value");
								bsb1 +=  bsb;
								bsb2 = bsb1 * 6;
							}
							
							if(value6.getString("statusName").equals("Done") && (value6.getString("typeName").equals("Story"))){
								// value6.getString("statusName").equals("Done") &&
								
									JSONObject currentEstimateStatistic = (JSONObject) value6.get("currentEstimateStatistic") ;
									
									JSONObject statFieldValue = (JSONObject) currentEstimateStatistic.get("statFieldValue") ;
									
									if(statFieldValue.has("value"))
									dsvalueval = (Double) statFieldValue.get("value");
									
									dsoverallval +=  dsvalueval;
									
									System.out.println("dsoverallval is :"+dsoverallval);
									
									dstotaldonevalhr = dsoverallval * 6;
									System.out.println("dstotaldonevalhr is :"+dstotaldonevalhr);
								}
							
						}	
						
						issuesNotCompletedInCurrentSprint1 = (JSONArray) contents.get("issuesNotCompletedInCurrentSprint")  ;
						
						int inclen = issuesNotCompletedInCurrentSprint1.length();
						
						System.out.println("inclen is: issuesNotCompletedInCurrentSprint1:"+inclen);
						
						if(inclen!=0){								
							
							for(int pi=0;pi<issuesNotCompletedInCurrentSprint1.length();pi++){				
								JSONObject value1 = (JSONObject) issuesNotCompletedInCurrentSprint1.get(pi);
							
								JSONObject currentEstimateStatistic1 = (JSONObject) value1.get("currentEstimateStatistic") ;
								
								JSONObject statFieldValue1 = (JSONObject) currentEstimateStatistic1.get("statFieldValue") ;
								
								String Key = (String) value1.get("key") ;					
								
								allstory.put(Key, false);					
								System.out.println("allstory size:"+allstory.size());
								
								
								System.out.println("allstory"+allstory);
								
								if((value1.getString("typeName").equals("Story")) && statFieldValue1.has("value"))
								snvalueval = (Double) statFieldValue1.get("value");
								
								snoverallval +=  snvalueval;
								
								nstorypointval += snvalueval;
								nsthr = nstorypointval*6;
								
								System.out.println("snoverallval is:" +snoverallval);
								
								sntotaldonevalhr = snoverallval * 6;
								System.out.println("sntotaldonevalhr:"+sntotaldonevalhr);
							}
						}
						
						stoverallval = soverallval + snoverallval ;
						sttotaldonevalhr = stoverallval * 6;
						System.out.println("sttotaldonevalhr:"+sttotaldonevalhr);
						
						tspval= storypointval + nstorypointval ; 
						tsthr= sthr+ nsthr ;
						
						
						stoverallvalarr[i] = sttotaldonevalhr;
						System.out.println("toverallvalarr" +stoverallvalarr);
						
						// done and all story cal
						// toal story
						ts[i] =  sttotaldonevalhr;
						tstoverallvalar[i] = sttotaldonevalhr;
						System.out.println("ts is:"+ts);
						//totalstory.add(ts[i]);
						totalstory.add(tstoverallvalar[i]);
						System.out.println("total story :"+totalstory);
						// done story
						dstoverallvalarr[i] = dstotaldonevalhr;
						
						donestory.add(dstoverallvalarr[i]);
						System.out.println("donestory"+donestory);						

						JSONObject completedIssuesEstimateSum6 = (JSONObject)contents6.get("completedIssuesEstimateSum") ;
						System.out.println("completedIssuesEstimateSum" + completedIssuesEstimateSum6);
						double cieslen6=completedIssuesEstimateSum6.length();
						System.out.println("cieslen6 = "+cieslen6);
						
						if(cieslen6 <=1){
							
							System.out.println("No done Story are current in sprint");
							donevalue6 = 0 ;
							totalhrs6 = donevalue6 * 6;
							overalltotalhrs6 = totaldonehrs - totalhrs6;
							System.out.println("spent hrs"+totalhrs6);
							System.out.println("remaining hrs"+overalltotalhrs6);
							
							
							if(i==0){
								 spenthrs6[i] = totalhrs6;
								 remaininghrs6[i] = overalltotalhrs6;
								}
								 
								else{
									spenthrs6[i] = totalhrs6+spenthrs6[i-1];
									 remaininghrs6[i] = overalltotalhrs6;
								}
							
							 System.out.println("spent hrs"+spenthrs6[i]);
							 System.out.println("remaining hrs"+remaininghrs6[i]);
							 set11.add(spenthrs6[i]);
					         set16.add(remaininghrs6[i]);
					         list11.add(spenthrs6[i]);
					         list16.add(remaininghrs6[i]);
						}
						else{
							donevalue6 = (Double) completedIssuesEstimateSum6.get("value");
							
							 totalhrs6 = donevalue6 * 6;
							 overalltotalhrs6 = totaldonehrs - totalhrs6;
							
							System.out.println("spent hrs"+totalhrs6);
							System.out.println("remaining hrs"+overalltotalhrs6);
				    	    
							
							if(i==0){
								 spenthrs6[i] = totalhrs6;
								 remaininghrs6[i] = overalltotalhrs6;
								}
								 
								else{
									spenthrs6[i] = totalhrs6+spenthrs6[i-1];
									 remaininghrs6[i] = overalltotalhrs6;
								} 
							
							 System.out.println("spent hrs"+spenthrs6[i]);
							 System.out.println("remaining hrs"+remaininghrs6[i]);
							 set11.add(spenthrs6[i]);
					         set16.add(remaininghrs6[i]);
					         list11.add(spenthrs6[i]);
					         list16.add(remaininghrs6[i]);
						}
				     
				 }
				 
				}//d1 and d2 null
				 				 				 
				 System.out.println("spent hrs"+spenthrs[i]);
				 System.out.println("remaining hrs"+remaininghrs[i]);

				 set.add(spenthrs[i]);
		         set1.add(remaininghrs[i]);
		         list.add(spenthrs[i]);
		         list1.add(remaininghrs[i]);
				 
	    	    }
	    	    
	    	    }
	    	    
	    	    else if(key.equalsIgnoreCase("name"))
	    	    {
	    	    nameValue = (String)jsonObject.get("name");
	    	    System.out.println("\n nameValue>>"+nameValue);

	    	    str[i] = nameValue;
	    	    System.out.println("Sprint name"+str[i]);
	    	    set3.add(str[i]);
	            list2.add(str[i]);
	            System.out.println("All Sprint name"+set3);
	            System.out.println("All Sprint names" +list2);
	    	    
	    	    }
	    	    
	    	    }
	    	
	    	
	    	
	    }
	       
	    }
	    
	    
	    else{
	    	
	    	JSONObject finalResponse = new JSONObject();
			
	    	int empty = 0;
	    	finalResponse.put("No Sprint Started yet",empty);
				
			System.out.println("Output from Server .... \n" + finalResponse);
			client.destroy();
			//return Response.status(200).entity(output.toString()).header("Content-Type", "application/text").build();
			return Response.status(200).entity(finalResponse.toString()).build();
	    	
	    }
	    for(int k=0;k<count;k++){//length is the property of array  
			
	    	System.out.println("k="+k);
			System.out.println("spenthrs="+spenthrs[k]);
			System.out.println(spenthrs[k]);
			System.out.println("remaininghrs="+remaininghrs[k]);
			
	            set.add(spenthrs[k]);
	            set1.add(remaininghrs[k]);
	            list.add(spenthrs[k]);
	            list1.add(remaininghrs[k]);
		         for(int ri = 0; ri < count; ri++) {
			         }
		         
		         System.out.println(set);
		         System.out.println(set1);
		         System.out.println("List = "+list);
		         System.out.println("List1 = "+list1);
			
			 }
		
	    System.out.println("startdatefinal"+startdatefinal+"enddatefinal"+enddatefinal);
	
	    // add additional coding here 
	    // imp
	    if (totalstory != null && !totalstory.isEmpty()) {
	    WebResource webResource12 = client
				.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId="+ rid +"&selectedProjectKey="+ projectKey +"");
		ClientResponse response12 = webResource12.header("Content-Type", "application/json").header("Cookie", authStringEnc).get(ClientResponse.class);
		
		//double btotalhrs = 0.0;
		
		String respStr12 = response12.getEntity(String.class);
		System.out.println("Response " + response12);
		System.out.println("ResponseStr " + respStr12);
		JSONObject ob12;
		ob12 = new JSONObject(respStr12);
		JSONArray issues12 = (JSONArray) ob12.get("issues");
		//double bval = 0.0,obval = 0.0;
	    
		for(int i12=0;i12<issues12.length();i12++){
			
			JSONObject value12 = (JSONObject) issues12.get(i12);
			
			if((value12.getString("typeName").equals("Story"))){
				
				String key = (String) value12.get("key");
				
				if(!allstory.containsKey(key)){
				/*allstory = getDefaultMap(key, allstory);
				
				System.out.println("allstory is:" +allstory);*/
				
				System.out.println("key is:"+key);
				
				JSONObject estimateStatistic12 = (JSONObject) value12.get("estimateStatistic");
				JSONObject statFieldValue12 = (JSONObject) estimateStatistic12.get("statFieldValue");
				if(statFieldValue12.has("value")){
					bval = (Double) statFieldValue12.get("value");
					
					obval +=  bval;
					
					System.out.println("overallval is :"+obval);
				}
				}
					
				
			}
			//added bug value
			
			if(value12.getString("statusName")!=("Done")&&(value12.getString("typeName").equals("Bug"))){				
				String key = (String) value12.get("key");		
				if(!allstory.containsKey(key)){
					allstory = getDefaultMap(key, allstory);
					
					System.out.println("allstory is:" +allstory);				
					System.out.println("key is:"+key);
					
					JSONObject estimateStatistic12 = (JSONObject) value12.get("estimateStatistic");
					JSONObject statFieldValue12 = (JSONObject) estimateStatistic12.get("statFieldValue");
					if(statFieldValue12.has("value")){
						bvals = (Double) statFieldValue12.get("value");
						
						bvalss +=  bvals;
						
						System.out.println("overallval is :"+obval);
					}
					}
			}
			
		}
		System.out.println("obval:"+obval);
		
		double abc = (totalstory.get(totalstory.size()-1))/6;
		System.out.println("abc:"+abc);
		//obval = obval + totalstory.get(totalstory.size()-1);
		obval = obval + abc;
		totalhrs = obval * 6;
		System.out.println("obval:"+obval);
		System.out.println("totalhrs:"+totalhrs);
	    // imp
		
		bvalhr = bvalss * 6 ;
		
		// sprints
		// namefinals.add();
		JSONArray sprints12 = (JSONArray) ob12.get("sprints");
		
		for(int s12=0;s12<sprints12.length();s12++){
			
			JSONObject svalue12 = (JSONObject) sprints12.get(s12);
			String sprintname = (String) svalue12.get("name");
			System.out.println("sprint name:"+sprintname);
			
			/*if(!namefinals.containsKey(sprintname)){
				System.out.println("name val for planned story:"+namefinals);
			}*/
			
			if(!namefinals.contains(sprintname)){
				namefinals.add(sprintname);
				System.out.println("name val for planned story:"+namefinals);
			}
			
			//containsKey

			//
		}
		
	    }
		// stmt is end here
		
	    double da2=0.0;
		if (totalstory != null && !totalstory.isEmpty()) {
	        System.out.println("Last element is:");
	        System.out.println(totalstory.get(totalstory.size()-1));
	     /*   da = totalstory.get(totalstory.size()-1);
	        System.out.println("da val is:"+da);*/
	    
			for(int i1=0;i1<donestory.size();i1++){
				
				if(i1==0){
					double z =0.0;
					donestory.add(0,z);
					System.out.println("donestory is i==0 :"+donestory);
				}
				
				System.out.println("total story val is:"+donestory.get(i1));
				double da1 = donestory.get(i1);
				System.out.println("da1 is :"+da1);
				da2 = totalstory.get(totalstory.size()-1) - da1 ;
				/*tsval.add(da2);*/
				System.out.println("totalstory.size() is:"+totalstory.size());
				System.out.println("donestory.size() is:"+donestory.size());
				/*System.out.println("ts val is:"+tsval);*/
				System.out.println("da2 is :"+da2);
								
				double da3 = totalhrs - da1;
				totalremainingstoryhr.add(da3);
				
				/*if(i1==0){
				totalremainingstory.add(totalstory.get(totalstory.size()-1));
				System.out.println("totalstory.get(totalstory.size()-1) is:"+totalremainingstory);
				}*/
				totalremainingstory.add(da2); //(da-totalstory.get(i1))
				System.out.println("totalremainingstory val:"+totalremainingstory);
				//"+al.get(0));
			}
		 }
	    
	    
	    if(startdatefinal!=null && enddatefinal!=null && val==true){
	     //}
	    
		 if (startdatefinal.compareTo(currentday) <= 0 && enddatefinal.compareTo(currentday) >=0 ) {
			 JSONObject finalResponse = new JSONObject();
		    	// finalResponse.put("Upcoming Release Ver",name);
			 /*finalResponse.put("Date",strDate1+"-"+enddate);
		    	 finalResponse.put("Release",sequence);
		    	 finalResponse.put("StartDate",strDate2);  //strDate2
	    	     finalResponse.put("Enddate",strDate3);   	    	       	     
	    	     finalResponse.put("donestory", donestory);	    	     
	    	     finalResponse.put("totalremainingstoryhr", totalremainingstoryhr);*/
			 	int b = totalremainingstoryhr.size();
			 	 double a =0.0;
			 	if(b==0){
			 		a =0.0;
			 	}else{
			 	a = totalremainingstoryhr.get(0);
			 	}
			 	 finalResponse.put("totalstoryhr", a);
			 	 //finalResponse.put("totalbughrs", bugs*6);
			 	// finalResponse.put("bvalhr", bvalhr);
			 	 finalResponse.put("totalbughr", totalbug*6);
		    }
		 else {
		        System.out.println("no release date is there");
		        int r=0;
		        JSONObject finalResponse = new JSONObject();
		    }	 		 
	     }
	     else{
	     JSONObject finalResponse = new JSONObject();
		 String a = "missing";
		 System.out.println("no current release setup is:"+a);
		 finalResponse.put("no current release setup",a);
		 //finalResponse.put("Release",seq);
		 System.out.println("Output from Server .... \n" + finalResponse);
		 client.destroy();
		 return Response.status(200).entity(finalResponse.toString()).build();					 
	     }
	     
		 JSONObject finalResponse = new JSONObject();
		 
		 if(val==true && relstrdt1!=null && relenddate!=null && enddt1!=null && strdt1!=null ){
		    	
		/* finalResponse.put("Date",relstrdt1+"-"+relenddate); // strDate1+"-"+enddate
    	 finalResponse.put("Release",seq); //sequence
    	 finalResponse.put("StartDate",strdt1);  //strDate2  //strDate2
	     finalResponse.put("Enddate",enddt1); //strDate3
*/	    if(nofinalvallen>0){
	     /*finalResponse.put("donestory", donestory);
	     finalResponse.put("totalremainingstoryhr", totalremainingstoryhr);*/
	     double a =totalremainingstoryhr.get(0);
	 	 finalResponse.put("totalstoryhr", a);
	 	 //finalResponse.put("totalbughrs", bugs*6);
	 	 //finalResponse.put("bvalhr", bvalhr);
	 	 finalResponse.put("totalbughr", totalbug*6);
	    }
	    else{
	    	int r=0;
	    	WebResource webResource16 = client
					.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId="+ rid +"&selectedProjectKey="+ projectKey +"");
			ClientResponse response16 = webResource16.header("Content-Type", "application/json").header("Cookie", authStringEnc).get(ClientResponse.class);
			String respStr16 = response16.getEntity(String.class);
			System.out.println("Response " + response16);
			System.out.println("ResponseStr " + respStr16);
			JSONObject ob16;
			ob16 = new JSONObject(respStr16);
			JSONArray issues16 = (JSONArray) ob16.get("issues");
			//1453 to 1488
			for(int i16=0;i16<issues16.length();i16++){
				
			    JSONObject value16 = (JSONObject) issues16.get(i16);			
				Map  statusName = new HashMap<String, String>();			
				Map  typeName = new HashMap<String, String>();								
				if((value16.getString("typeName").equals("Story"))){				
					String key = (String) value16.get("key");
					
					if(!allstory.containsKey(key)){
					allstory = getDefaultMap(key, allstory);
					
					System.out.println("allstory is:" +allstory);				
					System.out.println("key is:"+key);
					
					JSONObject estimateStatistic16 = (JSONObject) value16.get("estimateStatistic");
					JSONObject statFieldValue16 = (JSONObject) estimateStatistic16.get("statFieldValue");
					if(statFieldValue16.has("value")){
						bval = (Double) statFieldValue16.get("value");
						
						obval +=  bval;
						
						System.out.println("overallval is :"+obval);
					}
					}									
				}				
				if(value16.getString("statusName")!=("Done")&&(value16.getString("typeName").equals("Bug"))){				
					String key = (String) value16.get("key");		
					if(!allstory.containsKey(key)){
						allstory = getDefaultMap(key, allstory);
						
						System.out.println("allstory is:" +allstory);				
						System.out.println("key is:"+key);
						
						JSONObject estimateStatistic16 = (JSONObject) value16.get("estimateStatistic");
						JSONObject statFieldValue16 = (JSONObject) estimateStatistic16.get("statFieldValue");
						if(statFieldValue16.has("value")){
							bvals = (Double) statFieldValue16.get("value");
							
							bvalss +=  bvals;
							
							System.out.println("overallval is :"+obval);
						}
						}
				} // added for bug								
			}
			
			System.out.println("obval:"+obval);
			totalhrs = obval * 6;
			System.out.println("obval:"+obval);
			System.out.println("totalhrs:"+totalhrs);
			
			double dsfr = 0;
			donestory.add(dsfr);
			totalremainingstoryhr.add(totalhrs);
			
			bvalhr = bvalss * 6 ;
			
			JSONArray sprints16 = (JSONArray) ob16.get("sprints");
			
			for(int s16=0;s16<sprints16.length();s16++){
				
				JSONObject svalue16 = (JSONObject) sprints16.get(s16);
				String sprintname = (String) svalue16.get("name");
				System.out.println("sprint name:"+sprintname);
			
				if(!namefinals.contains(sprintname)){
					namefinals.add(sprintname);
					System.out.println("name val for planned story:"+namefinals);
				}
				
				//containsKey

				//
			}
	    	/*finalResponse.put("Date",relstrdt1+"-"+relenddate); // strDate1+"-"+enddate
	    	finalResponse.put("Release",seq); //sequence
	    	finalResponse.put("StartDate",strdt1);  //strDate2  //strDate2
		    finalResponse.put("Enddate",enddt1);   
		    finalResponse.put("name value", namefinals);		    
		    finalResponse.put("donestory", donestory);
		    finalResponse.put("totalremainingstoryhr", totalremainingstoryhr);*/
			 double a =totalremainingstoryhr.get(0);
		 	 finalResponse.put("totalstoryhr", a);
		 	 //finalResponse.put("totalbughrs", bugs*6);
		 	 //finalResponse.put("bvalhr", bvalhr);
		 	 finalResponse.put("totalbughr", totalbug*6);
		 	 //finalResponse.put("totalbug", bughr);
		 	 
	    	//finalResponse.put("Release date are available no sprint started yet", r);
	    	//finalResponse.put("no release date is there",r); 
	        System.out.println("Output from Server .... \n" + finalResponse);
			client.destroy();
			return Response.status(200).entity(finalResponse.toString()).build();
	    }
		 }
		 
		 else{
			// 
			 int r1=0;
		    	finalResponse.put("Release date are not available no sprint started yet", r1);
		    	//finalResponse.put("no release date is there",r1);  
		        System.out.println("Output from Server .... \n" + finalResponse);
				client.destroy();
				return Response.status(200).entity(finalResponse.toString()).build();
		 }
		System.out.println("Output from Server .... \n" + finalResponse);
		client.destroy();
		//return Response.status(200).entity(output.toString()).header("Content-Type", "application/text").build();
		return Response.status(200).entity(finalResponse.toString()).build();
	}

	private HashMap<String, Boolean> getDefaultMap(String key, HashMap<String, Boolean> allstory) {
		// TODO Auto-generated method stub
		return allstory;
	}
	// 
	
}
