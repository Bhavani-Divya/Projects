package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/getsprintburntdownvalues")

public class JIRAserviceBoardsECDSsprints {
	@GET
	@Path("/{rapidViewId}/{sprintID}")

	public Response getjssoap(@PathParam("rapidViewId") String rapidViewId, @PathParam("sprintID") String sprintID,
			@Context HttpHeaders headers) throws JSONException {

		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {

			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		WebResource webResource = client.resource(
				"https://agilectb.atlassian.net/rest/greenhopper/1.0/rapid/charts/scopechangeburndownchart.json?rapidViewId="
						+ rapidViewId + "&sprintId=" + sprintID + "&statisticFieldId=field_customfield_10200&_="
						+ timestamp.getTime());// rapidViewId=15 &sprintId=143
		double tns = 0;
		double tns1 = 0;
		double ncs = 0;
		double planDoval = 0;
		double overallProgressval = 0;
		double planDoval1 = 0;
		String expComp = null;
		double actualvelocity = 0;
		double date = 0;
		double today = 1;
		double expComp1 = 0;
		ClientResponse response = webResource.header("Content-Type", "application/json")
				.header("Cookie",authStringEnc).get(ClientResponse.class);
		String responseString = response.getEntity(String.class);
		JSONObject objResponseString;
		objResponseString = new JSONObject(responseString);
		JSONObject changes = (JSONObject) objResponseString.get("changes");
		long startTime = (Long) objResponseString.get("startTime");
		Timestamp startTimeStamp = new Timestamp(startTime);
		new Date(startTimeStamp.getTime());
		SimpleDateFormat format = new SimpleDateFormat("dd/MMM/yyyy HH:mm aa");
		format.format(startTimeStamp);
		long endTime = (Long) objResponseString.get("endTime");
		Timestamp endTimeStamp = new Timestamp(endTime);
		new Date(endTimeStamp.getTime());
		SimpleDateFormat format1 = new SimpleDateFormat("dd/MMM/yyyy HH:mm aa");
		format1.format(endTimeStamp);
		double time = endTime - startTime;
		int days = (int) Math.ceil(time / (24 * 60 * 60 * 1000));
		date = days;
		JSONArray keys = null;
		HashMap<String, Boolean> planDo = new HashMap<String, Boolean>();
		HashMap<String, Boolean> overallProgress = new HashMap<String, Boolean>();
		HashMap<String, Boolean> doneFlag = new HashMap<String, Boolean>();

		for (String key : changes.keySet()) {
			String keyName = (String) key;
			long key_intger = Long.parseLong(keyName);
			keys = changes.getJSONArray(key);
			for (int i = 0; i < keys.length(); i++) {
				JSONObject column = (JSONObject) keys.get(i);
				String keys1 = column.getString("key");
				planDo = getDefaultMap(keys1, planDo);
				overallProgress = getDefaultMap(keys1, overallProgress);
				doneFlag = getDefaultMap(keys1, doneFlag);
				if (column.has("column")) {
					JSONObject objColumn = column.getJSONObject("column");
					if (objColumn.has("done")) {
						Boolean done = objColumn.getBoolean("done");
						if (done.equals(true) && doneFlag.containsKey(keys1) && !doneFlag.get(keys1)) {
							System.out.println("NCS incremented...");
							ncs++;
							doneFlag.put(keys1, true);
						} else if (done.equals(false) && doneFlag.containsKey(keys1) && doneFlag.get(keys1)
								|| !doneFlag.get(keys1)) {
							System.out.println("NCS decremented...");
							ncs--;
							doneFlag.put(keys1, false);
						}
					}
				}
				if (column.has("added")) {
					Boolean added = column.getBoolean("added");
					if (key_intger <= startTime) {
						if (added && planDo.containsKey(keys1) && !planDo.get(keys1)) {
							System.out.println("TNSS incremented...");
							tns1++;
							planDo.put(keys1, true);
						}
					}
					if (added && overallProgress.containsKey(keys1) && !overallProgress.get(keys1)) {
						System.out.println("TNS incremented...");
						tns++;
						overallProgress.put(keys1, true);
					}
				}
			}
			System.out.println(keyName + " = " + keys);
		}
		double previousNcs = 0;
		double previousDate = 0;
		Response list = new JIRAserviceGetSprints().getSprints(rapidViewId, headers);
		JSONObject objSprintsList = new JSONObject(list);
		JSONObject objEntity = new JSONObject(objSprintsList.getString("entity"));
		JSONArray sprints = objEntity.getJSONArray("sprints");
		for (int j = 0; j < sprints.length(); j++) {
			JSONObject sprintscolumn = (JSONObject) sprints.get(j);
			boolean state = sprintscolumn.getString("state").equals("ACTIVE");
			Integer id = (Integer) sprintscolumn.get("id");
			int previousSprintId = sprints(j, id, id, sprints);
			if (sprintID.equals(id.toString())) {
				if (previousSprintId > 0) {
					WebResource webResource1 = client.resource(
							"https://agilectb.atlassian.net/rest/greenhopper/1.0/rapid/charts/scopechangeburndownchart.json?rapidViewId="
									+ rapidViewId + "&sprintId=" + previousSprintId
									+ "&statisticFieldId=field_customfield_10200&_=" + timestamp.getTime());// rapidViewId=15
																											// &sprintId=143
					ClientResponse response1 = webResource1.header("Content-Type", "application/json")
							.header("Cookie",authStringEnc).get(ClientResponse.class);
					String responseString1 = response1.getEntity(String.class);
					JSONObject objResponseString1;
					objResponseString1 = new JSONObject(responseString1);
					JSONObject changes1 = (JSONObject) objResponseString1.get("changes");
					JSONArray keys1 = null;
					HashMap<String, Boolean> previousPlanDo = new HashMap<String, Boolean>();
					HashMap<String, Boolean> previousOverallProgress = new HashMap<String, Boolean>();
					HashMap<String, Boolean> previousDoneFlag = new HashMap<String, Boolean>();
					for (Object key1 : changes1.keySet()) {
						String keyName1 = (String) key1;
						Long.parseLong(keyName1);
						keys1 = changes1.getJSONArray(keyName1);

						for (int k = 0; k < keys1.length(); k++) {
							JSONObject column1 = (JSONObject) keys1.get(k);
							String keys2 = column1.getString("key");
							previousPlanDo = getDefaultMap(keys2, previousPlanDo);
							previousOverallProgress = getDefaultMap(keys2, previousOverallProgress);
							previousDoneFlag = getDefaultMap(keys2, previousDoneFlag);
							long previousstartTime = (Long) objResponseString1.get("startTime");
							Timestamp startTimeStamp1 = new Timestamp(previousstartTime);
							Date startDate = new Date(startTimeStamp1.getTime());
							new SimpleDateFormat("dd/MMM/yyyy HH:mm aa");
							System.out.println(format.format(startTimeStamp1));
							System.out.println(format.format(startDate));
							format.format(startTimeStamp1);
							long previousEndTime = (Long) objResponseString1.get("endTime");
							Timestamp endTimeStamp1 = new Timestamp(previousEndTime);
							Date endDate = new Date(endTimeStamp1.getTime());
							SimpleDateFormat format4 = new SimpleDateFormat("dd/MMM/yyyy HH:mm aa");
							System.out.println(format4.format(endTimeStamp1));
							System.out.println(format4.format(endDate));
							format4.format(endTimeStamp1);
							System.out.println(endDate.compareTo(startDate));
							double previousTime = previousEndTime - previousstartTime;
							int previousDays = (int) Math.ceil(previousTime / (24 * 60 * 60 * 1000));
							previousDate = previousDays;
							System.out.print("date" + date + " days ");
							if (column1.has("column")) {
								JSONObject objColumn1 = column1.getJSONObject("column");
								if (objColumn1.has("done")) {
									Boolean done = objColumn1.getBoolean("done");
									if (done.equals(true) && previousDoneFlag.containsKey(keys2)
											&& !previousDoneFlag.get(keys2)) {
										System.out.println("NCS incremented...");
										previousNcs++;
										previousDoneFlag.put(keys2, true);
										System.out.println("previousNcs" + previousNcs);
									} else {
										System.out.println("done is" + column1);
									}
								}
							}
						}
					}
				} else {
					previousNcs = ncs;
					previousDate = date;

				}
				System.out.println("sprintID" + sprintID + "id" + id);

				if (state == true) {
					return JIRAserviceBoardsECDSsprints.Active(ncs, tns, tns1, today, planDoval, overallProgressval,
							expComp1, expComp, actualvelocity, date, previousNcs, previousDate);

				}

				else if (state == false) {

					return JIRAserviceBoardsECDSsprints.closed(ncs, tns, tns1, today, planDoval, overallProgressval,
							expComp1, expComp, actualvelocity, date, planDoval1, previousNcs, previousDate);

				}
				previousSprintId = id;
			}
		}
		return null;
	}

	public static int sprints(int j, int id, int currentSprintid, JSONArray sprints) {
		if (id == currentSprintid && j == 0) {
			return 0;
		} else if (id == currentSprintid) {
			int prevArrayval = j - 1;
			JSONObject newcolumn = (JSONObject) sprints.get(prevArrayval);
			boolean state = newcolumn.getString("state").equals("ACTIVE");
			System.out.println("state" + state);
			Integer previd = (Integer) newcolumn.get("id");
			return previd;
		} else {
			return 0;
		}
	}

	public static Response Active(double ncs, double tns, double tns1, double today, double planDoval,
			double overallProgressval, double expComp1, String expComp, double actualvelocity, double date,
			double previousNcs, double previousDate) {

		System.out.println("Before: " + " ncs: " + ncs + " tns: " + tns + " tns1: " + tns1 + " today: " + today
				+ "planDoval11: " + planDoval + " oap: " + overallProgressval + " expComp1: " + expComp1 + " expComp: "
				+ expComp + " actualvelocity: " + actualvelocity + " date: " + date + " previousNcs: " + previousNcs
				+ " previousDate: " + previousDate);
		double expCompR;
		String expCompS;
		double rs = 0;

		overallProgressval = Math.round((ncs * 100) / tns);
		if (previousNcs > 0 && previousDate > 0) {
			actualvelocity = (previousNcs / previousDate);
		} else {
			actualvelocity = (previousNcs / previousDate);
		}

		rs = (tns - ncs) / actualvelocity;

		expComp1 = 1 + rs;
		expCompR = Math.round(expComp1);

		if (expCompR < 10) {
			expCompS = "0" + String.valueOf(expCompR);
		} else {
			expCompS = String.valueOf(expCompR);
		}

		String str = expCompS.substring(0, 2);
		expComp = str;
		JSONObject finalResponse = new JSONObject();
		double planDoval1 = 0.0;
		System.out.println("After: " + " ncs: " + ncs + " tns: " + tns + " tns1: " + tns1 + " today: " + today
				+ "planDoval11: " + planDoval + " oap: " + overallProgressval + " expComp1: " + expComp1 + " expComp: "
				+ expComp + " actualvelocity: " + actualvelocity + " date: " + date + " previousNcs: " + previousNcs
				+ " previousDate: " + previousDate);
		System.out.println("From Active Method  - Expected Completion: " + expComp + " Plan-Do: " + planDoval1
				+ " Overall Progress: " + overallProgressval); // Newly added
		finalResponse.put("planDoval1", planDoval1); // Plan-Do
		finalResponse.put("oap", overallProgressval); // Overall Progress
		finalResponse.put("expComp", expComp); // Expected Completion
		return Response.status(200).entity(finalResponse.toString()).build();

	}

	public static Response closed(double ncs, double tns, double tns1, double today, double planDoval,
			double overallProgressval, double expComp1, String expComp, double actualvelocity, double date,
			double planDoval1, double previousNcs, double previousDate) {
		double rs = 0;
		double expCompR;
		String expCompS;

		if (tns1 == 0) {
			planDoval1 = 0;
		} else {
			planDoval = (ncs / tns1) * 100;
		}
		if (planDoval >= 100) {
			planDoval = 100;
		}
		planDoval1 = Math.round(planDoval);
		overallProgressval = Math.round((ncs * 100) / tns);
		if (previousNcs > 0 && previousDate > 0) {
			actualvelocity = (previousNcs / previousDate);
		} else {

			actualvelocity = (ncs / date);
		}

		rs = (tns - ncs) / actualvelocity;
		System.out.println("rs" + rs);
		expComp1 = 1 + rs;

		expCompR = Math.round(expComp1);

		if (expCompR < 10) {

			expCompS = "0" + String.valueOf(expCompR);
		} else {
			expCompS = String.valueOf(expCompR);

		}

		System.out.println("expComps " + expCompS);
		expCompS.substring(0, 2);
		expComp = "00";
		System.out.println("From Closed Method  - Expected Completion: " + expComp + " Plan-Do: " + planDoval1
				+ " Overall Progress: " + overallProgressval); // Newly added
		JSONObject finalResponse = new JSONObject();
		finalResponse.put("oap", overallProgressval); // Plan-Do
		finalResponse.put("planDoval1", planDoval1); // Overall Progress
		finalResponse.put("expComp", expComp); // Expected Completion

		return Response.status(200).entity(finalResponse.toString()).build();

	}

	private HashMap<String, Boolean> getDefaultMap(String keyss, HashMap<String, Boolean> flagMap) {
		if (flagMap.containsKey(keyss)) {
			return flagMap;
		} else {
			flagMap.put(keyss, false);
		}
		return flagMap;
	}

	public static void main(String[] args) {
		int diffDays = (int) Math.ceil(1209600000 / (24 * 60 * 60 * 1000));
		double db = 1209600000;
		System.out.println(db);
		System.out.println("Time is:" + diffDays);

		String s = "20";
		System.out.println("substring: " + s.substring(0, 2));
	}
}
