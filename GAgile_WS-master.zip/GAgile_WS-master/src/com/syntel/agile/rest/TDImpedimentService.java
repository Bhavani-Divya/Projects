package com.syntel.agile.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/impediments")
public class TDImpedimentService {
	
	double impedimentsCount;
	@GET
	@Path("/{teamId}/{projectKey}")
	public Response getActiveTeamSpecificImpediments(@PathParam("teamId") String teamId, @PathParam("projectKey") String projectKey,
			@Context HttpHeaders headers) throws JSONException {
		
		Set<String> headerKeys = headers.getRequestHeaders().keySet(); // delete later as it's not used
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.err.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();
		WebResource webResource = client
				 .resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId="+ teamId + "&selectedProjectKey=" + projectKey + "");// 15 // AIEM
				/* .resource("http://172.25.46.172:8081/rest/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId="
						/+ teamId + "&selectedProjectKey=" + projectKey + ""); */

		ClientResponse response = webResource.header("Content-Type", "application/json")
				.header("Cookie",authStringEnc).get(ClientResponse.class);

		String impedimentID = null;
		String summary = null;
		String priorityName = null;
		boolean hasCustomUserAvatar;
		String assigneeName = null;
		String statusName = null;
		String colorName = null;
		String creator = null;
		String versionName = null;
		List<JSONObject> finalResponselist = new ArrayList<>();
		//JSONObject finalResponse = null;
		//JSONObject finalResponse1 = null;
		String errorMsg = "There are no impediments associated with this team";
		String fixVersionsMsg = "None";
		//double impediment = 0;

		String respStr = response.getEntity(String.class);
		System.out.println("Response: " + response);
		System.out.println("ResponseStr: " + respStr);

		JSONObject ob;
		ob = new JSONObject(respStr);
		System.out.println("ResponseStr Obj: " + ob);

		JSONArray issues = (JSONArray) ob.get("issues");
		System.out.println("Issues: " + issues);

		for (int k = 0; k < issues.length(); k++) {
			JSONObject value;
			value = (JSONObject) issues.get(k);
			//System.out.println("Value: " + value); No need to print
			HashMap<String, String> bugss = new HashMap<String, String>(); // delete later as it's not used
			
			String typeName = (String) value.get("typeName");
			System.out.println("TypeName: " + typeName);
			
			Boolean done = (Boolean) value.get("done");
			System.out.println("Done: " + done);

			if ((typeName.equals("Impediment")) && (done.equals(false))) {
				System.out.println("Inside IF LOOP");
				
				impedimentsCount++;
				impedimentID = (String) value.get("key"); // key:AIEM-199
				summary = value.getString("summary");
				priorityName = value.getString("priorityName"); // priorityName:Medium
				hasCustomUserAvatar = value.getBoolean("hasCustomUserAvatar");
				
				if (hasCustomUserAvatar) {
					assigneeName = value.getString("assigneeName");
				} else {
					assigneeName = "Unassigned"; // Unknown or Issue yet to assigned or Yet to assign
				}

				statusName = value.getString("statusName"); // statusName:To Do
				// String statusColor = value.getString("status");
				JSONObject status = value.getJSONObject("status");
				JSONObject statusCategory = status.getJSONObject("statusCategory");
				colorName = statusCategory.getString("colorName"); // colorName:yellow

				// System.out.println("Output from Server .... \n" + finalResponselist);
			} else if (impedimentsCount == 0 && !((typeName.equals("Bug")) || (typeName.equals("Story") || (typeName.equals("Task"))))) { // Add typeName = !Bug && !Story && !Task with impediment == 0
				JSONObject finalResponse1 = new JSONObject();
				finalResponse1.put("errorMsg", errorMsg);
				finalResponselist.add(finalResponse1);
				//System.out.println("There are no impediments associated with this team");
			}
		}
		
		// ---Start - Another API used
		WebResource webResourceBoardDetails = client
				.resource("https://agilectb.atlassian.net/rest/agile/latest/board/" + teamId + "/issue");
				// .resource("http://172.25.43.200:8081/rest/agile/latest/board/" + teamId + "/issue");
					
		ClientResponse responseBoardDetails = webResourceBoardDetails
				.header("Content-Type", "application/json").header("Cookie",authStringEnc).get(ClientResponse.class);
					
		String responseBoard = responseBoardDetails.getEntity(String.class);
		JSONObject object = new JSONObject(responseBoard);
		JSONArray issuearray = object.getJSONArray("issues");
					
		for (int j = 0; j < issuearray.length(); j++) {
			JSONObject row = (JSONObject) issuearray.get(j);
			JSONObject fieldsJson = row.getJSONObject("fields");
			System.out.println(fieldsJson);

			JSONObject issuetypeJson = fieldsJson.getJSONObject("issuetype");
			if ((issuetypeJson.getString("name").equals("Impediment"))) {
				JSONArray fixedVersion = fieldsJson.getJSONArray("fixVersions");
				creator = fieldsJson.getString("created");

				for (int l = 0; l < fixedVersion.length(); l++) {
					JSONObject versionNameRow = (JSONObject) fixedVersion.get(l);
					versionName = (String) versionNameRow.get("name");
					if (versionName.length() == 0) {
						versionName = "None";
					}
					System.out.println("versionName is:" + versionName);
				}
			}
		}
		// ---END - Another API used
						
		JSONObject finalResponse = new JSONObject();
		finalResponse.put("impedimentID", impedimentID);
		finalResponse.put("assigneeName", assigneeName);
		finalResponse.put("summary", summary); // Description

		finalResponse.put("openedSince", creator); // e.g.- 10/30/2018
		finalResponse.put("release", versionName); // version/release e.g.- 2018-03
		
		finalResponse.put("severity", priorityName);
		finalResponse.put("statusName", statusName);
		finalResponse.put("statusColor", colorName);
		finalResponse.put("impedimentsCount", impedimentsCount);

		finalResponselist.add(finalResponse);
		System.out.println("Output from Server: " + finalResponselist);

		client.destroy();

		return Response.status(200).entity(finalResponselist.toString()).header("Content-Type", "application/json").build();
	}
	

}
