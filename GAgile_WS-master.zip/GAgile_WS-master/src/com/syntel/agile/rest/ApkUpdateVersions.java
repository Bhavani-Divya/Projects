package com.syntel.agile.rest;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.apache.poi.util.IOUtils;

@Path("/apkUpdate")
public class ApkUpdateVersions {

	@GET
	@Path ("/download")
	public Response getApkUpdateChangeLog(@Context HttpHeaders headers) {
		System.out.println("Start");
		String output = "ChangeLog";
		FileInputStream fis= null;
	
		try {
			fis = new FileInputStream(System.getProperty("catalina.base")+File.separator+"GAgileFiles"+File.separator+"GAgile.apk");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 byte[] entity=null;
		try {
			entity = IOUtils.toByteArray(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return Response.status(Response.Status.OK)
            .entity(entity)
            .header("Content-Disposition", "attachment; filename=\"GAgile.apk\"")
            .build();
			//Response.status(200).entity(output.toString()).header("Content-Type", "application/json").build(); 
	}
}
