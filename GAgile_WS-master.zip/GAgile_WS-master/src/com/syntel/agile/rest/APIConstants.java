package com.syntel.agile.rest;

public class APIConstants {
	/*
	 * APIConstants class in intentionally created to store JIRA API's at one place
	 * using constant variables. Later on whenever any changes in the API's, you can
	 * make at one single place.
	 */

	// IssueTypes:
	public static final String IMPEDIMENTS = "Impediment";
	public static final String BUGS = "Bug";
	public static final String STORIES = "Story";

	// Issue Assigned/Unassigned Status:
	public static final String UNASSIGNED = "Unassigned";
	public static final String NONE = "None";
}
