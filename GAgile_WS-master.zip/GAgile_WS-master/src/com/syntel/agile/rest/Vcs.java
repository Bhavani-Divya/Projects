package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

class Vc {
	String sprintname;
	double comval;
	double val;

	public Vc(String sprintname, double val, double comval) {
		super();
		this.sprintname = sprintname;
		this.val = val;
		this.comval = comval;

	}

	public void setSprintname(String sprintname) {
		this.sprintname = sprintname;
	}

	public void setVal(double val) {
		this.val = val;
	}

	public void setComval(double comval) {
		this.comval = comval;
	}

	public String toString() {
		return "VelocityDetail [sprintname=" + sprintname + ", esti=" + val + ",compl=" + comval + "]";
	}

	void display() {
		System.out.println(sprintname + " " + val + " " + comval); // + " " + key
	}
}

@Path("/vcs")

public class Vcs {

	@GET
	@Path("/{rapidViewId}")
	public static Response getjssoap(@PathParam("rapidViewId") String rapidViewId, @Context HttpHeaders headers)
			throws JSONException {

		headers.getRequestHeaders().keySet();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
		}
		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();
		new Timestamp(System.currentTimeMillis());
		WebResource webResource = client
				.resource("https://agilectb.atlassian.net/rest/greenhopper/1.0/rapid/charts/velocity.json?rapidViewId="
						+ rapidViewId);// repidViewId=15
		ClientResponse response = webResource.header("Content-Type", "application/json")
				.header("Cookie",authStringEnc).get(ClientResponse.class);

		String responseString = response.getEntity(String.class);
		JSONObject objResponseString = new JSONObject(responseString);

		// Vc VelocityDetail
		List<Vc> VelocityDetailList = new LinkedList<Vc>();
		GsonBuilder gsonBuilder = new GsonBuilder();
		Gson gson = gsonBuilder.create();

		JSONArray sprints = (JSONArray) objResponseString.get("sprints");
		JSONObject velocityStatEntries = (JSONObject) objResponseString.get("velocityStatEntries");
		int sprintslength = sprints.length();
		System.out.println("sprintslength" + sprintslength);
		List<Integer> listSprintId = new ArrayList<Integer>();
		List<Double> estimated = new ArrayList<Double>();
		List<Double> completed = new ArrayList<Double>();
		List<String> listSprintName = new ArrayList<String>();
		String sprintname = "null";
		Double estimatedValue = 0.0;
		Double completedvalue = 0.0;

		if (sprintslength != 0) {

			for (int i = 0; i < sprintslength; i++) {
				JSONObject sprint = (JSONObject) sprints.get(i);
				String name = (String) sprint.get("name");
				String[] words = name.split("\\s");

				for (String w1 : words) {
					System.out.println(w1);
					sprintname = w1;

				}

				listSprintName.add(sprintname);
				Integer id = (Integer) sprint.get("id");
				listSprintId.add(id);
				String idstr = String.valueOf(id);

				JSONObject idval = velocityStatEntries.getJSONObject(idstr);
				JSONObject objEstimated = (JSONObject) idval.get("estimated");
				for (int j = 1; j < objEstimated.length(); j++) {
					estimatedValue = (Double) objEstimated.get("value");
					estimated.add(estimatedValue);
				}
				JSONObject objCompleted = (JSONObject) idval.get("completed");
				for (int k = 1; k < objCompleted.length(); k++) {
					completedvalue = (Double) objCompleted.get("value");
					completed.add(completedvalue);
				}

				// VelocityDetail
				Vc VelocityDetail1 = new Vc(sprintname, estimatedValue, completedvalue);
				VelocityDetailList.add(VelocityDetail1);
				System.out.println("VelocityDetailList" + VelocityDetailList);
				System.out.println("JSON Object List " + gson.toJson(VelocityDetailList));
			}

			JSONObject finalResponse = new JSONObject();
			finalResponse.put("Sprint name", listSprintName);
			finalResponse.put("Estimated value", estimated);
			finalResponse.put("Completed value", completed);
			return Response.status(200).entity(gson.toJson(VelocityDetailList).toString()).build();
		}

		else {
			JSONObject finalResponse = new JSONObject();
			JSONArray finalResponse1 = new JSONArray();
			String empty = "empty";
			finalResponse.put("No Velocity is not available", empty);
			finalResponse1.put(finalResponse);
			return Response.status(200).entity(finalResponse1.toString()).build();
		}

	}

}
