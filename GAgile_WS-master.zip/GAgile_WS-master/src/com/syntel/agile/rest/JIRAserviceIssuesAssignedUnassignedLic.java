package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/gettotalassignedUnassigned")

public class JIRAserviceIssuesAssignedUnassignedLic {

	@GET
	@Path("/{projkey}/{bordid}")
	public Response getTotalStoryPointsIssues(@PathParam("projkey") String projectKey,
			@PathParam("bordid") String boardId, @Context HttpHeaders headers) throws ParseException {
		long totalUnassigned = 0;
		long totalAssignedcount = 0;
		float tempunassigneeStoryPoints = 0;
		float tempassigneeStoryPoints = 0;

		double tempStoryPoints = 0;
		Date releaseD = null;
		long totalWorkedDays = 0;
		int totalDays = 0;
		Date currentDate1 = null;
		Date startDate = null;

		Date releaseDate = null;
		String responseReleaseDateValue = null;
		String responseStartDateValue = null;
		Calendar startCalDate;
		Calendar currentCalDate;
		Calendar endCalDate;
		startCalDate = Calendar.getInstance();
		endCalDate = Calendar.getInstance();
		currentCalDate = Calendar.getInstance();
		String currentnewDate = null;
		String currentDate = null;
		List<String> collectingList = new ArrayList<String>();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {

			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
		}

		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String authStringEnc = credentialMap.get("Cookie");
		ArrayList<JSONObject> finalResponselist = new ArrayList<>();
		System.out.println("authorisation-----" + authStringEnc);
		Client client = Client.create();

		WebResource webResource1 = client.resource("https://agilectb.atlassian.net/rest/projects/1.0/project/"
				+ projectKey + "/release/allversions?_=" + timestamp.getTime());
		ClientResponse response1 = webResource1.header("Content-Type", "application/json")
				.header("Cookie",authStringEnc).get(ClientResponse.class);

		String responseString = response1.getEntity(String.class);
		JSONArray responseJsonObjArray = new JSONArray(responseString);
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date dateobj = new Date();
		System.out.println(dateFormat.format(dateobj));// 2019-05-10

		currentDate = dateFormat.format(dateobj);

		currentDate1 = dateFormat.parse(currentDate);
		currentCalDate.setTime(currentDate1);
		currentnewDate = new SimpleDateFormat("MM-dd-yy").format(currentDate1);
		ArrayList<String> final3 = new ArrayList<>();
		final3.add(currentnewDate);
		for (int q = 0; q < responseJsonObjArray.length(); q++) {

			JSONObject responseJsonObjrow = (JSONObject) responseJsonObjArray.get(q);
			JSONObject responseStartDate = (JSONObject) responseJsonObjrow.get("startDate");
			if (!(responseStartDate.getString("iso").length() == 0)) {
				responseStartDateValue = responseStartDate.getString("iso");
				// responseStartDateValue="2018-03-22"

				System.out.println(responseStartDateValue);
				System.out.println(startDate);
				startDate = dateFormat.parse(responseStartDateValue);
				new SimpleDateFormat("MM-dd-yy").format(startDate);
				// Just changing the format "startingDate"
				startCalDate.setTime(startDate);
				System.out.println(startCalDate);

				System.out.println(responseStartDateValue);
				JSONObject responsereleaseDate = (JSONObject) responseJsonObjrow.get("releaseDate");
				responseReleaseDateValue = responsereleaseDate.getString("iso");
				System.out.println(responseReleaseDateValue);
				releaseDate = dateFormat.parse(responseReleaseDateValue);
				new SimpleDateFormat("MM-dd-yy").format(releaseDate);
				endCalDate.setTime(releaseDate);
				System.out.println(releaseDate);

				System.out.println(responseReleaseDateValue);

				if (startDate.before(currentDate1) && releaseDate.after(currentDate1)
						|| releaseDate.equals(currentDate1)) {
					if (startDate.before(currentDate1) && releaseDate.after(currentDate1)
							|| releaseDate.equals(currentDate1)) {

						releaseD = releaseDate;

						totalDays = (int) (totalDays + totalWorkedDays);
						System.out.println("TotalDays Are:" + totalDays);
					}
					break;
				} else {
					System.out.println("There id no current Relesase");

				}

			}

			else {
				System.out.println("Please Enter the Start Date");

			}
		}

		WebResource webResourceBoardDetails = client.resource("https://agilectb.atlassian.net/rest/agile/1.0/board/"
				+ boardId + "/issue?jql=Project=" + projectKey + "&startAt=0&maxResults=2000");

		ClientResponse responseBoardDetails = webResourceBoardDetails.header("Content-Type", "application/json")
				.header("Cookie",authStringEnc).get(ClientResponse.class);

		System.out.println("responseBoardDetails O/P" + responseBoardDetails);
		String responseBoard = responseBoardDetails.getEntity(String.class);
		System.out.println("Response O/P" + responseBoard);
		JSONObject objResponseBoard = new JSONObject(responseBoard);
		JSONArray issuearray = objResponseBoard.getJSONArray("issues");
		System.out.println("IssueArray O/P" + issuearray);
		for (int j = 0; j < issuearray.length(); j++) {
			JSONObject zeroRow = (JSONObject) issuearray.get(j);
			JSONObject fields = zeroRow.getJSONObject("fields");
			String Key = (String) zeroRow.get("key");
			JSONObject issueType = (JSONObject) fields.get("issuetype");
			String issueTypeName = (String) issueType.get("name");

			if (fields.get("fixVersions") != null

					|| fields.getJSONArray("fixVersions") != null) {

				JSONArray newrFixedVersion = fields.getJSONArray("fixVersions");
				// 2018-06-08
				for (int s = 0; s < newrFixedVersion.length(); s++) {

					JSONObject zerorow1 = (JSONObject) newrFixedVersion.get(s);
					if (zerorow1.has("releaseDate")) {
						String newrzeroeportorfieldDate = (String) zerorow1.get("releaseDate");

						Date releaseDate1 = dateFormat.parse(newrzeroeportorfieldDate);
						Date dateobj1 = new Date();
						System.out.println(dateFormat.format(dateobj1));
						String a = dateFormat.format(dateobj1);
						dateFormat.parse(a);

						if (!collectingList.contains(Key)) {

							if (releaseDate1.equals(releaseD)) {

								if (issueTypeName.equals("Story")) {

									if (fields.has("customfield_10200")
											&& !fields.get("customfield_10200").equals(null)) {
										double storyPointJson = (double) fields.get("customfield_10200");

										tempStoryPoints = storyPointJson + tempStoryPoints;

									}

									if (fields.get("assignee").equals(null)) {

										if (fields.has("customfield_10200")
												&& !fields.get("customfield_10200").equals(null)) {
											double unassigneestoryPointJson = (double) fields.get("customfield_10200");

											tempunassigneeStoryPoints = (float) (unassigneestoryPointJson
													+ tempunassigneeStoryPoints);
											System.out.println("tempunassigneeStoryPoints" + tempunassigneeStoryPoints);

										}

									} else if (!fields.get("assignee").equals(null)) {
										if (fields.has("customfield_10200")
												&& !fields.get("customfield_10200").equals(null)) {
											double assigneestoryPointJson = (double) fields.get("customfield_10200");

											tempassigneeStoryPoints = (float) (assigneestoryPointJson
													+ tempassigneeStoryPoints);
											System.out.println("tempassigneeStoryPoints" + tempassigneeStoryPoints);
										}

									}

								}
							}
						}
					}
				}
			}

		}

		double totalUnassignedpercentage = ((tempunassigneeStoryPoints / tempStoryPoints) * 100);
		System.out.println("totalUnassigne" + totalUnassignedpercentage);
		totalUnassigned = Math.round(totalUnassignedpercentage);
		System.out.println("totalUnassigned" + totalUnassigned);

		double totalAssignedpercentage = ((tempassigneeStoryPoints / tempStoryPoints) * 100);
		System.out.println("totalAssignedcoun" + totalAssignedpercentage);
		totalAssignedcount = Math.round(totalAssignedpercentage);
		System.out.println("totalAssignedcount" + totalAssignedcount);
		JSONObject finalResponse = new JSONObject();
		finalResponse.put("unassignedcount", totalUnassigned + "%");
		finalResponse.put("assignedcount", totalAssignedcount + "%");
		finalResponse.put("storyPoinJson", tempStoryPoints);

		finalResponselist.add(finalResponse);
		return Response.status(200).entity(finalResponselist.toString()).header("Content-Type", "application/json")
				.build();

	}

}
