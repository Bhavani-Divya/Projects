package com.syntel.agile.rest;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/getimpedimentstablelic")

public class JIRAserviceIssuesImpedimentsButtonLic {

	@GET
	@Path("/{projkey}")
	public Response getTotalStoryPointsIssues(@Context HttpHeaders headers, @PathParam("projkey") String projectKey) {
		String summary = null;
		String teamName = null;
		String impid = null;
		String Errormsg = "There are no impediments";
		List<JSONObject> finalResponselist = new ArrayList<>();
		List<String> collectingList = new ArrayList<String>();
		new ArrayList<>();
		Client client = Client.create();

		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.out.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		WebResource webResource = client.resource(APIConstants.ServerName + APIConstants.ViewData);

		ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc)
				.get(ClientResponse.class);
		String responseString = response.getEntity(String.class);
		JSONObject ob = new JSONObject(responseString);
		JSONArray viewsArray = ob.getJSONArray("views");
		System.out.println("1Outside For loop");
		for (int i = 0; i < viewsArray.length(); i++) {
			System.out.println("1Inside For loop");
			JSONObject viewsRow = (JSONObject) viewsArray.get(i);
			System.out.println("viewsRow" + viewsRow);
			boolean projectFlag = (boolean) viewsRow.get("isSimpleQueryBoard");
			System.out.println("projFlag" + projectFlag);
			JSONObject filterProj = (JSONObject) viewsRow.get("filter");
			System.out.println("filterProj" + filterProj);
			JSONObject obb = new JSONObject(filterProj);
			System.out.println(obb);
			JSONObject queryProj = (JSONObject) filterProj.get("queryProjects");
			System.out.println("queryProj" + queryProj);
			JSONArray projectArray = (JSONArray) queryProj.getJSONArray("projects");
			System.out.println("projectArray" + projectArray);
			System.out.println("2outside For loop");

			for (int k = 0; k < projectArray.length();) {

				JSONObject projectRow = (JSONObject) projectArray.get(k);
				String projectRowKey = (String) projectRow.get("key");
				System.out.println("2Inside For loop");
				System.out.println("projRowKeyFinal" + projectRowKey);
				System.out.println("projkeyFinal" + projectKey);
				if (projectRowKey.equals(projectKey)) {
					System.out.println("Inside if loop");
					System.out.println("projRowKey is" + projectRowKey);
					System.out.println("Inside if loop");
					int boardId = viewsRow.getInt("id");// fetched boardId from the selected project
					System.out.println("id is" + boardId);

					WebResource webResourceBoardDetails = client.resource(APIConstants.ServerName
							+ APIConstants.LatestBoardID + boardId + APIConstants.IssueMaxResult500);// boardId=81
					ClientResponse responseBoardDetails = webResourceBoardDetails
							.header("Content-Type", "application/json").header("Cookie", authStringEnc)
							.get(ClientResponse.class);

					String responseBoard = responseBoardDetails.getEntity(String.class);
					JSONObject object = new JSONObject(responseBoard);
					JSONArray issueArray = object.getJSONArray("issues");

					for (int j = 0; j < issueArray.length(); j++) {
						JSONObject row = (JSONObject) issueArray.get(j);
						String newrzeroeportor = (String) row.get("key");

						JSONObject fieldsJson = row.getJSONObject("fields");
						System.out.println(fieldsJson);
						if (!collectingList.contains(newrzeroeportor)) {

							if (fieldsJson.get("resolution").equals(null)) {
								JSONObject finalResponse = new JSONObject();
								List<String> versionName = new ArrayList<String>();
								JSONObject issuetypeJson = fieldsJson.getJSONObject("issuetype");
								impid = row.getString("key");

								System.out.println("B4 loop JSONObject impid" + impid);

								// TODO - Start
								JSONObject projectObj = fieldsJson.getJSONObject("project");
								String projKey = (String) projectObj.get("key");
								String projName = (String) projectObj.get("name");

								System.out.println("Project Key: " + projKey + "Project Name: " + projName);

								if ((issuetypeJson.getString("name").equals("Impediment"))) {
									String ver = null;
									collectingList.add(newrzeroeportor);
									impid = row.getString("key");
									System.out.println("Inside loop JSONObject impid" + impid);

									if (fieldsJson.has("customfield_10703")
											&& !fieldsJson.get("customfield_10703").equals(null)) {
										JSONObject valuefield = fieldsJson.getJSONObject("customfield_10703");
										teamName = valuefield.getString("value");
									}
									summary = fieldsJson.getString("summary");
									String creator = fieldsJson.getString("created");

									JSONObject priority = fieldsJson.getJSONObject("priority");
									String priorityname = priority.getString("name");

									fieldsJson.getJSONObject("status");
									String statusname = priority.getString("name");

									JSONArray fixedVersion = fieldsJson.getJSONArray("fixVersions");

									if (fieldsJson.isNull("fixVersions")) {
										String none = "None";
										versionName.add(none);
									} else {
										for (int r = 0; r < fixedVersion.length(); r++) {
											JSONObject fixedVersionJSONObject = (JSONObject) fixedVersion.get(r);
											ver = fixedVersionJSONObject.getString("name");
											versionName.add(ver);
										}

									}
									finalResponse.put("impid", impid);
									finalResponse.put("description", summary);
									finalResponse.put("teamName", teamName);
									finalResponse.put("Release", versionName);
									finalResponse.put("openedsince", creator);
									finalResponse.put("severity", priorityname);
									finalResponse.put("status", statusname);

									finalResponselist.add(finalResponse);
									System.out.println("Final is:" + finalResponselist);

								}

							} else {
								JSONObject finalResponse = new JSONObject();
								finalResponse.put("Error msg", Errormsg);
								System.out.println("There are no impediments");
							}
						}

					}
				}

				break;
			}

		}
		return Response.status(200).entity(finalResponselist.toString()).header("Content-Type", "application/json")
				.build();
	}
}
