package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Collections;
import java.util.Comparator;
import java.util.Arrays;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/getReleaseBurnDownChart")
public class ReleaseBurnDownChart {

	@SuppressWarnings("unused")
	@GET
	@Path("/{ProjectKey}/{BoardId}/{ReleaseId}")
	public Response getSprintBurnDownChartValues(@PathParam("ProjectKey") String projectKey,
			@PathParam("BoardId") String rapidViewId, @PathParam("ReleaseId") String releaseID,
			@Context HttpHeaders headers) throws JSONException {
		org.json.JSONObject responseJson = new org.json.JSONObject();
		LinkedHashMap<String, Boolean> issuekey_booleanpair = new LinkedHashMap<String, Boolean>();

		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.out.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();

		System.out.println("Data Received: " + rapidViewId);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		System.out.println(timestamp.getTime());
		// boardId=15 projectKey=AIEM
		WebResource webResource1 = client.resource(APIConstants.ServerName + APIConstants.BacklogData + rapidViewId
				+ APIConstants.SelectedProjectKey + projectKey + "");
		ClientResponse response1 = webResource1.header("Content-Type", "application/json")
				.header("Cookie", authStringEnc).get(ClientResponse.class);

		String responseString = response1.getEntity(String.class);
		System.out.println("Response " + response1);
		System.out.println("ResponseStr " + responseString);
		JSONObject objResponseString;
		objResponseString = new JSONObject(responseString);
		System.out.println(objResponseString);

		if (responseString != null) {

			WebResource webResource = client.resource(APIConstants.ServerName + APIConstants.ReleaseBurndownChart
					+ rapidViewId + APIConstants.VersionID + releaseID + "&_=" + timestamp.getTime());
			ClientResponse response = webResource.header("Content-Type", "application/json")
					.header("Cookie", authStringEnc).get(ClientResponse.class);

			String resp = response.getEntity(String.class);
			System.out.println("Output is:" + resp);
			String finalresp = resp.replaceAll("Sample Sprint", "").replaceAll("Sprint", "").replaceAll("GOGMA", "")
					.replaceAll("DummyTes", "");
			client.destroy();
			String added, change_key, oldvalue, notDone;
			String original_estimate, release, releaseDate;
			ArrayList<String> starttime_list = new ArrayList<String>();
			ArrayList<String> sprint_name_List = new ArrayList<String>();
			ArrayList<String> endtime_list = new ArrayList<String>();
			ArrayList<String> window_List = new ArrayList<String>();
			ArrayList<String> labels = new ArrayList<String>();
			ArrayList<Float> workadded_List = new ArrayList<Float>();
			ArrayList<Float> workcompleted_list = new ArrayList<Float>();
			ArrayList<Float> workremaining_list = new ArrayList<Float>();
			ArrayList<Float> workAtTheStartOfSprint_list = new ArrayList<Float>();
			LinkedHashMap<String, String> change_values;
			float work_completed_null = 0, release_WA = 0;
			change_values = new LinkedHashMap<String, String>();
			String start_time, end_time, original_sprint_name, changeskey, stat_c, newvalue;
			String map_newvalue;
			String[][] sprintArray;
			float initial_wr_value = 0, release_null = 0;
			ArrayList<String> keyList;
			LinkedHashMap<String, String> new_issue_listpair;
			String versionStartDateString = "", versionEndDateString = "";
			Long sprintStartTimeString, sprintEndTimeString;
			Boolean done_value = false;

			try {
				JSONObject mainObj = new JSONObject(finalresp);
				JSONObject versionDates = mainObj.getJSONObject("version");

				final JSONArray sortedJsonArray = new JSONArray();
				final JSONArray sprintsWithinTheRelease = new JSONArray();
				if (mainObj != null) {

					List<JSONObject> jsonValues = new ArrayList<JSONObject>();
					final JSONArray sprints = mainObj.getJSONArray("sprints");
					System.out.println("JSONSPRINT LENTGH" + sprints.length());

					// SORTING JSON VALUES ACCORDING OT START TIME
					for (int s = 0; s < sprints.length(); s++) {
						jsonValues.add(sprints.getJSONObject(s));
					}
					Collections.sort(jsonValues, new Comparator<JSONObject>() {
						// You can change "Name" with "ID" if you want to sort by ID
						private static final String KEY_NAME = "startTime";

						@Override
						public int compare(JSONObject a, JSONObject b) {
							String valA = new String();
							String valB = new String();

							try {
								valA = a.getString(KEY_NAME);
								valB = b.getString(KEY_NAME);
							} catch (JSONException e) {
								// do something
							}

							try {
								return valA.compareTo(valB);
							} catch (Exception e) {
								throw new IllegalArgumentException(e);
							}
							// if you want to change the sort order, simply use the following:
							// return -valA.compareTo(valB);
						}
					});

					for (int i = 0; i < sprints.length(); i++) {

						sortedJsonArray.put(jsonValues.get(i));
					}
					if (versionDates.has("startDate") && versionDates.has("releaseDate")) {
						versionStartDateString = versionDates.getString("startDate");
						versionEndDateString = versionDates.getString("releaseDate");
						for (int js = 0; js < sortedJsonArray.length(); js++) {
							JSONObject sortedJsonArrayObjects = sortedJsonArray.getJSONObject(js);
							String name = sortedJsonArrayObjects.getString("name");
							sprintStartTimeString = Long.parseLong(sortedJsonArrayObjects.getString("startTime"));
							sprintEndTimeString = Long.parseLong(sortedJsonArrayObjects.getString("endTime"));
							try {

								Date sprint_strt_date = new Date(sprintStartTimeString);
								Date sprint_end_date1 = new Date(sprintEndTimeString);
								System.out.println("///////////////////////////sprint Nmae/////////////" + name);
								Date releaseStartdate = new Date(Long.parseLong(versionStartDateString));
								Date releaseEndDate = new Date(Long.parseLong(versionEndDateString));
								System.out.println(
										"///////////////////////////Sprint start date/////////////" + sprint_strt_date);
								System.out.println("///////////////////////////release start date/////////////"
										+ releaseStartdate);
								System.out.println(
										"///////////////////////////Sprint End date/////////////" + sprint_end_date1);
								System.out.println(
										"///////////////////////////release End date/////////////" + releaseEndDate);

								if ((sprint_strt_date.after(releaseStartdate))
										&& (sprint_end_date1.before(releaseEndDate))) {
									System.out.println("INTO the if cond");
									sprintsWithinTheRelease.put(jsonValues.get(js));
								}

							} catch (Exception e) {
								e.printStackTrace();
							}

						}

						System.out.println("SORTED JSON ARRAY" + sprintsWithinTheRelease);
					}

					if (sprintsWithinTheRelease != null && sprintsWithinTheRelease.length() > 0) {

						for (int i = 0; i < sprintsWithinTheRelease.length(); i++) {
							JSONObject elem = sprintsWithinTheRelease.getJSONObject(i);
							start_time = elem.getString("startTime");
							starttime_list.add(start_time);
							original_sprint_name = elem.getString("name");
							sprint_name_List.add(original_sprint_name);
							end_time = elem.getString("endTime");
							endtime_list.add(end_time);
							System.out.println("starttime list" + Arrays.toString(starttime_list.toArray()));
							System.out.println("endtime list" + Arrays.toString(endtime_list.toArray()));
							System.out.println("Sprint name list" + Arrays.toString(sprint_name_List.toArray()));
						}
						System.out.println("unsorted starttime list" + Arrays.toString(starttime_list.toArray()));
						System.out.println("sorted starttime list" + Arrays.toString(starttime_list.toArray()));
						System.out.println("Srted Sprint name list" + Arrays.toString(sprint_name_List.toArray()));
						sprintArray = new String[sprintsWithinTheRelease.length() + 1][2];
						for (int i = 0; i <= sprintsWithinTheRelease.length(); i++) {
							for (int j = 0; j < 2; j++) {
								if (i == 0 && j == 0) {
									sprintArray[i][j] = "0";
								} else if (i > j && j == 0) {
									sprintArray[i][j] = sprintArray[i - 1][j + 1];
								} else if (i == sprintsWithinTheRelease.length() && j == 1) {
									sprintArray[i][j] = versionEndDateString;
								} else {
									sprintArray[i][j] = starttime_list.get(i).toString();
								}
							}

						}
						for (int i = 0; i <= sprintsWithinTheRelease.length(); i++) {
							for (int j = 0; j < 2; j++) {
								System.out.println(sprintArray[i][j] + "");
							}
							System.out.println();

						}
						System.out.println("SPRINT ARRAY LENGTH" + sprintArray.length);

						JSONObject changes = mainObj.getJSONObject("changes");

						if (changes.length() == 0) {

							responseJson.put("warningMessage", "No estimated issues in this version");

						} else {
							if (changes != null) {
								Iterator<?> x = changes.keys();
								JSONArray jsonArray = new JSONArray();

								while (x.hasNext()) {
									String key = (String) x.next();
									jsonArray.put(changes.get(key));
								}
								System.out.println("JSON ARRAY LENGTH" + jsonArray.length());
								for (int i = 0; i < jsonArray.length(); i++) {
									System.out.println("CHANGES JSON ARRAY" + jsonArray.getJSONArray(i));

									JSONArray innerarray = jsonArray.getJSONArray(i);
									for (int j = 0; j < innerarray.length(); j++) {

										JSONObject innerobj = innerarray.getJSONObject(j);
										changeskey = innerobj.getString("key");

										System.out.println("CHANGES KEY" + changeskey);
										if (innerobj.has("statC")) {
											stat_c = innerobj.getString("statC");
											System.out.println("STATC VALUE" + stat_c);
											JSONObject innerobj2 = innerobj.getJSONObject("statC");
											if (innerobj2.has("newValue")) {
												newvalue = innerobj2.getString("newValue");
												System.out.println("STATC NEW VALUE" + newvalue);
												change_values.put(changeskey, newvalue);
												issuekey_booleanpair.put(changeskey, done_value);
											}
										}
									}
								}
								System.out.println("issue key boolean pair" + issuekey_booleanpair);

								for (Map.Entry<String, String> entry : change_values.entrySet()) {
									String key = entry.getKey();
									String value = entry.getValue();
									System.out.println("Final map size" + change_values.size());
									System.out.println("map key" + key + " map value" + value);
								}
							}
							for (int i = 0; i < sprintArray.length; i++) {
								keyList = new ArrayList<String>();
								new_issue_listpair = new LinkedHashMap<>();
								float work_added = 0;
								float work_remaining = 0;
								@SuppressWarnings("unused")
								float int_oldvalue = 0;
								@SuppressWarnings("unused")
								float int_old_newvalue = 0;
								float work_completed = 0;

								System.out.println("SPRINT SIZE!!!" + sprintArray.length + "" + "CHANGES MAP SIZE!!"
										+ change_values.size() + "iteration number" + "-" + i);
								JSONObject win_changes = mainObj.getJSONObject("changes");
								if (win_changes != null) {
									@SuppressWarnings("rawtypes")
									Iterator h = win_changes.keys();
									JSONArray array = new JSONArray();

									while (h.hasNext()) {

										float new_workadded = 0, new_workcompleted = 0;
										String timestamps = (String) h.next();
										array.put(changes.get(timestamps));
										System.out.println("TIME STAMPS" + timestamps);
										Long long_timestamp = Long.parseLong(timestamps);
										System.out.println("TIME STAMP IN Double" + long_timestamp);
										if ((long_timestamp > Long.parseLong(sprintArray[i][0]))
												&& (long_timestamp < Long.parseLong(sprintArray[i][1]))) {
											/* flag++; */
											System.out.println("INTO MAIN IF");
											String time_stamp = String.valueOf(long_timestamp);
											String tm = changes.get(time_stamp).toString();
											System.out.println("CHECKED TIME STAMP" + tm);
											JSONArray checked_tmarray = new JSONArray(tm);
											for (int s = 0; s < checked_tmarray.length(); s++) {
												JSONObject checked_tm_obj = checked_tmarray.getJSONObject(s);

												change_key = checked_tm_obj.getString("key");

												keyList.add(change_key);
												if (checked_tm_obj.has("statC")) {
													JSONObject statc_obj = checked_tm_obj.getJSONObject("statC");

													if (statc_obj.has("oldValue") && statc_obj.has("newValue")) {
														oldvalue = statc_obj.getString("oldValue");
														int_oldvalue = Float.parseFloat(oldvalue);
														int_old_newvalue = Float
																.parseFloat(statc_obj.getString("newValue"));

														System.out.println(
																"************WORK ADDED INSIDE OLDVALUE***************"
																		+ work_added);
													}
												}

												if (checked_tm_obj.has("added")) {
													added = checked_tm_obj.getString("added");

													if (added.equals("true")) {
														if (change_values.containsKey(change_key)) {
															map_newvalue = change_values.get(change_key);
															new_workadded = Float.parseFloat(map_newvalue);
															work_added = work_added + new_workadded;

														}
														System.out.println(
																"************WORK ADDED INSIDE ADDED==TRUE***************"
																		+ work_added);

													}
													if (added.equals("false")) {
														if (change_values.containsKey(change_key)) {
															map_newvalue = change_values.get(change_key);
															System.out.println("KEY INSIDE THE WINDOW AND CHANGE"
																	+ change_key + "" + map_newvalue);
															new_workadded = Float.parseFloat(map_newvalue);

															work_added = work_added - new_workadded;
														}

														System.out.println(
																"************WORK ADDED INSIDE ADDED==FALSE***************"
																		+ work_added);
													}
												}
												if (checked_tm_obj.has("column")) {
													JSONObject column_obj = checked_tm_obj.getJSONObject("column");

													if (column_obj.has("notDone")) {
														notDone = column_obj.getString("notDone");
														if (notDone.equals("false")) {
															if (change_values.containsKey(change_key)) {
																map_newvalue = change_values.get(change_key);
																new_workcompleted = Float.parseFloat(map_newvalue);
																work_completed = work_completed + new_workcompleted;
																if (issuekey_booleanpair.get(change_key) == false) {
																	done_value = true;
																	issuekey_booleanpair.put(change_key, done_value);
																}
															}

															System.out.println("WORK COMPLETED" + work_completed);
															System.out.println("issue key boolean pair notdone==false"
																	+ issuekey_booleanpair);

														} else {
															if (notDone.equals("true")) {
																if (change_values.containsKey(change_key)) {

																	map_newvalue = change_values.get(change_key);
																	new_workcompleted = Float.parseFloat(map_newvalue);

																	if (issuekey_booleanpair.get(change_key) == true) {
																		if (work_completed >= Float
																				.parseFloat(map_newvalue)) {
																			work_completed = work_completed
																					- Float.parseFloat(map_newvalue);
																			work_remaining = work_remaining
																					+ Float.parseFloat(map_newvalue);
																		}
																		System.out.println(
																				"INTO FALSE ..........................");
																		done_value = false;
																		issuekey_booleanpair.put(change_key,
																				done_value);

																	}

																}
															}
															System.out.println("WORK COMPLETED" + work_completed);
															System.out.println("issue key boolean pair notdone==true"
																	+ issuekey_booleanpair);
														}

													}

												}
											}

										}

									}

									workcompleted_list.add(work_completed);
									for (int wc = 0; wc < workcompleted_list.size(); wc++) {
										System.out.println("WORK COMPLETED LISt" + workcompleted_list.get(wc));
									}
									System.out.println("NEW WORK ADDED VALUE IS" + work_added);
									workadded_List.add(work_added);
									for (int w = 0; w < workadded_List.size(); w++) {
										System.out.println("WORK ADDED LIST" + workadded_List.get(w));
									}
									if (i == 0) {

										System.out.println("INTO IF WHEN I=0");
										workremaining_list.add(initial_wr_value);
										workAtTheStartOfSprint_list.add(workadded_List.get(i));

									}
									if (i > 0) {
										System.out.println("INTO IF WHEN I>0");

										work_remaining = workAtTheStartOfSprint_list.get(i - 1) + workadded_List.get(i)
												- workcompleted_list.get(i);

										System.out.println(
												".........................Work at the start of the sprint................++++++++"
														+ workAtTheStartOfSprint_list.get(i - 1) + "work adde"
														+ workadded_List.get(i) + " Work completed"
														+ workcompleted_list.get(i));

										workremaining_list.add(work_remaining);
										workAtTheStartOfSprint_list.add(workremaining_list.get(i));
									}

									for (int wr = 0; wr < workremaining_list.size(); wr++) {
										System.out.println("Work remaining list length" + workremaining_list.size());
										System.out.println("WORK REMAINING LIST" + workremaining_list.get(wr));
									}
								} else {
									workcompleted_list.add(work_completed_null);
									workadded_List.add(work_completed_null);
									workremaining_list.add(work_completed_null);
								}
								if (i == 0) {
									original_estimate = "Original";
								} else {
									original_estimate = sprint_name_List.get(i - 1);
								}
								window_List.add(original_estimate);
							}

							System.out.println("WA LIST" + Arrays.toString(workadded_List.toArray()));
							System.out.println("WC LIST" + Arrays.toString(workcompleted_list.toArray()));
							System.out.println("WA LIST" + Arrays.toString(workremaining_list.toArray()));

							JSONObject version = mainObj.getJSONObject("version");
							release = version.getString("released");
							System.out.println("RELEASE" + release);
							System.out.println("RELEASE STRING" + release);
							if (version.has("releaseDate")) {
								releaseDate = version.getString("releaseDate");
								System.out.println("RELEASE DATE" + releaseDate);
								responseJson.put("workadded_List", workadded_List);
								responseJson.put("workcompleted_list", workcompleted_list);
								responseJson.put("workremaining_list", workremaining_list);
							} else {
								if (release.equals("false")) {
									for (int r = 0; r < workadded_List.size(); r++) {
										release_WA += workadded_List.get(r);
									}

									workadded_List.set(0, release_WA);
									workremaining_list.set(0, release_null);
									workcompleted_list.set(0, release_null);
									for (int q = 1; q < workadded_List.size(); q++) {
										workadded_List.set(q, release_null);
									}
									for (int d = 1; d < workcompleted_list.size(); d++) {
										workcompleted_list.set(d, release_null);
									}
									for (int f = 1; f < workremaining_list.size(); f++) {
										workremaining_list.set(f, release_null);
									}
									System.out.println(
											"Release version WA LIST" + Arrays.toString(workadded_List.toArray()));
									System.out.println(
											"Release version WC LIST" + Arrays.toString(workcompleted_list.toArray()));
									System.out.println(
											"Release version WR LIST" + Arrays.toString(workremaining_list.toArray()));

									responseJson.put("workadded_List", workadded_List);
									responseJson.put("workcompleted_list", workcompleted_list);
									responseJson.put("workremaining_list", workremaining_list);
								}
							}

							for (int wl = 0; wl < window_List.size(); wl++) {
								System.out.println("WINDOWS FOR X-AXIS" + window_List.get(wl));

							}

							for (int win = 0; win < sprintArray.length; win++) {

								labels.add(win, window_List.get(win));
								System.out.println("WINDOW LIST VALUE IN CHART" + window_List.get(win).toString());
							}

							responseJson.put("sprintsList", labels);

						}
					} else {

						System.out.println(
								"**********************//////////////////This is into else condition from the main if statement//////////////////////*************************** ");
						float work_added = 0;
						JSONObject changes = null;
						try {
							changes = mainObj.getJSONObject("changes");
						} catch (JSONException e) {
							e.printStackTrace();
						}

						if (changes.length() == 0) {
							responseJson.put("warningMessage", "No estimated issues in this version");
						} else if (changes != null) {
							float OE_sum = 0;
							@SuppressWarnings("rawtypes")
							Iterator x = changes.keys();
							JSONArray jsonArray = new JSONArray();

							while (x.hasNext()) {
								String key = (String) x.next();
								jsonArray.put(changes.get(key));
							}
							System.out.println("JSON ARRAY LENGTH" + jsonArray.length());
							for (int i = 0; i < jsonArray.length(); i++) {
								System.out.println("CHANGES JSON ARRAY" + jsonArray.getJSONArray(i));

								JSONArray innerarray = jsonArray.getJSONArray(i);
								for (int j = 0; j < innerarray.length(); j++) {

									JSONObject innerobj = innerarray.getJSONObject(j);
									changeskey = innerobj.getString("key");

									System.out.println("CHANGES KEY" + changeskey);
									if (innerobj.has("statC")) {
										stat_c = innerobj.getString("statC");
										System.out.println("STATC VALUE" + stat_c);
										JSONObject innerobj2 = innerobj.getJSONObject("statC");
										if (innerobj2.has("newValue")) {
											newvalue = innerobj2.getString("newValue");
											System.out.println("STATC NEW VALUE" + newvalue);
											change_values.put(changeskey, newvalue);
										}
									}
								}
							}
							for (Map.Entry<String, String> entry : change_values.entrySet()) {
								String key = entry.getKey();
								System.out.println("Final map size" + change_values.size());
								System.out.println("map key" + key);
								String value = entry.getValue();
								OE_sum = OE_sum + Float.parseFloat(value.toString());
								work_added = OE_sum;
							}
							responseJson.put("OriginalEstimate", (work_added));
						}
					}
				} else {
					System.out.println("MAIN OBJECT IS NULL");
					responseJson.put("errorMessage", "Invalid Values / Permission error");
				}
			} catch (JSONException ae) {
				ae.printStackTrace();
				responseJson.put("errorMessage", "Invalid Values / Permission error");
			}
		} else {
			System.out.println("RESPONSE STRING NULL");
			responseJson.put("errorMessage", "Invalid Values / Permission error");
		}

		return Response.status(200).entity(responseJson.toString()).build();
	}
}
