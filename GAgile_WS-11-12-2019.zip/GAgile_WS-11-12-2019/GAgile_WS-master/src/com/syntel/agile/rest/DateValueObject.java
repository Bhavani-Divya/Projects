package com.syntel.agile.rest;

public class DateValueObject {

	public float getDate() {
		return date;
	}
	public void setDate(float date) {
		this.date = date;
	}
	public float getHours() {
		return hours;
	}
	public void setHours(float hours) {
		this.hours = hours;
	}
	public DateValueObject(float hours, float date) {
		this.date = date;
		this.hours = hours;
	}
	private float date;
	private float hours;
	
}
