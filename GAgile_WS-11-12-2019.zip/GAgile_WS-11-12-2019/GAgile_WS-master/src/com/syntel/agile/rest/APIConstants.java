package com.syntel.agile.rest;

public final class APIConstants {
	/*
	 * APIConstants class in intentionally created to store JIRA API's at one place
	 * using constant variables. Later on whenever any changes in the API's, you can
	 * make at one single place.
	 */

	// IssueTypes:
	public static final String IMPEDIMENTS = "Impediment";
	public static final String BUGS = "Bug";
	public static final String STORIES = "Story";

	// Issue Assigned/Unassigned Status:
	public static final String UNASSIGNED = "Unassigned";
	public static final String NONE = "None";

	// URL's
	public static final String ServerName = "https://agilectb.atlassian.net/rest";
	public static final String BacklogData = "/greenhopper/1.0/xboard/plan/backlog/data.json?rapidViewId=";
	public static final String SprintQuery = "/greenhopper/1.0/sprintquery/";
	public static final String SprintReport = "/greenhopper/1.0/rapid/charts/sprintreport?rapidViewId=";
	public static final String ScopeChangeBurndownChart = "/greenhopper/1.0/rapid/charts/scopechangeburndownchart.json?rapidViewId=";
	public static final String BoardUserName = "/api/2/myself";
	public static final String Search = "/api/2/search";
	public static final String Issue = "/api/2/issue/";
	public static final String ProjectKey = "/projects/1.0/project/";
	public static final String Version = "/release/allversions?_=1511187054869";
	public static final String Projects = "/api/2/project";
	public static final String BoardID = "/agile/1.0/board/";
	public static final String ViewData = "/greenhopper/1.0/rapidviews/viewsData?";
	public static final String LatestBoardID = "/agile/latest/board/";
	public static final String IssueKey = "/api/latest/user/assignable/search?issueKey=";
	public static final String Login = "/auth/1/session";
	public static final String Includes = "?includeHistoricSprints=false&includeFutureSprints=false";
	public static final String SprintJQL = "/issue?jql=Sprint=";
	public static final String ReleaseBurndownChart = "/greenhopper/1.0/rapid/charts/releaseburndownchart?rapidViewId=";
	public static final String SearchJQL = "/api/2/search?jql=";
	public static final String Status = "/greenhopper/1.0/xboard/work/allData.json?rapidViewId=";
	public static final String ImpedimentsJQL = "/issue?jql='issuetype'=Impediment&maxResults=1000";
	public static final String VelocityChart = "/greenhopper/1.0/rapid/charts/velocity.json?rapidViewId=";
	public static final String WorkloadChart = "/chartplugin/1.0/workloadpie/generate?projectOrFilterId=filter-";
	public static final String SelectedProjectKey = "&selectedProjectKey=";
	public static final String SprintID = "&sprintId=";
	public static final String CustomField10200 = "&statisticFieldId=field_customfield_10200&_=";
	public static final String ReleaseAllVersions = "/release/allversions?_=";
	public static final String ImpedimentsJQLMax500 = "/issue?jql=issuetype=Impediment&maxResults=500";
	public static final String EditMeta = "/editmeta";
	public static final String IssueJQL = "/issue?jql=Project=";
	public static final String MaxResult = "&startAt=0&maxResults=2000";
	public static final String IssueMaxResult = "/issue?maxResults=1000";
	public static final String IssueMaxResult500 = "/issue?maxResults=500";
	public static final String MaxResult1000 = "&maxResults=1000";
	public static final String VersionID = "&versionId=";
	public static final String BugMaxResult = "/issue?jql='issuetype'=bug&maxResults=1000";
	public static final String StaticAssignee = "&statistictype=assignees";
	public static final String MaxResult1 = "&startAt=0&maxResults=1";
	public static final String Username = "&username=";
	public static final String ActiveSprints = "&activeSprints=";
	// Messages
	public static final String NoReleaseDate = "Release date are not available no sprint started yet";
	public static final String NoSprintStarted = "No Sprint Started yet";
	public static final String ErrorMessage = "errorMessages";
	public static final String WarningMessage = "warningMessage";
	public static final String NoIssues = "No issues are estimated/completed";
	public static final String NoActiveSprint = "Currently no active Sprint ";
	public static final String NoSprintAdded = "No Sprint Added";
	public static final String NoImpediments = "There are no impediments associated with this team";
	public static final String ReleaseVersion = "Upcoming Release Version";
	public static final String NoReleaseSetup = "no current release setup";
	public static final String ReleaseDatenotAvail = "Release date are not available";
	public static final String NoVelocity = "No Velocity is not available";
	public static final String NoWorkdown = "No Work break down chart is";
	public static final String SearchNoIssues = "No issues were found to match your search";
}
