
package com.syntel.agile.rest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/sprinthealthactivesprintlic")

public class SprintHealthActiveSprintlic {
	@GET
	@Path("/{rid}/{projectKey}")
	public Response getSprintHealthSample(@PathParam("rid") String rapidViewId,
			@PathParam("projectKey") String projectKey, @PathParam("activeSprints") String activeSprints,
			@Context HttpHeaders headers) throws JSONException, ParseException {
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.out.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();
		System.out.println(authStringEnc);
		// rapidViewId=15 projectKey=AIEM
		WebResource webResource = client
				.resource(APIConstants.ServerName + APIConstants.Status + rapidViewId + APIConstants.SelectedProjectKey + projectKey + "");
		ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc)
				.get(ClientResponse.class);
		double totalstorycount = 0, todo = 0, inprogress = 0, completed = 0;

		String responseString = response.getEntity(String.class);
		System.out.println("Response " + response);
		System.out.println("ResponseStr " + responseString);
		JSONObject objResponseString;
		objResponseString = new JSONObject(responseString);
		JSONObject sprintsData = (JSONObject) objResponseString.get("sprintsData");
		JSONArray sprints = (JSONArray) sprintsData.get("sprints");
		int sprintLength = sprints.length();
		System.out.println("n = " + sprintLength);
		if (sprintLength == 1) {
			JSONObject issuesData = (JSONObject) objResponseString.get("issuesData");
			JSONArray issues = (JSONArray) issuesData.get("issues");
			for (int i = 0; i < issues.length(); i++) {
				JSONObject value = (JSONObject) issues.get(i);

				String statusName = (String) value.get("statusName");
				System.out.println(statusName);
				if (value.getString("statusName").equals("In Progress")
						&& (value.getString("typeName").equals("Story"))) {
					inprogress++;
					System.out.println(inprogress);
				} else if (value.getString("statusName").equals("To Do")
						&& (value.getString("typeName").equals("Story"))) {
					todo++;
					System.out.println(todo);
				} else if (value.getString("statusName").equals("Done")
						&& (value.getString("typeName").equals("Story"))) {
					completed++;
					System.out.println(completed);
				}
			}
			JSONObject objSprints = (JSONObject) sprints.get(sprintLength - 1); // name
			System.out.println(sprints);
			String name = (String) objSprints.get("name");
			System.out.println(name);
			String startDate = (String) objSprints.get("startDate");
			System.out.println(startDate);
			String endDate = (String) objSprints.get("endDate");
			System.out.println(endDate);
			Integer daysRemaining = (Integer) objSprints.get("daysRemaining");
			if (daysRemaining != 0) {
				JSONObject finalResponse = new JSONObject();
				finalResponse.put("completed", completed);
				finalResponse.put("inprogress", inprogress);
				finalResponse.put("todo", todo);
				totalstorycount = (completed * 100) / (inprogress + completed + todo);
				finalResponse.put("total story count", totalstorycount + "% "); // completed
				finalResponse.put("Sprint", objSprints.get("name").toString());
				finalResponse.put(" Remaining work days", daysRemaining);
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MMM/yy hh:mm");
				SimpleDateFormat formatterCustom = new SimpleDateFormat("MMM dd");
				Date startDateFormated = formatter.parse((String) objSprints.get("startDate").toString());
				System.out.println(startDateFormated);
				String startDateFormatter = formatterCustom.format(startDateFormated);
				System.out.println(startDateFormatter);

				Date endDateFormated = formatter.parse((String) objSprints.get("endDate").toString());
				System.out.println(endDateFormated);
				String endDateFormatter = formatterCustom.format(endDateFormated);
				System.out.println(endDateFormatter);
				finalResponse.put("Date", startDateFormatter + "-" + endDateFormatter);
				System.out.println("Output from Server .... \n" + finalResponse);
				client.destroy();
				return Response.status(200).entity(finalResponse.toString()).header("Content-Type", "application/json")
						.build();
			}

			else {
				JSONObject finalResponse = new JSONObject();
				finalResponse.put("Currently no active Sprint", daysRemaining);
				System.out.println("Output from Server .... \n" + finalResponse);
				client.destroy();
				return Response.status(200).entity(finalResponse.toString()).header("Content-Type", "application/json")
						.build();
			}
		}

		else if (sprintLength > 1) {
			JSONObject objSprints = (JSONObject) sprints.get(sprintLength - 1);
			Integer activeSprintId = (Integer) objSprints.get("id");
			System.out.println("activeSprintsid" + activeSprintId);
			System.out.println("n = " + sprintLength);
			// rapidViewId=15, projectKey=AIEM, activeSprintsid=143
			WebResource webResource2 = client.resource(APIConstants.ServerName + APIConstants.Status + rapidViewId
					+ APIConstants.SelectedProjectKey + projectKey + APIConstants.ActiveSprints + activeSprintId + "");
			ClientResponse response2 = webResource2.header("Content-Type", "application/json")
					.header("Cookie", authStringEnc).get(ClientResponse.class);
			String respStr2 = response2.getEntity(String.class);
			System.out.println("Response " + response2);
			System.out.println("ResponseStr " + respStr2);
			JSONObject ob2;
			ob2 = new JSONObject(respStr2);
			JSONObject issuesData = (JSONObject) ob2.get("issuesData");
			JSONArray issues = (JSONArray) issuesData.get("issues");
			System.out.println("activeSprintsid" + activeSprintId);
			for (int i = 0; i < issues.length(); i++) {
				JSONObject value = (JSONObject) issues.get(i);
				if (value.getString("statusName").equals("In Progress")
						&& (value.getString("typeName").equals("Story"))) {
					inprogress++;
				} else if (value.getString("statusName").equals("To Do")
						&& (value.getString("typeName").equals("Story"))) {
					todo++;
				} else if (value.getString("statusName").equals("Done")
						&& (value.getString("typeName").equals("Story"))) {
					completed++;
				}
			}
			System.out.println(sprints);
			String name = (String) objSprints.get("name");
			System.out.println(name);
			String startDate = (String) objSprints.get("startDate");
			System.out.println(startDate);
			String endDate = (String) objSprints.get("endDate");
			System.out.println(endDate);
			Integer daysRemaining = (Integer) objSprints.get("daysRemaining");
			if (daysRemaining != 0) {
				JSONObject finalResponse = new JSONObject();
				finalResponse.put("Sprint", objSprints.get("name").toString());
				finalResponse.put(" Remaining work days", daysRemaining);
				finalResponse.put("completed", completed);
				finalResponse.put("inprogress", inprogress);
				finalResponse.put("todo", todo);
				totalstorycount = (completed * 100) / (inprogress + completed + todo);
				finalResponse.put("total story count", totalstorycount + "% "); // completed
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MMM/yy hh:mm");
				SimpleDateFormat formatterCustom = new SimpleDateFormat("MMM dd");
				Date startDateFormated = formatter.parse((String) objSprints.get("startDate").toString());
				System.out.println(startDateFormated);
				String startDateFormatter = formatterCustom.format(startDateFormated);
				System.out.println(startDateFormatter);

				Date endDateFormated = formatter.parse((String) objSprints.get("endDate").toString());
				System.out.println(endDateFormated);
				String endDateFormatter = formatterCustom.format(endDateFormated);
				System.out.println(endDateFormatter);

				finalResponse.put("Date", startDateFormatter + "-" + endDateFormatter);
				System.out.println("Output from Server .... \n" + finalResponse);
				client.destroy();
				return Response.status(200).entity(finalResponse.toString()).header("Content-Type", "application/json")
						.build();
			} else {
				JSONObject finalResponse = new JSONObject();
				finalResponse.put(APIConstants.NoActiveSprint, daysRemaining);
				System.out.println("Output from Server .... \n" + finalResponse);
				client.destroy();
				return Response.status(200).entity(finalResponse.toString()).header("Content-Type", "application/json")
						.build();
			}

		} else {
			JSONObject finalResponse = new JSONObject();
			finalResponse.put(APIConstants.NoSprintAdded, sprintLength);
			System.out.println("Output from Server .... \n" + finalResponse);
			client.destroy();
			return Response.status(200).entity(finalResponse.toString()).header("Content-Type", "application/json")
					.build();
		}

	}

}
