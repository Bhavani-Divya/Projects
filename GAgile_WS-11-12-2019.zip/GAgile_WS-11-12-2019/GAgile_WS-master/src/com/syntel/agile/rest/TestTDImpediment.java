package com.syntel.agile.rest;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/testImpediments")
public class TestTDImpediment {

	@GET
	@Path("/{teamId}/{projectKey}")
	public Response getActiveImpediments(@PathParam("teamId") String teamId, @PathParam("projectKey") String projectKey,
			@Context HttpHeaders headers) throws JSONException {

		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		List<JSONObject> finalResponselist = new ArrayList<>();
		double impedimentsCount = 0.0;
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.err.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();
		WebResource webResource = client
				.resource(APIConstants.ServerName + APIConstants.LatestBoardID + teamId + APIConstants.ImpedimentsJQL);

		ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc)
				.get(ClientResponse.class);

		String responseBoard = response.getEntity(String.class);
		JSONObject object = new JSONObject(responseBoard);
		JSONArray issueArray = object.getJSONArray("issues");
		JSONObject finalRes = new JSONObject();
		for (int j = 0; j < issueArray.length(); j++) {
			JSONObject finalResponse = new JSONObject();
			JSONObject row = (JSONObject) issueArray.get(j);
			JSONObject fieldsJson = row.getJSONObject("fields");

			JSONObject issuetypeJson = fieldsJson.getJSONObject("issuetype");
			String issueType = issuetypeJson.getString("name"); // issueType=Impediment/Bug/Story
			boolean isResolution = fieldsJson.isNull("resolution");

			if (issueType.equals(APIConstants.IMPEDIMENTS) && isResolution) {
				impedimentsCount++;
				List<String> versionName = new ArrayList<String>();
				String version = null;
				String assigneeName = null;
				String impedimentId = (String) row.get("key"); // AIEM-211/AIEM-212
				JSONArray fixedVersionArray = fieldsJson.getJSONArray("fixVersions");
				for (int r = 0; r < fixedVersionArray.length(); r++) {

					JSONObject fixedVersionObj = (JSONObject) fixedVersionArray.get(r);
					version = fixedVersionObj.getString("name");
					versionName.add(version);

				}

				String createdDate = fieldsJson.getString("created");
				JSONObject priorityObj = fieldsJson.getJSONObject("priority");
				String severity = priorityObj.getString("name");
				String summary = fieldsJson.getString("summary");

				if (!fieldsJson.isNull("assignee")) {
					JSONObject assigneeObj = (JSONObject) fieldsJson.get("assignee");
					assigneeName = assigneeObj.getString("displayName");
				} else {
					assigneeName = APIConstants.UNASSIGNED;
				}
				System.out.println("assigneeName: " + assigneeName);

				JSONObject statusObj = fieldsJson.getJSONObject("status");
				JSONObject statusCategoryObj = statusObj.getJSONObject("statusCategory");
				String statusName = statusCategoryObj.getString("name");
				String statusColor = statusCategoryObj.getString("colorName");
				finalResponse.put("impedimentID", impedimentId);
				finalResponse.put("summary", summary);
				finalResponse.put("assigneeName", assigneeName);
				finalResponse.put("severity", severity);
				finalResponse.put("status", statusName);
				finalResponse.put("statusColor", statusColor);
				finalResponse.put("releaseVersion", versionName);
				finalResponse.put("openedSince", createdDate);
				finalResponselist.add(finalResponse);

				finalRes.put("impedimentsDetails", finalResponselist);// finalResponselist
				finalRes.put("impedimentsCount", impedimentsCount);
			}
		}

		if (impedimentsCount == 0) {
			finalRes.put("Impediments Details", finalResponselist);
			finalRes.put("impedimentsCount", impedimentsCount);
		}

		System.out.println("Output from Server: " + finalResponselist);
		client.destroy();
		return Response.status(200).entity(finalRes.toString()).header("Content-Type", "application/json").build();
	}
}
