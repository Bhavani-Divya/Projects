package com.syntel.agile.rest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/upcomingReleaseLic")

public class UpcomingReleaseLic {

	@GET
	@Path("/{rid}/{projectKey}")
	public Response getAllsprintidvalue(@PathParam("rid") String rapidViewId,
			@PathParam("projectKey") String projectKey, @PathParam("activeSprints") String activeSprints,
			@Context HttpHeaders headers) throws JSONException, ParseException {

		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.err.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();

		WebResource webResource1 = client
				.resource(APIConstants.ServerName + APIConstants.SprintQuery + rapidViewId + "");

		ClientResponse response = webResource1.header("Content-Type", "application/json")
				.header("Cookie", authStringEnc).get(ClientResponse.class);

		String responseString = response.getEntity(String.class);
		System.out.println("Response " + response);
		System.out.println("ResponseStr " + responseString);
		JSONObject objResponseString;
		objResponseString = new JSONObject(responseString);

		JSONArray sprints = (JSONArray) objResponseString.get("sprints");
		int sprintLength = sprints.length();

		System.out.println("sprintlength" + sprintLength);

		int count = sprintLength;
		System.out.println("count" + count);

		Set<Double> set = new HashSet<Double>();
		Set<Double> set1 = new HashSet<Double>();
		Set<String> set3 = new HashSet<String>();
		double noFinalvalLength = 0.0;
		String endDateFormatter = null;
		String startDateFormatter = null;
		Integer sequence = 0;
		String name;
		String releaseVersionName = null;
		String startDateFormatter1 = null;
		String startDateFormatter2 = null;
		@SuppressWarnings("unused")
		int seq = 0;
		Date currentDay = null;
		Date startDateFinal = null;
		Date endDateFinal = null;
		@SuppressWarnings("unused")
		Date d1 = null;
		@SuppressWarnings("unused")
		Date d2 = null;

		boolean val = false;
		String startDateFormatedval = null, endDateFormatedval = null;
		String releaseStartDate = null, releaseEndDate = null;

		Integer projectId = 0, projectId1 = 0;

		String endDateFinalval = null;
		@SuppressWarnings("unused")
		String startDateFinalval = null;
		@SuppressWarnings("unused")
		String currentDayFinalval = null;

		if (sprintLength != 0) {

			WebResource webResource3 = client.resource(APIConstants.ServerName + APIConstants.BacklogData + rapidViewId
					+ APIConstants.SelectedProjectKey + projectKey + "");

			ClientResponse response1 = webResource3.header("Content-Type", "application/json")
					.header("Cookie", authStringEnc).get(ClientResponse.class);

			String responseString1 = response1.getEntity(String.class);
			System.out.println("Response " + response1);
			System.out.println("ResponseStr " + responseString1);
			JSONObject objResponseString1;
			objResponseString1 = new JSONObject(responseString1);
			JSONArray issues = (JSONArray) objResponseString1.get("issues");
			int issuesLength = issues.length();

			JSONArray projects = (JSONArray) objResponseString1.get("projects");
			for (int i = 0; i < 1; i++) {

				JSONObject objProjects = (JSONObject) projects.get(i);
				projectId = (Integer) objProjects.get("id");
				System.out.println();
			}

			for (int i = 0; i < issuesLength; i++) {
				JSONObject objissues = (JSONObject) issues.get(i);

				projectId = (Integer) objissues.get("projectId");
			}

			JSONObject versionData = (JSONObject) objResponseString1.get("versionData");

			System.out.println("version Data" + versionData);

			if (projectId != 0 || projectId1 != 0) {

				JSONObject versionsPerProject = (JSONObject) versionData.get("versionsPerProject");

				System.out.println("versionsPerProject" + versionsPerProject);

				String projectIdValue = null;

				if (projectId != 0) {

					projectIdValue = Integer.toString(projectId);
					System.out.println("projidval" + projectIdValue);
				}

				else {

					projectIdValue = Integer.toString(projectId1);
					System.out.println("projidval" + projectIdValue);

				}

				JSONArray versionProjectId = versionsPerProject.getJSONArray(projectIdValue);
				int versionProjectIdLength = versionProjectId.length();

				System.out.println("rellength" + versionProjectIdLength);

				if (versionProjectIdLength != 0) {

					for (int i = 0; i < versionProjectIdLength; i++) { // iterate through jsonArray
						JSONObject jsonObject1 = (JSONObject) versionProjectId.get(i); // get jsonObject @ i position
						System.out.println("jsonObject " + i + ": " + jsonObject1 + "size>>" + jsonObject1.length());

						if (jsonObject1.has("releaseDateFormatted")) {
							String releaseDateFormatted = (String) jsonObject1.get("releaseDateFormatted");
							System.out.println("rel date" + releaseDateFormatted);
						}

						@SuppressWarnings("rawtypes")
						Set keys1 = jsonObject1.keySet();
						@SuppressWarnings("rawtypes")
						Iterator a1 = keys1.iterator();
						while (a1.hasNext()) {
							String key1 = (String) a1.next();
							// loop to get the dynamic key
							if (key1.equalsIgnoreCase("released")) {
								boolean value = (Boolean) jsonObject1.get(key1);
								if (!value) {
									System.out.println("!value = " + !value);
									val = !value;
									System.out.println("val = " + val);
									sequence = (Integer) jsonObject1.get("sequence");
									name = (String) jsonObject1.get("name");
									String releaseDateFormatted = null;
									String startDateFormatted = null;
									if (jsonObject1.has("releaseDateFormatted")
											&& jsonObject1.has("startDateFormatted")) {

										releaseDateFormatted = (String) jsonObject1.get("releaseDateFormatted");
										startDateFormatted = (String) jsonObject1.get("startDateFormatted");
										System.out.println("\n seq>>" + sequence + " and nam" + name);
										System.out.println("\n startDateFormatted>>" + startDateFormatted
												+ " and releaseDateFormatted" + releaseDateFormatted);
										LocalDateTime dateTime = LocalDateTime.now();
										DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MM/dd/yy");

										String formatDateTime = dateTime.format(dateFormat);
										System.out.println(formatDateTime);

										SimpleDateFormat formatter = new SimpleDateFormat("dd/MMM/yy");
										SimpleDateFormat formatterCustom = new SimpleDateFormat("MM/dd/yy");
										Date startDate = formatter
												.parse((String) jsonObject1.get("startDateFormatted").toString());
										System.out.println(startDate);
										startDateFormatter = formatterCustom.format(startDate);
										System.out.println("startDate" + startDate);
										Date endDate = formatter
												.parse((String) jsonObject1.get("releaseDateFormatted").toString());
										System.out.println("endDate" + endDate);
										endDateFormatter = formatterCustom.format(endDate);
										System.out.println("enddate" + endDateFormatter);

										SimpleDateFormat formatterCustom1 = new SimpleDateFormat("MMM yy");
										Date startDateFormated = formatter
												.parse((String) jsonObject1.get("startDateFormatted").toString());
										System.out.println(startDateFormated);
										startDateFormatter1 = formatterCustom1.format(startDateFormated);
										System.out.println(startDateFormatter1);

										Date startDateFormated1 = formatter
												.parse((String) jsonObject1.get("releaseDateFormatted").toString());
										System.out.println(startDateFormated1);
										startDateFormatter2 = formatterCustom1.format(startDateFormated1);
										System.out.println(startDateFormatter2);
										String today = formatDateTime;
										SimpleDateFormat formatterCustom2 = new SimpleDateFormat("MM/dd/yy");
										endDateFinal = endDate;
										System.out.println("enddatefinal" + endDateFinal);
										startDateFinal = startDate;
										System.out.println("startdatefinal" + startDateFinal);

										currentDay = formatterCustom2.parse(today);
										System.out.println("currentDay" + currentDay);

										System.out.println("enddatefinal : " + formatterCustom2.format(endDateFinal));
										System.out
												.println("startdatefinal : " + formatterCustom2.format(startDateFinal));
										System.out.println("currentDay : " + formatterCustom2.format(currentDay));

										endDateFinalval = formatterCustom2.format(endDateFinal);
										System.out.println("enddatefinalval" + endDateFinalval);
										startDateFinalval = formatterCustom2.format(startDateFinal);
										currentDayFinalval = formatterCustom2.format(currentDay);

										if (startDateFinal.compareTo(currentDay) <= 0
												&& endDateFinal.compareTo(currentDay) >= 0) {

											d1 = startDateFinal;
											d2 = endDateFinal;
											System.out.println("Date is" + startDateFormatter + "-" + endDateFormatter);
											System.out.println("Release :" + sequence);
											System.out.println("startdate is:" + startDateFormatter1);
											System.out.println("enddate is:" + startDateFormatter2);

											releaseStartDate = startDateFormatter;
											releaseEndDate = endDateFormatter;

											seq = sequence;
											releaseVersionName = name;
											startDateFormatedval = startDateFormatter1;
											endDateFormatedval = startDateFormatter2;
											System.out.println("spent hr is :" + set);
											System.out.println("rem hr is :" + set1);
											System.out.println("sprint name is :" + set3);
										} else {
											System.out.println("no release date is there");
										}

									} else {
										System.out.println("no current release setup");
									}

								}

								else {

									System.out.println("release date are not available not set up yet");
								}
							}

						}

					}
				}
			}
		}

		else {

			JSONObject finalResponse = new JSONObject();

			int empty = 0;

			finalResponse.put(APIConstants.NoSprintStarted, empty);

			System.out.println("Output from Server .... \n" + finalResponse);
			client.destroy();
			return Response.status(200).entity(finalResponse.toString()).build();

		}
		System.out.println("startdatefinal" + startDateFinal + "enddatefinal" + endDateFinal);
		if (startDateFinal != null && endDateFinal != null && val == true) {

			if (startDateFinal.compareTo(currentDay) <= 0 && endDateFinal.compareTo(currentDay) >= 0) {
				JSONObject finalResponse = new JSONObject();

				finalResponse.put(APIConstants.ReleaseVersion, releaseVersionName);
				finalResponse.put("due on", endDateFormatter);

			} else {
				System.out.println("no release date is there");
			}

		} else {
			JSONObject finalResponse = new JSONObject();
			String a = "missing";
			System.out.println("no current release setup is:" + a);
			finalResponse.put(APIConstants.NoReleaseSetup, a);

			System.out.println("Output from Server .... \n" + finalResponse);
			client.destroy();
			return Response.status(200).entity(finalResponse.toString()).build();

		}

		JSONObject finalResponse = new JSONObject();

		if (val == true && releaseStartDate != null && releaseEndDate != null && endDateFormatedval != null
				&& startDateFormatedval != null) {

			finalResponse.put(APIConstants.ReleaseVersion, releaseVersionName);
			finalResponse.put("due on", releaseEndDate);

			if (noFinalvalLength > 0) {

			}

			else {
				System.out.println("Output from Server .... \n" + finalResponse);
				client.destroy();
				return Response.status(200).entity(finalResponse.toString()).build();
			}

		}

		else {

			int r1 = 0;
			finalResponse.put(APIConstants.ReleaseDatenotAvail, r1);
			System.out.println("Output from Server .... \n" + finalResponse);
			client.destroy();
			return Response.status(200).entity(finalResponse.toString()).build();
		}

		System.out.println("Output from Server .... \n" + finalResponse);
		client.destroy();
		return Response.status(200).entity(finalResponse.toString()).build();

	}
}
