package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/BoardTeamMemberslic")

public class JIRAserviceIssuesBoardTeamMembersLic {

	@GET
	@Path("/{projkey}")
	public Response getTotalStoryPointsIssues(@PathParam("projkey") int projkey, @Context HttpHeaders headers) {
		headers.getRequestHeaders().keySet();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		System.out.println(authStringEnc);
		ArrayList<JSONObject> finalResponselist = new ArrayList<>();
		new Timestamp(System.currentTimeMillis());

		Client client = Client.create();
		System.out.println(projkey);
		WebResource webResource = client.resource(APIConstants.ServerName + APIConstants.LatestBoardID + projkey + "/issue");
		ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc)
				.get(ClientResponse.class);
		System.out.println("1st webservice REsp" + response);
		String respStr = response.getEntity(String.class);
		System.out.println("String Response" + respStr);
		JSONObject ob = new JSONObject(respStr);
		System.out.println("response :" + ob);
		JSONArray issuearray = ob.getJSONArray("issues");
		System.out.println("Befor IF loop  NO issue is present");
		if (issuearray == null || issuearray.length() == 0) {
			String error;
			error = "NO issue is present";
			JSONObject finalErrorResponse = new JSONObject();
			finalErrorResponse.put("Error", error);
			System.out.println("NO issue is present");

			return Response.status(200).entity(finalErrorResponse.toString()).header("Content-Type", "application/json")
					.build();
		}
		String boardKey = null;
		for (int i = 0; i < issuearray.length();) {
			if (i == 0) {
				JSONObject zerorow = (JSONObject) issuearray.get(i);
				boardKey = (String) zerorow.get("key");

			}

			break;
		}

		WebResource webResource1 = client.resource(APIConstants.ServerName + APIConstants.IssueKey + boardKey + APIConstants.Username);
		ClientResponse response1 = webResource1.header("Content-Type", "application/json")
				.header("Cookie", authStringEnc).get(ClientResponse.class);
		System.out.println("2nd webservice REsp" + response1.toString());
		System.out.println("response1" + response1);
		String respStr1 = response1.getEntity(String.class);
		System.out.println("respStr1" + respStr1);
		int newresp = response1.getStatus();
		if (newresp == 404) {
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(respStr1);
			while (sc.hasNext()) {
				String line = sc.next();
				if (line.contains("Unauthorised user")) {
					return Response.status(200).entity("Unauthorised user").build();
				}
				break;
			}
		}

		String firstcar = respStr1.substring(0);
		String lastcar = respStr1.substring(respStr1.length() - 1);
		if (!"[".equals(firstcar) && !"]".equals(lastcar)) {

			respStr1 = "[" + respStr1 + "]";
		}
		JSONArray membersList = new JSONArray(respStr1);

		for (int j = 0; j < membersList.length(); j++) {

			JSONObject row = (JSONObject) membersList.get(j);
			JSONObject avatar = (JSONObject) row.get("avatarUrls");
			String avatarUrl = (String) avatar.get("24x24");
			String displayName = (String) row.get("displayName");

			JSONObject finalResponse = new JSONObject();
			finalResponse.put("TeamMembers", displayName);
			finalResponse.put("Avatar", avatarUrl);
			finalResponselist.add(finalResponse);
		}
		return Response.status(200).entity(finalResponselist.toString()).header("Content-Type", "application/json")
				.build();
	}

}
