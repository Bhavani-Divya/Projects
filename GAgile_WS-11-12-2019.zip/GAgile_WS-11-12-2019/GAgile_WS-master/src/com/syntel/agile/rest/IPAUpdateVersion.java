package com.syntel.agile.rest;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import org.apache.poi.util.IOUtils;

@Path("/ipaUpdate")
public class IPAUpdateVersion {

	@GET
	@Path("/download")
	public Response getApkUpdateChangeLog(@Context HttpHeaders headers) {
		System.out.println("Start");
		FileInputStream fios = null;
		try {
			fios = new FileInputStream(System.getProperty("catalina.base") + File.separator + "GAgileFiles"
					+ File.separator + "GAgile.ipa");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		byte[] entity = null;
		try {
			entity = IOUtils.toByteArray(fios);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Response.status(Response.Status.OK).entity(entity)
				.header("Content-Disposition", "attachment; filename=\"GAgile.ipa\"").build();
	}
}
