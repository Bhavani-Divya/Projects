package com.syntel.agile.rest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;

@Path("/getVersionNumber")

public class JIRAappUpdateVersion {
	@GET
	@Path("/{versionNumber}")
	public Response getVerNum(@PathParam("versionNumber") int versionNumber, @Context HttpHeaders headers) {
		final String FILE_NAME = System.getProperty("catalina.base") + File.separator + "GAgileFiles" + File.separator
				+ "Gagile_Version.xlsx";
		int versionnum = versionNumber;
		int Versiondata;
		String Changedata;
		String ChangeLog = "";
		try {
			FileInputStream excelFile = new FileInputStream(new File(FILE_NAME));
			@SuppressWarnings("resource")
			Workbook workbook = new XSSFWorkbook(excelFile);
			Sheet datatypeSheet = workbook.getSheetAt(0);
			int rowCounter = datatypeSheet.getLastRowNum();
			System.out.println("version num greater than given version number and Change Log");
			for (int i = 1; i < rowCounter + 1; i++) {
				Changedata = datatypeSheet.getRow(i).getCell(3).getStringCellValue();
				Versiondata = (int) datatypeSheet.getRow(i).getCell(2).getNumericCellValue();
				if (i == 1) {
					ChangeLog = ChangeLog.concat("[");
				}
				if (versionnum < Versiondata) {
					System.out.println(Versiondata + ":" + (Changedata));
					ChangeLog = ChangeLog.concat("{" + Versiondata + ":" + Changedata + "}");
					if (i < rowCounter) {
						ChangeLog = ChangeLog.concat(",");
					}
				}
				if (i == rowCounter) {
					ChangeLog = ChangeLog.concat("]");
				}
			}
			System.out.println("latest Change Log is " + ChangeLog);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(ChangeLog);
		JSONArray objresponseString1;
		objresponseString1 = new JSONArray(ChangeLog);
		System.out.println(objresponseString1);
		JSONObject combined = new JSONObject();
		combined.put("ChangeLog", objresponseString1);
		return Response.status(200).entity(combined.toString()).header("Content-Type", "application/json").build();
	}
}
