package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeSet;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/getportfoliovelocity")

public class JIRAserviceIssuesPortfolioVelocitySnapshot {

	@SuppressWarnings("rawtypes")
	@GET
	@Path("/{projkey}")
	public Response getTotalStoryPointsIssues(@PathParam("projkey") String projectKey, @Context HttpHeaders headers)
			throws ParseException {
		long totalWorkedDays = 0;
		int totalDays = 0;
		int days = 0;
		Date currentDate1 = null;
		Date startDate = null;
		Date releaseDate = null;
		Date releaseD = null;
		String responseReleaseDateValue = null;
		String responseStartDateValue = null;
		Calendar startCalDate;
		Calendar currentCalDate;
		Calendar endCalDate;
		startCalDate = Calendar.getInstance();
		endCalDate = Calendar.getInstance();
		currentCalDate = Calendar.getInstance();
		String startingDate = null;
		String endingDate = null;
		String currentnewDate = null;
		String startingDat = null;
		String endingDat = null;
		String currentDate = null;
		String releasName = null;
		int seq = 0;
		String teamname = null;
		double totalAssigneeStoryPoints = 0;
		double totalDoneStoryPoints = 0;

		ArrayList<JSONObject> finalResponselist = new ArrayList<>();
		new ArrayList<ArrayList>();
		ArrayList<JSONObject> finalList = new ArrayList<JSONObject>();
		Map<String, ArrayList> finalMap = new HashMap<String, ArrayList>();
		List<String> collectingList = new ArrayList<String>();
		new TreeSet<String>();
		Client client = Client.create();

		headers.getRequestHeaders().keySet();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.out.println(str);
			}
		}
		String authStringEnc = credentialMap.get("Cookie");

		Timestamp timestamp = new Timestamp(System.currentTimeMillis());

		WebResource webResource1 = client.resource(APIConstants.ServerName + APIConstants.ProjectKey + projectKey
				+ APIConstants.ReleaseAllVersions + timestamp.getTime());// project=AIEM
		ClientResponse response1 = webResource1.header("Content-Type", "application/json")
				.header("Cookie", authStringEnc).get(ClientResponse.class);

		String responseString = response1.getEntity(String.class);
		JSONArray responseJsonObjArray = new JSONArray(responseString);
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date dateObj = new Date();
		System.out.println(dateFormat.format(dateObj));
		currentDate = dateFormat.format(dateObj);
		currentDate1 = dateFormat.parse(currentDate);
		currentCalDate.setTime(currentDate1);
		currentnewDate = new SimpleDateFormat("MM-dd-yy").format(currentDate1);
		ArrayList<String> final3 = new ArrayList<>();
		final3.add(currentnewDate);
		finalMap.put("teamdata", final3);
		for (int q = 0; q < responseJsonObjArray.length(); q++) {
			JSONObject responseJsonObjRow = (JSONObject) responseJsonObjArray.get(q);
			JSONObject responseStartDate = (JSONObject) responseJsonObjRow.get("startDate");
			if (!(responseStartDate.getString("iso").length() == 0)) {
				responseStartDateValue = responseStartDate.getString("iso");
				System.out.println(responseStartDateValue);
				System.out.println(startDate);
				startDate = dateFormat.parse(responseStartDateValue);
				// After passing with time "startDate"
				startingDat = new SimpleDateFormat("MM-dd-yy").format(startDate);
				// Just changing the format "startingDate"
				startCalDate.setTime(startDate);
				System.out.println(startCalDate);
				System.out.println(responseStartDateValue);
				JSONObject responseReleaseDate = (JSONObject) responseJsonObjRow.get("releaseDate");
				responseReleaseDateValue = responseReleaseDate.getString("iso");
				System.out.println(responseReleaseDateValue);
				releaseDate = dateFormat.parse(responseReleaseDateValue);
				endingDat = new SimpleDateFormat("MM-dd-yy").format(releaseDate);
				endCalDate.setTime(releaseDate);
				System.out.println(releaseDate);
				System.out.println(responseReleaseDateValue);
				if (startDate.before(currentDate1) && releaseDate.after(currentDate1)
						|| releaseDate.equals(currentDate1) || startDate.equals(currentDate1)) {
					startingDate = startingDat;
					endingDate = endingDat;
					releaseD = releaseDate;
					do {
						startCalDate.add(Calendar.DAY_OF_MONTH, 1);
						if (startCalDate.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
								&& startCalDate.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
							++totalWorkedDays;
						}

					} while (startCalDate.getTimeInMillis() < currentCalDate.getTimeInMillis());

					do {

						startCalDate.add(Calendar.DAY_OF_MONTH, 1);
						if (startCalDate.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY
								&& startCalDate.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
							++totalDays;
						}
					} while (startCalDate.getTimeInMillis() < endCalDate.getTimeInMillis());

					totalDays = (int) (totalDays + totalWorkedDays);
					System.out.println("TotalDays Are:" + totalDays);

					break;
				} else {
					System.out.println("There id no current Relesase");

				}

			}

			else {
				System.out.println("Please Enter the Start Date");

			}
		}

		WebResource webResource = client.resource(APIConstants.ServerName + APIConstants.ViewData);

		ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc)
				.get(ClientResponse.class);
		String responseString1 = response.getEntity(String.class);
		JSONObject objresponseString1 = new JSONObject(responseString1);
		JSONArray viewsArray = objresponseString1.getJSONArray("views");
		boolean flag = true;
		System.out.println("1Outside For loop");

		for (int z = 0; z < viewsArray.length(); z++) {
			JSONObject viewsRow = (JSONObject) viewsArray.get(z);
			System.out.println("viewsRow" + viewsRow);
			boolean projFlag = (boolean) viewsRow.get("isSimpleQueryBoard");
			System.out.println("projFlag" + projFlag);
			JSONObject filterProject = (JSONObject) viewsRow.get("filter");
			System.out.println("filterProj" + filterProject);
			JSONObject objFilterProject = new JSONObject(filterProject);
			System.out.println(objFilterProject);
			JSONObject queryProject = (JSONObject) filterProject.get("queryProjects");
			System.out.println("queryProj" + queryProject);
			JSONArray projectArray = (JSONArray) queryProject.getJSONArray("projects");
			System.out.println("projectArray" + projectArray);
			for (int k = 0; k < projectArray.length(); k++) {
				JSONObject projectRow = (JSONObject) projectArray.get(k);
				String projectRowKey = (String) projectRow.get("key");
				if (projectRowKey.equals(projectKey) && projFlag == false) {
					flag = false;
					break;
				}
			}

		}

		for (int i = 0; i < viewsArray.length(); i++) {
			System.out.println("1Inside For loop");
			JSONObject viewsRow = (JSONObject) viewsArray.get(i);
			System.out.println("viewsRow" + viewsRow);
			boolean projectFlag = (boolean) viewsRow.get("isSimpleQueryBoard");
			String boardName = (String) viewsRow.get("name");
			System.out.println("projFlag" + projectFlag);
			JSONObject filterProject = (JSONObject) viewsRow.get("filter");
			System.out.println("filterProj" + filterProject);
			JSONObject objFilterProject = new JSONObject(filterProject);
			System.out.println(objFilterProject);
			JSONObject queryProject = (JSONObject) filterProject.get("queryProjects");
			System.out.println("queryProj" + queryProject);
			JSONArray projectArray = (JSONArray) queryProject.getJSONArray("projects");
			System.out.println("projectArray" + projectArray);
			System.out.println("2outside For loop");
			for (int k = 0; k < projectArray.length(); k++) {
				JSONObject projectRow = (JSONObject) projectArray.get(k);
				String projectRowKey = (String) projectRow.get("key");
				System.out.println("2Inside For loop");
				System.out.println("projRowKeyFinal" + projectRowKey);
				System.out.println("projkeyFinal" + projectKey);
				if (projectRowKey.equals(projectKey) && projectFlag == false) {

					teamname = boardName;
					System.out.println("Inside if loop");
					System.out.println("projRowKey is" + projectRowKey);
					System.out.println("Inside if loop");
					int boardId = viewsRow.getInt("id");
					System.out.println("id is" + boardId);
					WebResource webResourceBoardDetails = client.resource(APIConstants.ServerName + APIConstants.BoardID
							+ boardId + APIConstants.IssueJQL + projectKey + APIConstants.MaxResult);
					ClientResponse responseBoardDetails = webResourceBoardDetails
							.header("Content-Type", "application/json").header("Cookie", authStringEnc)
							.get(ClientResponse.class);
					String responseBoard = responseBoardDetails.getEntity(String.class);
					JSONObject object = new JSONObject(responseBoard);
					JSONArray issuearray = object.getJSONArray("issues");
					double tempUnassigneeStoryPoints = 0;
					double doneTotalStoryPoints = 0;
					for (int j = 0; j < issuearray.length(); j++) {

						JSONObject zeroRow = (JSONObject) issuearray.get(j);
						JSONObject zeroRowFields = zeroRow.getJSONObject("fields");
						String zeroRowKey = (String) zeroRow.get("key");
						JSONObject issueType = (JSONObject) zeroRowFields.get("issuetype");
						String issueTypeName = (String) issueType.get("name");

						if (zeroRowFields.get("fixVersions") != null
								|| zeroRowFields.getJSONArray("fixVersions") != null) {

							JSONArray newrFixedVersion = zeroRowFields.getJSONArray("fixVersions");
							for (int s = 0; s < newrFixedVersion.length(); s++) {

								JSONObject zeroRow1 = (JSONObject) newrFixedVersion.get(s);
								if (zeroRow1.has("releaseDate")) {

									String zeroRowReleaseDate = (String) zeroRow1.get("releaseDate");
									Date releaseDate1 = dateFormat.parse(zeroRowReleaseDate);
									Date dateObj1 = new Date();
									System.out.println(dateFormat.format(dateObj1));
									String a = dateFormat.format(dateObj1);
									dateFormat.parse(a);

									if (!collectingList.contains(zeroRowKey)) {
										if (releaseDate1.equals(releaseD)) {

											if (issueTypeName.equals("Story")) {
												releasName = (String) zeroRow1.get("name");
												collectingList.add(zeroRowKey);
												if (zeroRowFields.has("customfield_10200")
														&& !zeroRowFields.get("customfield_10200").equals(null)) {
													double unassigneestoryPointJson = (double) zeroRowFields
															.get("customfield_10200");

													tempUnassigneeStoryPoints = unassigneestoryPointJson
															+ tempUnassigneeStoryPoints;

													System.out.println("key Inside issue:" + zeroRowKey);
													System.out.println("key Inside issue story count:"
															+ tempUnassigneeStoryPoints);

												}

												if (!zeroRowFields.get("resolution").equals(null)) {

													if (zeroRowFields.has("customfield_10200")
															&& !zeroRowFields.get("customfield_10200").equals(null)) {
														double unassigneestoryPointJson = (double) zeroRowFields
																.get("customfield_10200");

														doneTotalStoryPoints = unassigneestoryPointJson
																+ doneTotalStoryPoints;
														Math.round((int) (doneTotalStoryPoints
																/ tempUnassigneeStoryPoints * 100));
														System.out.println(" Done issue:" + zeroRowKey);
														System.out.println(" Done issue Count:" + doneTotalStoryPoints);

													}

												}

											}
										}
									}
								} else {
									System.out.println("release Date not present");
								}
							}
						}

					}
					totalAssigneeStoryPoints = totalAssigneeStoryPoints + tempUnassigneeStoryPoints;
					totalDoneStoryPoints = totalDoneStoryPoints + doneTotalStoryPoints;
					JSONObject finalResponse = new JSONObject();
					finalResponse.put("teamName", teamname);
					finalResponse.put("donetotalStoryPoints", doneTotalStoryPoints);
					finalResponse.put("releasName", releasName);
					finalResponse.put("totalStoryPoints", tempUnassigneeStoryPoints);
					finalResponselist.add(finalResponse);

				} else if (projectRowKey.equals(projectKey) && !projectFlag == false && boardName.contains(projectKey)
						&& flag == true) {
					teamname = boardName;
					System.out.println("Inside if loop");
					System.out.println("projRowKey is" + projectRowKey);
					System.out.println("Inside if loop");
					int boardId = viewsRow.getInt("id");
					System.out.println("id is" + boardId);
					WebResource webResourceBoardDetails = client.resource(APIConstants.ServerName + APIConstants.BoardID
							+ boardId + APIConstants.IssueJQL + projectKey + APIConstants.MaxResult);
					ClientResponse responseBoardDetails = webResourceBoardDetails
							.header("Content-Type", "application/json").header("Cookie", authStringEnc)
							.get(ClientResponse.class);
					String responseBoard = responseBoardDetails.getEntity(String.class);
					JSONObject object = new JSONObject(responseBoard);
					JSONArray issuearray = object.getJSONArray("issues");
					double tempunassigneeStoryPoints = 0;

					double donetotalStoryPoints = 0;
					for (int j = 0; j < issuearray.length(); j++) {

						JSONObject zeroRow = (JSONObject) issuearray.get(j);
						JSONObject zeroRowFields = zeroRow.getJSONObject("fields");
						String zeroRowKey = (String) zeroRow.get("key");
						JSONObject issueType = (JSONObject) zeroRowFields.get("issuetype");
						String issueTypeName = (String) issueType.get("name");

						if (zeroRowFields.get("fixVersions") != null
								|| zeroRowFields.getJSONArray("fixVersions") != null) {

							JSONArray newrFixedVersion = zeroRowFields.getJSONArray("fixVersions");
							for (int s = 0; s < newrFixedVersion.length(); s++) {

								JSONObject zeroRow1 = (JSONObject) newrFixedVersion.get(s);
								if (zeroRow1.has("releaseDate")) {
									String zeroRowReleaseDate = (String) zeroRow1.get("releaseDate");
									Date releaseDate1 = dateFormat.parse(zeroRowReleaseDate);
									Date dateObj1 = new Date();
									System.out.println(dateFormat.format(dateObj1));
									String a = dateFormat.format(dateObj1);
									dateFormat.parse(a);

									if (!collectingList.contains(zeroRowKey)) {

										if (releaseDate1.equals(releaseD)) {

											if (issueTypeName.equals("Story")) {
												releasName = (String) zeroRow1.get("name");
												collectingList.add(zeroRowKey);
												if (zeroRowFields.has("customfield_10200")
														&& !zeroRowFields.get("customfield_10200").equals(null)) {
													double unassigneestoryPointJson = (double) zeroRowFields
															.get("customfield_10200");

													tempunassigneeStoryPoints = unassigneestoryPointJson
															+ tempunassigneeStoryPoints;

													System.out.println("key Inside issue:" + zeroRowKey);
													System.out.println("key Inside issue story count:"
															+ tempunassigneeStoryPoints);

												}

												if (!zeroRowFields.get("resolution").equals(null)) {

													if (zeroRowFields.has("customfield_10200")
															&& !zeroRowFields.get("customfield_10200").equals(null)) {
														double unassigneestoryPointJson = (double) zeroRowFields
																.get("customfield_10200");
														donetotalStoryPoints = unassigneestoryPointJson
																+ donetotalStoryPoints;
														Math.round((int) (donetotalStoryPoints
																/ tempunassigneeStoryPoints * 100));
														System.out.println(" Done issue:" + zeroRowKey);
														System.out.println(" Done issue Count:" + donetotalStoryPoints);

													}

												}

											}
										}
									}
								} else {
									System.out.println("release Date not present");
								}
							}
						}

					}
					totalAssigneeStoryPoints = totalAssigneeStoryPoints + tempunassigneeStoryPoints;
					totalDoneStoryPoints = totalDoneStoryPoints + donetotalStoryPoints;

					JSONObject finalResponse = new JSONObject();
					finalResponse.put("teamName", teamname);
					finalResponse.put("donetotalStoryPoints", donetotalStoryPoints);
					finalResponse.put("releasName", releasName);
					finalResponse.put("totalStoryPoints", tempunassigneeStoryPoints);

					finalResponselist.add(finalResponse);

					break;
				}

			}
		}

		System.out.println("Second ********************************************LOOP");
		for (int i = 0; i < viewsArray.length(); i++) {
			System.out.println("1Inside For loop");
			JSONObject viewsRow = (JSONObject) viewsArray.get(i);
			System.out.println("viewsRow" + viewsRow);
			boolean projectFlag = (boolean) viewsRow.get("isSimpleQueryBoard");
			System.out.println("projFlag" + projectFlag);
			JSONObject filterProject = (JSONObject) viewsRow.get("filter");
			System.out.println("filterProj" + filterProject);
			JSONObject objFilterProject = new JSONObject(filterProject);
			System.out.println(objFilterProject);
			boolean queryCanEdit = (boolean) filterProject.get("canEdit");
			System.out.println("queryCanEdit************" + queryCanEdit);
			JSONObject queryProject = (JSONObject) filterProject.get("queryProjects");
			System.out.println("queryProj" + queryProject);
			JSONArray projectArray = (JSONArray) queryProject.getJSONArray("projects");
			System.out.println("projectArray" + projectArray);
			System.out.println("2outside For loop");
			for (int k = 0; k < projectArray.length(); k++) {
				JSONObject projectRow = (JSONObject) projectArray.get(k);
				String projectRowKey = (String) projectRow.get("key");
				System.out.println("2Inside For loop");
				System.out.println("projRowKeyFinal" + projectRowKey);
				System.out.println("projkeyFinal" + projectKey);
				if (projectRowKey.equals(projectKey) && projectFlag == true) {
					System.out.println("queryCanEdit*******INSIDE***********" + queryCanEdit);
					System.out.println("Inside if loop");
					System.out.println("projRowKey is" + projectRowKey);
					System.out.println("Inside if loop");
					int boardId = viewsRow.getInt("id");
					System.out.println("id is" + boardId);
					WebResource webResource2 = client.resource(APIConstants.ServerName + APIConstants.BacklogData
							+ boardId + APIConstants.SelectedProjectKey + projectKey + "");
					ClientResponse response2 = webResource2.header("Content-Type", "application/json")
							.header("Cookie", authStringEnc).get(ClientResponse.class);

					String responseString2 = response2.getEntity(String.class);
					JSONObject objResponseString2 = new JSONObject(responseString2);
					JSONArray releaseArray = objResponseString2.getJSONArray("issues");
					for (int p = 0; p < releaseArray.length(); p++) {

						JSONObject responseJsonRow = (JSONObject) releaseArray.get(p);
						int projectId = responseJsonRow.getInt("projectId");
						String releaseKey = Integer.toString(projectId);
						JSONObject versionData = (JSONObject) objResponseString2.get("versionData");
						JSONObject versionsPerProject = (JSONObject) versionData.get("versionsPerProject");
						if (!(versionsPerProject.toString().equals("{}"))) {
							JSONArray releaseKeyArray = versionsPerProject.getJSONArray(releaseKey);
							for (int o = 0; o < releaseKeyArray.length(); o++) {

								JSONObject responseJsonObjrow = (JSONObject) releaseKeyArray.get(o);
								if (responseJsonObjrow.has("startDate")) {

									long startDateRow = (long) responseJsonObjrow.get("startDate");
									long releaseDateRow = (long) responseJsonObjrow.get("releaseDate");
									System.out.println(startDateRow);
									Date startDateRowConvert = new Date(startDateRow);
									Date releaseDateRowConvert = new Date(releaseDateRow);
									System.out.println(startDateRowConvert);
									String startdat = dateFormat.format(startDateRowConvert);
									String releasedat = dateFormat.format(releaseDateRowConvert);
									if (releasedat.compareTo(startdat) <= 0) {
									}
									if (releasedat.compareTo(currentDate) == 0) {
									}
									if (startdat.compareTo(currentDate) == 0) {
									}
									if (releasedat.compareTo(startdat) >= 0) {
									}
									Date dateobjj = new Date();
									System.out.println(dateFormat.format(dateobjj));
									// Thu Feb 08 16:39:11 IST 2018 "dateobj"
									currentDate = dateFormat.format(dateobjj);
									if (releasedat.compareTo(currentDate) == 0 || startdat.compareTo(currentDate) == 0
											|| startdat.compareTo(currentDate) <= 0
													&& releasedat.compareTo(currentDate) >= 0) {
										seq = (int) responseJsonObjrow.get("sequence");
									}
								} else {
									System.out.println("Start Date not present");

								}

							}
						}
					}

				}

			}

		}
		JSONObject finalResponse = new JSONObject();
		days = totalDays;
		finalResponse.put("totalStoryPoints", totalDoneStoryPoints);
		finalResponse.put("seq", seq);
		finalResponse.put("totalEstimate", totalAssigneeStoryPoints);
		finalResponse.put("currentDate", currentnewDate);
		finalResponse.put("totalDays", days);
		finalResponse.put("workedDays", totalWorkedDays);
		finalResponse.put("startdate", startingDate);
		finalResponse.put("endDate", endingDate);
		finalList.add(finalResponse);
		finalMap.put("teamdata", finalList);
		finalMap.put("velocitydata", finalResponselist);
		JSONObject final2 = new JSONObject(finalMap);
		return Response.status(200).entity(final2.toString()).header("Content-Type", "application/json").build();
	}
}
