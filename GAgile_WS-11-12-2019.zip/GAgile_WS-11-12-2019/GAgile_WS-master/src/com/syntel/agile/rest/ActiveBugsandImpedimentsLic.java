package com.syntel.agile.rest;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/ActiveBugsandImpedimentslic")

public class ActiveBugsandImpedimentsLic {

	@GET
	@Path("/{id}/{projectKey}")
	public Response getActiveBugsandImpediments(@PathParam("id") String boardId,
			@PathParam("projectKey") String projectKey, @Context HttpHeaders headers) throws JSONException {
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.err.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");

		Client client = Client.create();
		// boardId=15 projectKey=AIEM
		WebResource webResource = client
				.resource(APIConstants.ServerName + APIConstants.BacklogData + boardId + APIConstants.SelectedProjectKey + projectKey + "");

		ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc)
				.get(ClientResponse.class);

		double bugs = 0;
		double impediment = 0;
		String responseString = response.getEntity(String.class);
		System.out.println("Response " + response);
		System.out.println("ResponseStr " + responseString);
		JSONObject objResponseString;
		objResponseString = new JSONObject(responseString);
		System.out.println(objResponseString);

		JSONArray issues = (JSONArray) objResponseString.get("issues");

		for (int k = 0; k < issues.length(); k++) {
			JSONObject value = (JSONObject) issues.get(k);
			String typeName = (String) value.get("typeName");
			System.out.println(typeName);
			Boolean done = (Boolean) value.get("done");
			System.out.println(done);
			if ((typeName.equals(APIConstants.BUGS)) && (done.equals(false)))
				bugs++;

			if ((typeName.equals("Impediment")) && (done.equals(false)))
				impediment++;

		}

		JSONObject finalResponse = new JSONObject();
		finalResponse.put("Active Bug", bugs);
		finalResponse.put("Impediment", impediment);
		System.out.println("Output from Server .... \n" + finalResponse);
		client.destroy();
		return Response.status(200).entity(finalResponse.toString()).header("Content-Type", "application/json").build();

	}

}
