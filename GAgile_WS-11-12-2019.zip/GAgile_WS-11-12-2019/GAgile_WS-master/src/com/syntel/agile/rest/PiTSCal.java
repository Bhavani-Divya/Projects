package com.syntel.agile.rest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/pitscal")

public class PiTSCal {

	@SuppressWarnings("null")
	@GET
	@Path("/{rid}/{projectKey}")
	public Response getAllsprintidvalue(@PathParam("rid") String rapidViewId,
			@PathParam("projectKey") String projectKey, @PathParam("activeSprints") String activeSprints,
			@Context HttpHeaders headers) throws JSONException, ParseException {

		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.err.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();

		WebResource webResource1 = client
				.resource(APIConstants.ServerName + APIConstants.SprintQuery + rapidViewId + "");// rapidViewId=15

		ClientResponse response = webResource1.header("Content-Type", "application/json")
				.header("Cookie", authStringEnc).get(ClientResponse.class);
		double bval = 0.0, obval = 0.0;
		HashMap<String, Boolean> allstory = new HashMap<String, Boolean>();
		List<Double> totalremainingstoryhr = new ArrayList<Double>();

		Double valueval = 0.0;
		Double overallval = 0.0, toverallval = 0.0;
		Double dsoverallval = 0.0, dstotaldonevalhr = 0.0;
		Double totaldonevalhr = 0.0, ttotaldonevalhr = 0.0;

		Double svalueval = 0.0, soverallval = 0.0, stotaldonevalhr = 0.0, sttotaldonevalhr = 0.0;
		Double dsvalueval = 0.0;
		Double snvalueval = 0.0, snoverallval = 0.0, sntotaldonevalhr = 0.0, stoverallval = 0.0;

		String responseString = response.getEntity(String.class);
		System.out.println("Response " + response);
		System.out.println("ResponseStr " + responseString);
		JSONObject objResponseString;
		objResponseString = new JSONObject(responseString);

		JSONArray sprints = (JSONArray) objResponseString.get("sprints");
		JSONArray issuesNotCompletedInCurrentSprint1;
		int sprintLength = sprints.length();
		System.out.println("sprintlength" + sprintLength);
		int count = sprintLength;
		System.out.println("count" + count);
		double toverallvalarr[] = new double[sprintLength];
		double stoverallvalarr[] = new double[sprintLength];
		double dstoverallvalarr[] = new double[sprintLength];
		double tstoverallvalar[] = new double[sprintLength];
		double totalHours = 0.0, totalhrs6; // 215
		double overalltotalhrs, overalltotalhrs6; // 216
		double doneValue, donevalue6; // 215
		double doneCount = 0, donecount6 = 0;
		double donevallen6;
		String[] str = new String[count];
		double[] spenthrs = new double[count], spenthrs6 = new double[count];
		double[] remaininghrs = new double[count], remaininghrs6 = new double[count];
		Set<Double> set = new HashSet<Double>();
		Set<Double> set1 = new HashSet<Double>();
		Set<Double> set11 = new HashSet<Double>();
		Set<Double> set16 = new HashSet<Double>();
		Set<String> set3 = new HashSet<String>();
		double[] ts = new double[count];
		List<Double> donestory = new ArrayList<Double>();//
		List<Double> totalstory = new ArrayList<Double>();
		List<Double> totalremainingstory = new ArrayList<Double>();
		List<Double> list = new ArrayList<Double>();
		List<Double> list1 = new ArrayList<Double>();
		List<Double> list11 = new ArrayList<Double>();
		List<Double> list16 = new ArrayList<Double>();
		List<String> list2 = new ArrayList<String>();
		List<Double> sprintIdFinal = new ArrayList<Double>();
		List<String> sprintNameFinal = new ArrayList<String>();
		double[] spintIdArray = new double[count];
		double sprintIdLength = 0.0; // 496
		String[] sprintNameArray = new String[count];
		String endDateFormatCustom = null;
		String startDateFormatCustom = null, strDateSprint, endDateSprintFinal;
		Integer sequence = 0;
		String name;
		String startDateFormatCustom1 = null;
		String endDateFormatCustom1 = null;

		Date currentDay = null;
		Date startDateFinal = null;
		Date endDateFinal = null;
		boolean val = false;
		Integer projectId1 = null;
		String releaseStartDate1 = null, releaseEndDate1 = null;
		String releaseStartDate = null, releaseEndDate = null;
		@SuppressWarnings("unused")
		String startDateFinalValue = null;
		Integer sprintId = 0;
		String sprintName = null;
		int idvalfinals[] = new int[count]; // 683
		Integer projectId = 0;
		double doneEstimate;
		double doneTotalHour;
		double totalDoneHours = 0;

		String endDateFinalValue = null;
		@SuppressWarnings("unused")
		String currentdayfinalval = null;

		if (sprintLength != 0) {
			// rapidViewId=15 projectKey=AIEM

			WebResource webResource3 = client.resource(APIConstants.ServerName + APIConstants.BacklogData + rapidViewId
					+ APIConstants.SelectedProjectKey + projectKey + "");

			ClientResponse response1 = webResource3.header("Content-Type", "application/json")
					.header("Cookie", authStringEnc).get(ClientResponse.class);

			String responseString1 = response1.getEntity(String.class);
			System.out.println("Response " + response1);
			System.out.println("ResponseStr " + responseString1);
			JSONObject objResponseString1;
			objResponseString1 = new JSONObject(responseString1);
			JSONArray issues = (JSONArray) objResponseString1.get("issues");
			int issuesLength = issues.length();

			JSONArray projects = (JSONArray) objResponseString1.get("projects");
			for (int i = 0; i < 1; i++) {
				JSONObject objProjects = (JSONObject) projects.get(i);
				projectId = (Integer) objProjects.get("id");
				System.out.println();
			}

			for (int i = 0; i < issuesLength; i++) {
				JSONObject val1 = (JSONObject) issues.get(i);
				projectId = (Integer) val1.get("projectId");
				System.out.println("proj id is:" + projectId);
			}

			JSONObject versionData = (JSONObject) objResponseString1.get("versionData");
			System.out.println("version Data" + versionData);
			String projectIdValue = null;
			if (projectId != 0) {
				projectIdValue = Integer.toString(projectId);
				System.out.println("projidval" + projectIdValue);
			} else {
				projectIdValue = Integer.toString(projectId1);
				System.out.println("projidval" + projectIdValue);
			}

			JSONObject versionsPerProject = (JSONObject) versionData.get("versionsPerProject");
			System.out.println("versionsPerProject" + versionsPerProject);
			JSONArray versionsPerProjectId = versionsPerProject.getJSONArray(projectIdValue);
			int versionsPerProjectIdLength = versionsPerProjectId.length();

			JSONObject versionStatus;
			System.out.println("rellength" + versionsPerProjectIdLength);

			if (versionsPerProjectIdLength != 0) {

				for (int i = 0; i < versionsPerProjectIdLength; i++) { // iterate through jsonArray
					JSONObject objversionsPerProjectId = (JSONObject) versionsPerProjectId.get(i); // get jsonObject @ i
																									// position
					System.out.println("jsonObject " + i + ": " + objversionsPerProjectId + "size>>"
							+ objversionsPerProjectId.length());

					if (objversionsPerProjectId.has("releaseDateFormatted")) {
						String releaseDateFormatted = (String) objversionsPerProjectId.get("releaseDateFormatted");
						System.out.println("rel date" + releaseDateFormatted);
					}

					Set<String> keys1 = objversionsPerProjectId.keySet();
					Iterator<String> a1 = keys1.iterator();
					while (a1.hasNext()) {
						String key1 = (String) a1.next();
						// loop to get the dynamic key
						if (key1.equalsIgnoreCase("released")) {
							boolean value = (Boolean) objversionsPerProjectId.get(key1);
							if (!value) {
								System.out.println("!value = " + !value);
								val = !value;
								System.out.println("val = " + val);
								sequence = (Integer) objversionsPerProjectId.get("sequence");
								name = (String) objversionsPerProjectId.get("name");
								String releaseDateFormatted = null;
								String startDateFormatted = null;
								if (objversionsPerProjectId.has("releaseDateFormatted")
										&& objversionsPerProjectId.has("startDateFormatted")) {

									releaseDateFormatted = (String) objversionsPerProjectId.get("releaseDateFormatted");
									startDateFormatted = (String) objversionsPerProjectId.get("startDateFormatted");
									System.out.println("\n seq>>" + sequence + " and name" + name);
									System.out.println("\n startDateFormatted>>" + startDateFormatted
											+ " and releaseDateFormatted" + releaseDateFormatted);
									LocalDateTime localDateTime = LocalDateTime.now();
									DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yy");

									String formatterLocalDateTime = localDateTime.format(formatter);
									System.out.println(formatterLocalDateTime);

									SimpleDateFormat format = new SimpleDateFormat("dd/MMM/yy");
									SimpleDateFormat formatCustom = new SimpleDateFormat("MM/dd/yy");
									Date startDateFormat = format.parse(
											(String) objversionsPerProjectId.get("startDateFormatted").toString());
									System.out.println(startDateFormat);
									startDateFormatCustom = formatCustom.format(startDateFormat);
									System.out.println("startDate" + startDateFormat);
									Date endDateFormat = format.parse(
											(String) objversionsPerProjectId.get("releaseDateFormatted").toString());
									System.out.println("endDate" + endDateFormat);
									endDateFormatCustom = formatCustom.format(endDateFormat);
									System.out.println("enddate" + endDateFormatCustom);

									SimpleDateFormat formatCustom1 = new SimpleDateFormat("MMM yy");
									Date startDateFormat1 = format.parse(
											(String) objversionsPerProjectId.get("startDateFormatted").toString());
									System.out.println(startDateFormat1);
									startDateFormatCustom1 = formatCustom1.format(startDateFormat1);
									System.out.println(startDateFormatCustom1);

									Date endDateFormat1 = format.parse(
											(String) objversionsPerProjectId.get("releaseDateFormatted").toString());
									System.out.println(endDateFormat1);
									endDateFormatCustom1 = formatCustom1.format(endDateFormat1);
									System.out.println(endDateFormatCustom1);
									String today = formatterLocalDateTime;
									endDateFinal = endDateFormat;
									System.out.println("enddatefinal" + endDateFinal);
									startDateFinal = startDateFormat;
									System.out.println("startdatefinal" + startDateFinal);

									currentDay = formatCustom.parse(today);
									System.out.println("currentday" + currentDay);

									System.out.println("enddatefinal : " + formatCustom.format(endDateFinal));
									System.out.println("startdatefinal : " + formatCustom.format(startDateFinal));
									System.out.println("currentday : " + formatCustom.format(currentDay));

									endDateFinalValue = formatCustom.format(endDateFinal);
									System.out.println("enddatefinalval" + endDateFinalValue);
									startDateFinalValue = formatCustom.format(startDateFinal);
									currentdayfinalval = formatCustom.format(currentDay);

									if (startDateFinal.compareTo(currentDay) <= 0
											&& endDateFinal.compareTo(currentDay) >= 0) {
										System.out
												.println("Date is" + startDateFormatCustom + "-" + endDateFormatCustom);
										System.out.println("Release :" + sequence);
										System.out.println("startdate is:" + startDateFormatCustom1);
										System.out.println("enddate is:" + endDateFormatCustom1);

										releaseStartDate = startDateFormatCustom;
										releaseEndDate = endDateFormatCustom;
										releaseStartDate1 = startDateFormatCustom1;
										releaseEndDate1 = endDateFormatCustom1;
										System.out.println("spent hr is :" + set);
										System.out.println("rem hr is :" + set1);
										System.out.println("sprint name is :" + set3);

										versionStatus = (JSONObject) objversionsPerProjectId.get("versionStats");
										System.out.println("versionStats" + versionStatus);
										doneEstimate = (Double) versionStatus.get("doneEstimate");
										System.out.println("doneEstimate" + doneEstimate);
										doneTotalHour = doneEstimate * 6;
										System.out.println("donetotalhr" + doneTotalHour);
										totalDoneHours = doneTotalHour;
										System.out.println("totaldonehrs" + totalDoneHours);

									} else {
										System.out.println("no release date is there");
									}

								} else {
									System.out.println("no current release setup");
								}
							} else {
								System.out.println("release date are not available not set up yet");
							}
						}
					}
				}
			}

			for (int i = 0; i < sprintLength; i++) {

				JSONObject objSprints = (JSONObject) sprints.get(i); // get jsonObject @ i position
				System.out.println("\n jsonObject " + i + ": " + objSprints + "size>>" + objSprints.length());
				Set<String> keys = objSprints.keySet();
				Iterator<String> a = keys.iterator();
				int keyValue;
				String nameValue;

				// To get the Key value from sprints and to pass that to next API
				while (a.hasNext()) {

					String key = (String) a.next();
					System.out.print("\n key : " + key);

					if (key.equalsIgnoreCase("id")) {
						keyValue = (Integer) objSprints.get("id");
						System.out.println("\n keyValue>>" + keyValue);
						if (key.equalsIgnoreCase("name")) {

							nameValue = (String) objSprints.get("name");
							System.out.println("\n nameValue>>" + nameValue);

						}
						// rapidViewId=15 SprintId=26
						WebResource webResource2 = client.resource(APIConstants.ServerName + APIConstants.SprintReport
								+ rapidViewId + APIConstants.SprintID + keyValue + "");

						ClientResponse response2 = webResource2.header("Content-Type", "application/json")
								.header("Cookie", authStringEnc).get(ClientResponse.class);

						String responseString2 = response2.getEntity(String.class);
						System.out.println("Response2 " + response2);
						System.out.println("ResponseStr2 " + responseString2);
						JSONObject objResponseString2;
						objResponseString2 = new JSONObject(responseString2);

						JSONObject sprintValue = (JSONObject) objResponseString2.get("sprint");
						String namevalue = (String) sprintValue.get("name");
						Integer idValue = (Integer) sprintValue.get("id");

						System.out.println("nameval" + namevalue);
						System.out.println("idval" + idValue); // contents

						JSONObject contents = (JSONObject) objResponseString2.get("contents");
						System.out.println("contents" + contents);

						JSONArray completedIssues = (JSONArray) contents.get("completedIssues");
						System.out.println("completedIssues" + completedIssues);

						double completedIssuesLength = completedIssues.length();

						System.out.println("completedIssueslength" + completedIssuesLength);

						for (int j = 0; j < completedIssues.length(); j++) {

							JSONObject objCompletedIssues = (JSONObject) completedIssues.get(j);
							if (objCompletedIssues.getString("statusName").equals("Done")
									&& (objCompletedIssues.getString("typeName").equals("Story"))) {

								String doneKey = (String) objCompletedIssues.get("key");
								System.out.println("donekey = " + doneKey);
								doneCount = doneCount + 1;
								System.out.println("donevalue = " + doneCount);
							}
						}

						JSONObject completedIssuesEstimateSum = (JSONObject) contents.get("completedIssuesEstimateSum");
						System.out.println("completedIssuesEstimateSum" + completedIssuesEstimateSum);
						double completedIssuesEstimateSumLength = completedIssuesEstimateSum.length();
						System.out.println("completedIssuesEstimateSumLength = " + completedIssuesEstimateSumLength);
						String startDateSprint;
						String endDatesprint;

						if (completedIssuesEstimateSumLength <= 1) {

							System.out.println("No done Story are current in sprint");
							doneValue = 0;
							totalHours = doneValue * 6;
							overalltotalhrs = totalDoneHours - totalHours;
							System.out.println("spent hrs" + totalHours);
							System.out.println("remaining hrs" + overalltotalhrs);

							startDateSprint = (String) sprintValue.get("startDate");
							System.out.println("startdate = " + startDateSprint);
							endDatesprint = (String) sprintValue.get("endDate");
							System.out.println("enddate = " + endDatesprint);

							SimpleDateFormat format = new SimpleDateFormat("dd/MMM/yy");
							SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yy"); // dd/MM
							Date startDate = format.parse((String) sprintValue.get("startDate").toString());
							System.out.println(startDate);
							strDateSprint = formatter.format(startDate);
							System.out.println("strDateSprint" + strDateSprint);
							Date formatEndDateSprint = format.parse((String) sprintValue.get("endDate").toString());
							System.out.println(formatEndDateSprint);
							endDateSprintFinal = formatter.format(formatEndDateSprint);
							System.out.println("endDateSprint" + endDateSprintFinal);

							System.out.println("startDate & End date" + startDate + "" + formatEndDateSprint);
							System.out.println("relDate" + startDateFinal + "" + endDateFinal);
							if (startDateFinal != null && endDateFinal != null) {

								if (startDateFinal.compareTo(startDate) <= 0
										&& endDateFinal.compareTo(formatEndDateSprint) >= 0) {
									sprintId = (Integer) sprintValue.get("id");
									System.out.println("idval =" + sprintId);
									sprintName = (String) sprintValue.get("name");
									System.out.println("nameval =" + sprintName);
									spintIdArray[i] = sprintId;
									sprintNameArray[i] = sprintName;
									sprintIdFinal.add(spintIdArray[i]);
									System.out.println("nofinalval =" + sprintIdFinal);
									sprintNameFinal.add(sprintNameArray[i]);
									System.out.println("namefinalval =" + sprintNameFinal);

									sprintIdLength = spintIdArray.length;

									System.out.println("nofinalvallen" + sprintIdLength);

									WebResource webResource6 = client.resource(APIConstants.ServerName + APIConstants.SprintReport + rapidViewId
											+ APIConstants.SprintID + sprintId + "");

									ClientResponse response3 = webResource6.header("Content-Type", "application/json")
											.header("Cookie", authStringEnc).get(ClientResponse.class);
									String responseString3 = response3.getEntity(String.class);
									System.out.println("Response6 " + response3);
									System.out.println("ResponseStr6 " + responseString3);
									JSONObject objResponseString3;
									objResponseString3 = new JSONObject(responseString3);

									JSONObject sprintValue1 = (JSONObject) objResponseString3.get("sprint");
									String nameval6 = (String) sprintValue1.get("name");
									Integer idval6 = (Integer) sprintValue1.get("id");

									System.out.println("nameval is:" + nameval6);
									System.out.println("idval is:" + idval6); // contents

									JSONObject contents6 = (JSONObject) objResponseString3.get("contents");
									System.out.println("contents6" + contents6);

									JSONArray completedIssues6 = (JSONArray) contents6.get("completedIssues");
									System.out.println("completedIssues6" + completedIssues6);

									for (int si = 0; si < completedIssues6.length(); si++) {
									}

									JSONObject completedIssuesEstimateSum6 = (JSONObject) contents6
											.get("completedIssuesEstimateSum");
									System.out.println("completedIssuesEstimateSum" + completedIssuesEstimateSum6);
									double cieslen6 = completedIssuesEstimateSum6.length();
									System.out.println("cieslen6 = " + cieslen6);

									if (cieslen6 <= 1) {

										System.out.println("No done Story are current in sprint");
										donevalue6 = 0;
										totalhrs6 = donevalue6 * 6;
										overalltotalhrs6 = totalDoneHours - totalhrs6;
										System.out.println("spent hrs" + totalhrs6);
										System.out.println("remaining hrs" + overalltotalhrs6);

										if (i == 0) {
											spenthrs6[i] = totalhrs6;
											remaininghrs6[i] = overalltotalhrs6;
										}

										else {
											spenthrs6[i] = totalhrs6 + spenthrs6[i - 1];
											remaininghrs6[i] = overalltotalhrs6;
										}

										System.out.println("spent hrs" + spenthrs6[i]);
										System.out.println("remaining hrs" + remaininghrs6[i]);
										set11.add(spenthrs6[i]);
										set16.add(remaininghrs6[i]);
										list11.add(spenthrs6[i]);
										list16.add(remaininghrs6[i]);
									} else {
										donevalue6 = (Double) completedIssuesEstimateSum6.get("value");

										totalhrs6 = donevalue6 * 6;
										overalltotalhrs6 = totalDoneHours - totalhrs6;

										System.out.println("spent hrs" + totalhrs6);
										System.out.println("remaining hrs" + overalltotalhrs6);

										if (i == 0) {
											spenthrs6[i] = totalhrs6;
											remaininghrs6[i] = overalltotalhrs6;
										}

										else {
											spenthrs6[i] = totalhrs6 + spenthrs6[i - 1];
											remaininghrs6[i] = overalltotalhrs6;
										}

										System.out.println("spent hrs" + spenthrs6[i]);
										System.out.println("remaining hrs" + remaininghrs6[i]);
										set11.add(spenthrs6[i]);
										set16.add(remaininghrs6[i]);
										list11.add(spenthrs6[i]);
										list16.add(remaininghrs6[i]);
									}

								}
							}
							if (i == 0) {
								spenthrs[i] = totalHours;
								remaininghrs[i] = overalltotalhrs;
							}

							else {
								spenthrs[i] = totalHours + spenthrs[i - 1];
								remaininghrs[i] = overalltotalhrs;
							}

							System.out.println("spent hrs" + spenthrs[i]);
							System.out.println("remaining hrs" + remaininghrs[i]);
							set.add(spenthrs[i]);
							set1.add(remaininghrs[i]);
							list.add(spenthrs[i]);
							list1.add(remaininghrs[i]);

						}

						else {
							doneValue = (Double) completedIssuesEstimateSum.get("value");

							totalHours = doneValue * 6;
							overalltotalhrs = totalDoneHours - totalHours;

							System.out.println("spent hrs" + totalHours);
							System.out.println("remaining hrs" + overalltotalhrs);

							if (i == 0) {
								spenthrs[i] = totalHours;
								remaininghrs[i] = overalltotalhrs;
							}

							else {
								spenthrs[i] = totalHours + spenthrs[i - 1];
								remaininghrs[i] = overalltotalhrs;
							}

							startDateSprint = (String) sprintValue.get("startDate");
							System.out.println("startdate = " + startDateSprint);
							endDatesprint = (String) sprintValue.get("endDate");
							System.out.println("enddate = " + endDatesprint);

							SimpleDateFormat formatter5 = new SimpleDateFormat("dd/MMM/yy");
							SimpleDateFormat formatterCustom5 = new SimpleDateFormat("MM/dd/yy"); // dd/MM
							Date startDate = formatter5.parse((String) sprintValue.get("startDate").toString());
							System.out.println(startDate);
							strDateSprint = formatterCustom5.format(startDate);
							System.out.println("strDateSprint" + strDateSprint);

							SimpleDateFormat formatter6 = new SimpleDateFormat("dd/MMM/yy");
							Date endDateSprint = formatter6.parse((String) sprintValue.get("endDate").toString());
							System.out.println(endDateSprint);
							endDateSprintFinal = formatterCustom5.format(endDateSprint);
							System.out.println("endDateSprint" + endDateSprintFinal);

							System.out.println("relstrdt1 :" + releaseStartDate);
							System.out.println("relenddate :" + releaseEndDate);

							System.out.println("startDate & End date" + startDate + "" + endDateSprint);
							System.out.println("relDate" + startDateFinal + "" + endDateFinal);

							if (startDateFinal != null && endDateFinal != null) {
								System.out.println(startDate.compareTo(startDateFinal) + "sd<d1");
								System.out.println(endDateSprint.compareTo(endDateFinal) + "ed<d2");
								if (startDateFinal.compareTo(startDate) <= 0
										&& endDateFinal.compareTo(endDateSprint) >= 0) {
									sprintId = (Integer) sprintValue.get("id");
									System.out.println("idval =" + sprintId);
									sprintName = (String) sprintValue.get("name");
									System.out.println("nameval =" + sprintName);
									spintIdArray[i] = sprintId;
									sprintNameArray[i] = sprintName;
									sprintIdFinal.add(spintIdArray[i]);
									System.out.println("nofinalval =" + sprintIdFinal);
									sprintNameFinal.add(sprintNameArray[i]);
									System.out.println("namefinalval =" + sprintNameFinal);

									sprintIdLength = spintIdArray.length;

									System.out.println("nofinalvallen" + sprintIdLength);
									idvalfinals[i] = sprintId;

									WebResource webResource6 = client
											.resource(APIConstants.ServerName + APIConstants.SprintReport + rapidViewId
													+ APIConstants.SprintID + sprintId + "");

									ClientResponse response6 = webResource6.header("Content-Type", "application/json")
											.header("Cookie", authStringEnc).get(ClientResponse.class);
									String respStr6 = response6.getEntity(String.class);
									System.out.println("Response6 " + response6);
									System.out.println("ResponseStr6 " + respStr6);
									JSONObject ob6;
									ob6 = new JSONObject(respStr6);

									JSONObject sprintval6 = (JSONObject) ob6.get("sprint");
									String nameval6 = (String) sprintval6.get("name");
									Integer idval6 = (Integer) sprintval6.get("id");

									System.out.println("nameval" + nameval6);
									System.out.println("idval" + idval6); // contents

									JSONObject contents6 = (JSONObject) ob6.get("contents");
									System.out.println("contents" + contents6);

									JSONArray completedIssues6 = (JSONArray) contents6.get("completedIssues");
									System.out.println("completedIssues" + completedIssues6);

									for (int si = 0; si < completedIssues6.length(); si++) {

										JSONObject value6 = (JSONObject) completedIssues6.get(si);
										if (value6.getString("statusName").equals("Done")
												&& (value6.getString("typeName").equals("Story"))) {

											String donekey6 = (String) value6.get("key");
											System.out.println("donekey = " + donekey6);
											donecount6 = donecount6 + 1;
											System.out.println("donevalue6 = " + donecount6);
											double[] donecountval6 = new double[si];
											donevallen6 = donecountval6.length;
											System.out.println("done value = " + donevallen6);

											double donelengthvalue6 = donevallen6 + 1;
											System.out.println("donelengthvalue6" + donelengthvalue6);

										}
										if (value6.getString("statusName").equals("Done")
												&& (value6.getString("typeName").equals("Story"))) {

											JSONObject currentEstimateStatistic = (JSONObject) value6
													.get("currentEstimateStatistic");

											JSONObject statFieldValue = (JSONObject) currentEstimateStatistic
													.get("statFieldValue");

											System.out.println("statFieldValue is:" + statFieldValue);

											valueval = (Double) statFieldValue.get("value");

											System.out.println("valueval :" + valueval);

											overallval += valueval;
											System.out.println("overallval is :" + overallval);

											totaldonevalhr = overallval * 6;
											System.out.println("totaldonevalhr is :" + totaldonevalhr);

											toverallval = overallval; // + noverallval
											ttotaldonevalhr = toverallval * 6;
											System.out.println("ttotaldonevalhr:" + ttotaldonevalhr);
											toverallvalarr[i] = ttotaldonevalhr;
											System.out.println("toverallvalarr" + toverallvalarr);

											String donekey6 = (String) value6.get("key");
											System.out.println("donekey = " + donekey6);
											donecount6 = donecount6 + 1;
											System.out.println("donevalue6 = " + donecount6);
											double[] donecountval6 = new double[si];
											donevallen6 = donecountval6.length;
											System.out.println("done value = " + donevallen6);
											double donelengthvalue6 = donevallen6 + 1;
											System.out.println("donelengthvalue6" + donelengthvalue6);
										}
										if ((value6.getString("typeName").equals("Story"))) {

											String Key = (String) value6.get("key");

											allstory.put(Key, false);
											System.out.println("allstory size:" + allstory.size());

											System.out.println("allstory" + allstory);

											JSONObject currentEstimateStatistic = (JSONObject) value6
													.get("currentEstimateStatistic");

											JSONObject statFieldValue = (JSONObject) currentEstimateStatistic
													.get("statFieldValue");

											if (statFieldValue.has("value"))
												svalueval = (Double) statFieldValue.get("value");

											soverallval += svalueval;

											System.out.println("soverallval is :" + soverallval);

											stotaldonevalhr = soverallval * 6;
											System.out.println("stotaldonevalhr is :" + stotaldonevalhr);

										}

										if (value6.getString("statusName").equals("Done")
												&& (value6.getString("typeName").equals("Story"))) {
											JSONObject currentEstimateStatistic = (JSONObject) value6
													.get("currentEstimateStatistic");

											JSONObject statFieldValue = (JSONObject) currentEstimateStatistic
													.get("statFieldValue");

											if (statFieldValue.has("value"))
												dsvalueval = (Double) statFieldValue.get("value");

											dsoverallval += dsvalueval;

											System.out.println("dsoverallval is :" + dsoverallval);

											dstotaldonevalhr = dsoverallval * 6;
											System.out.println("dstotaldonevalhr is :" + dstotaldonevalhr);
										}

									}

									issuesNotCompletedInCurrentSprint1 = (JSONArray) contents
											.get("issuesNotCompletedInCurrentSprint");

									int inclen = issuesNotCompletedInCurrentSprint1.length();

									System.out.println("inclen is: issuesNotCompletedInCurrentSprint1:" + inclen);

									if (inclen != 0) {

										for (int pi = 0; pi < issuesNotCompletedInCurrentSprint1.length(); pi++) {

											JSONObject value1 = (JSONObject) issuesNotCompletedInCurrentSprint1.get(pi);

											JSONObject currentEstimateStatistic1 = (JSONObject) value1
													.get("currentEstimateStatistic");

											JSONObject statFieldValue1 = (JSONObject) currentEstimateStatistic1
													.get("statFieldValue");

											String Key = (String) value1.get("key");

											allstory.put(Key, false);
											System.out.println("allstory size:" + allstory.size());

											System.out.println("allstory" + allstory);

											if ((value1.getString("typeName").equals("Story"))
													&& statFieldValue1.has("value"))
												snvalueval = (Double) statFieldValue1.get("value");

											snoverallval += snvalueval;

											System.out.println("snoverallval is:" + snoverallval);

											sntotaldonevalhr = snoverallval * 6;
											System.out.println("sntotaldonevalhr:" + sntotaldonevalhr);
										}
									}

									stoverallval = soverallval + snoverallval;
									sttotaldonevalhr = stoverallval * 6;
									System.out.println("sttotaldonevalhr:" + sttotaldonevalhr);

									stoverallvalarr[i] = sttotaldonevalhr;
									System.out.println("toverallvalarr" + stoverallvalarr);
									ts[i] = sttotaldonevalhr;
									tstoverallvalar[i] = sttotaldonevalhr;
									System.out.println("ts is:" + ts);
									totalstory.add(tstoverallvalar[i]);
									System.out.println("total story :" + totalstory);
									dstoverallvalarr[i] = dstotaldonevalhr;

									donestory.add(dstoverallvalarr[i]);
									System.out.println("donestory" + donestory);

									JSONObject completedIssuesEstimateSum6 = (JSONObject) contents6
											.get("completedIssuesEstimateSum");
									System.out.println("completedIssuesEstimateSum" + completedIssuesEstimateSum6);
									double cieslen6 = completedIssuesEstimateSum6.length();
									System.out.println("cieslen6 = " + cieslen6);

									if (cieslen6 <= 1) {

										System.out.println("No done Story are current in sprint");
										donevalue6 = 0;
										totalhrs6 = donevalue6 * 6;
										overalltotalhrs6 = totalDoneHours - totalhrs6;
										System.out.println("spent hrs" + totalhrs6);
										System.out.println("remaining hrs" + overalltotalhrs6);

										if (i == 0) {
											spenthrs6[i] = totalhrs6;
											remaininghrs6[i] = overalltotalhrs6;
										}

										else {
											spenthrs6[i] = totalhrs6 + spenthrs6[i - 1];
											remaininghrs6[i] = overalltotalhrs6;
										}

										System.out.println("spent hrs" + spenthrs6[i]);
										System.out.println("remaining hrs" + remaininghrs6[i]);
										set11.add(spenthrs6[i]);
										set16.add(remaininghrs6[i]);
										list11.add(spenthrs6[i]);
										list16.add(remaininghrs6[i]);
									} else {
										donevalue6 = (Double) completedIssuesEstimateSum6.get("value");

										totalhrs6 = donevalue6 * 6;
										overalltotalhrs6 = totalDoneHours - totalhrs6;

										System.out.println("spent hrs" + totalhrs6);
										System.out.println("remaining hrs" + overalltotalhrs6);

										if (i == 0) {
											spenthrs6[i] = totalhrs6;
											remaininghrs6[i] = overalltotalhrs6;
										}

										else {
											spenthrs6[i] = totalhrs6 + spenthrs6[i - 1];
											remaininghrs6[i] = overalltotalhrs6;
										}

										System.out.println("spent hrs" + spenthrs6[i]);
										System.out.println("remaining hrs" + remaininghrs6[i]);
										set11.add(spenthrs6[i]);
										set16.add(remaininghrs6[i]);
										list11.add(spenthrs6[i]);
										list16.add(remaininghrs6[i]);
									}

								}

							} // d1 and d2 null

							System.out.println("spent hrs" + spenthrs[i]);
							System.out.println("remaining hrs" + remaininghrs[i]);

							set.add(spenthrs[i]);
							set1.add(remaininghrs[i]);
							list.add(spenthrs[i]);
							list1.add(remaininghrs[i]);

						}

					}

					else if (key.equalsIgnoreCase("name")) {
						nameValue = (String) objSprints.get("name");
						System.out.println("\n nameValue>>" + nameValue);

						str[i] = nameValue;
						System.out.println("Sprint name" + str[i]);
						set3.add(str[i]);
						list2.add(str[i]);
						System.out.println("All Sprint name" + set3);
						System.out.println("All Sprint names" + list2);

					}

				}
			}

		}

		else {

			JSONObject finalResponse = new JSONObject();

			int empty = 0;
			finalResponse.put("No Sprint Started yet", empty);

			System.out.println("Output from Server .... \n" + finalResponse);
			client.destroy();
			return Response.status(200).entity(finalResponse.toString()).build();

		}
		for (int k = 0; k < count; k++) {// length is the property of array

			System.out.println("k=" + k);
			System.out.println("spenthrs=" + spenthrs[k]);
			System.out.println(spenthrs[k]);
			System.out.println("remaininghrs=" + remaininghrs[k]);

			set.add(spenthrs[k]);
			set1.add(remaininghrs[k]);
			list.add(spenthrs[k]);
			list1.add(remaininghrs[k]);
			for (int ri = 0; ri < count; ri++) {
			}

			System.out.println(set);
			System.out.println(set1);
			System.out.println("List = " + list);
			System.out.println("List1 = " + list1);

		}

		System.out.println("startdatefinal" + startDateFinal + "enddatefinal" + endDateFinal);
		if (totalstory != null && !totalstory.isEmpty()) {
			WebResource webResource12 = client.resource(APIConstants.ServerName + APIConstants.BacklogData + rapidViewId
					+ APIConstants.SelectedProjectKey + projectKey + "");
			ClientResponse response12 = webResource12.header("Content-Type", "application/json")
					.header("Cookie", authStringEnc).get(ClientResponse.class);

			String respStr12 = response12.getEntity(String.class);
			System.out.println("Response " + response12);
			System.out.println("ResponseStr " + respStr12);
			JSONObject ob12;
			ob12 = new JSONObject(respStr12);
			JSONArray issues12 = (JSONArray) ob12.get("issues");

			for (int i12 = 0; i12 < issues12.length(); i12++) {

				JSONObject value12 = (JSONObject) issues12.get(i12);

				if ((value12.getString("typeName").equals("Story"))) {

					String key = (String) value12.get("key");

					if (!allstory.containsKey(key)) {

						System.out.println("key is:" + key);

						JSONObject estimateStatistic12 = (JSONObject) value12.get("estimateStatistic");
						JSONObject statFieldValue12 = (JSONObject) estimateStatistic12.get("statFieldValue");
						if (statFieldValue12.has("value")) {
							bval = (Double) statFieldValue12.get("value");

							obval += bval;

							System.out.println("overallval is :" + obval);
						}
					}

				}

			}
			System.out.println("obval:" + obval);

			double abc = (totalstory.get(totalstory.size() - 1)) / 6;
			System.out.println("abc:" + abc);
			obval = obval + abc;
			totalHours = obval * 6;
			System.out.println("obval:" + obval);
			System.out.println("totalhrs:" + totalHours);
			JSONArray sprints12 = (JSONArray) ob12.get("sprints");

			for (int s12 = 0; s12 < sprints12.length(); s12++) {

				JSONObject svalue12 = (JSONObject) sprints12.get(s12);
				String sprintname = (String) svalue12.get("name");
				System.out.println("sprint name:" + sprintname);

				if (!sprintNameFinal.contains(sprintname)) {
					sprintNameFinal.add(sprintname);
					System.out.println("name val for planned story:" + sprintNameFinal);
				}

			}

		}
		double da2 = 0.0;
		if (totalstory != null && !totalstory.isEmpty()) {
			System.out.println("Last element is:");
			System.out.println(totalstory.get(totalstory.size() - 1));

			for (int i1 = 0; i1 < donestory.size(); i1++) {

				if (i1 == 0) {
					double z = 0.0;
					donestory.add(0, z);
					System.out.println("donestory is i==0 :" + donestory);
				}

				System.out.println("total story val is:" + donestory.get(i1));
				double da1 = donestory.get(i1);
				System.out.println("da1 is :" + da1);
				da2 = totalstory.get(totalstory.size() - 1) - da1;
				System.out.println("totalstory.size() is:" + totalstory.size());
				System.out.println("donestory.size() is:" + donestory.size());
				System.out.println("da2 is :" + da2);

				double da3 = totalHours - da1;
				totalremainingstoryhr.add(da3);

				totalremainingstory.add(da2);
				System.out.println("totalremainingstory val:" + totalremainingstory);

			}
		}

		if (startDateFinal != null && endDateFinal != null && val == true) {

			if (startDateFinal.compareTo(currentDay) <= 0 && endDateFinal.compareTo(currentDay) >= 0) {
				JSONObject finalResponse = new JSONObject();
				finalResponse.put("Date", startDateFormatCustom + "-" + endDateFormatCustom);
				finalResponse.put("Release", sequence);
				finalResponse.put("StartDate", startDateFormatCustom1); // strDate2
				finalResponse.put("Enddate", endDateFormatCustom1);

				finalResponse.put("donestory", donestory);
				finalResponse.put("totalremainingstoryhr", totalremainingstoryhr);

				finalResponse.put("All Sprint name", set3);
			} else {
				System.out.println("no release date is there");
			}

		} else {
			JSONObject finalResponse = new JSONObject();
			String a = "missing";
			System.out.println("no current release setup is:" + a);
			finalResponse.put("no current release setup", a);
			System.out.println("Output from Server .... \n" + finalResponse);
			client.destroy();
			return Response.status(200).entity(finalResponse.toString()).build();

		}

		JSONObject finalResponse = new JSONObject();

		if (val == true && releaseStartDate != null && releaseEndDate != null && releaseEndDate1 != null
				&& releaseStartDate1 != null) {

			finalResponse.put("Date", releaseStartDate + "-" + releaseEndDate);
			finalResponse.put("Release", sequence); // sequence
			finalResponse.put("StartDate", releaseStartDate1); // strDate2
			finalResponse.put("Enddate", releaseEndDate1); // strDate3
			if (sprintIdLength > 0) {

				finalResponse.put("donestory", donestory);
				finalResponse.put("totalremainingstoryhr", totalremainingstoryhr);

				finalResponse.put("name value", sprintNameFinal);
			} else {

				WebResource webResource16 = client.resource(APIConstants.ServerName + APIConstants.BacklogData
						+ rapidViewId + APIConstants.SelectedProjectKey + projectKey + "");
				ClientResponse response16 = webResource16.header("Content-Type", "application/json")
						.header("Cookie", authStringEnc).get(ClientResponse.class);

				String respStr16 = response16.getEntity(String.class);
				System.out.println("Response " + response16);
				System.out.println("ResponseStr " + respStr16);
				JSONObject ob16;
				ob16 = new JSONObject(respStr16);
				JSONArray issues16 = (JSONArray) ob16.get("issues");

				for (int i16 = 0; i16 < issues16.length(); i16++) {

					JSONObject value16 = (JSONObject) issues16.get(i16);

					if ((value16.getString("typeName").equals("Story"))) {

						String key = (String) value16.get("key");

						if (!allstory.containsKey(key)) {
							allstory = getDefaultMap(key, allstory);

							System.out.println("allstory is:" + allstory);

							System.out.println("key is:" + key);

							JSONObject estimateStatistic16 = (JSONObject) value16.get("estimateStatistic");
							JSONObject statFieldValue16 = (JSONObject) estimateStatistic16.get("statFieldValue");
							if (statFieldValue16.has("value")) {
								bval = (Double) statFieldValue16.get("value");

								obval += bval;

								System.out.println("overallval is :" + obval);
							}
						}
					}
				}

				System.out.println("obval:" + obval);
				totalHours = obval * 6;
				System.out.println("obval:" + obval);
				System.out.println("totalhrs:" + totalHours);

				double dsfr = 0;
				donestory.add(dsfr);
				totalremainingstoryhr.add(totalHours);

				JSONArray sprints16 = (JSONArray) ob16.get("sprints");

				for (int s16 = 0; s16 < sprints16.length(); s16++) {

					JSONObject svalue16 = (JSONObject) sprints16.get(s16);
					String sprintname = (String) svalue16.get("name");
					System.out.println("sprint name:" + sprintname);

					if (!sprintNameFinal.contains(sprintname)) {
						sprintNameFinal.add(sprintname);
						System.out.println("name val for planned story:" + sprintNameFinal);
					}

				}
				finalResponse.put("Date", releaseStartDate + "-" + releaseEndDate);
				finalResponse.put("Release", sequence); // sequence
				finalResponse.put("StartDate", releaseStartDate1); // strDate2 //strDate2
				finalResponse.put("Enddate", releaseEndDate1);
				finalResponse.put("name value", sprintNameFinal);
				finalResponse.put("donestory", donestory);
				finalResponse.put("totalremainingstoryhr", totalremainingstoryhr);
				System.out.println("Output from Server .... \n" + finalResponse);
				client.destroy();
				return Response.status(200).entity(finalResponse.toString()).build();
			}
		}

		else {

			int r1 = 0;
			finalResponse.put(APIConstants.NoReleaseDate, r1);
			System.out.println("Output from Server .... \n" + finalResponse);
			client.destroy();
			return Response.status(200).entity(finalResponse.toString()).build();
		}

		System.out.println("Output from Server .... \n" + finalResponse);
		client.destroy();
		return Response.status(200).entity(finalResponse.toString()).build();
	}

	private HashMap<String, Boolean> getDefaultMap(String key, HashMap<String, Boolean> allstory) {
		// TODO Auto-generated method stub
		return allstory;
	}

}
