package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/getupcomingrelesetablelic")

public class JIRAserviceIssuesUpcomingReleaseButtonLic {

	@GET
	@Path("/{projkey}")
	public Response getTotalStoryPointsIssues(@PathParam("projkey") String projkey, @Context HttpHeaders headers) {
		ArrayList<JSONObject> finalResponselist = new ArrayList<>();
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		Client client = Client.create();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.out.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		WebResource webResource = client

				.resource(APIConstants.ServerName + APIConstants.ProjectKey + projkey
						+ APIConstants.ReleaseAllVersions + timestamp.getTime());
		ClientResponse response = webResource.header("Content-Type", "application/json")
				.header("Cookie",authStringEnc).get(ClientResponse.class);
		String responseString = response.getEntity(String.class);
		JSONArray ob = new JSONArray(responseString);
		for (int i = 0; i < ob.length(); i++) {

			JSONObject row = (JSONObject) ob.get(i);
			String version = (String) row.get("name");
			String description = (String) row.get("description");

			JSONObject status = row.getJSONObject("status");
			JSONObject toDoField = status.getJSONObject("toDo");
			int todoCount = (int) toDoField.get("count");

			JSONObject inProgressField = status.getJSONObject("inProgress");
			int inProgresscount = (int) inProgressField.get("count");

			JSONObject completeField = status.getJSONObject("complete");
			int completeCount = (int) completeField.get("count");

			JSONObject startDate = row.getJSONObject("startDate");
			String startdate = (String) startDate.get("iso");

			JSONObject releaseDate = row.getJSONObject("releaseDate");
			String releasedate = (String) releaseDate.get("iso");

			JSONObject finalResponse = new JSONObject();
			finalResponse.put("version", version);
			finalResponse.put("todocount", todoCount);
			finalResponse.put("inProgresscount", inProgresscount);
			finalResponse.put("completecount", completeCount);
			finalResponse.put("startdate", startdate);
			finalResponse.put("releasedate", releasedate);
			finalResponse.put("description", description);

			finalResponselist.add(finalResponse);

		}

		return Response.status(200).entity(finalResponselist.toString()).header("Content-Type", "application/json")
				.build();

	}

}
