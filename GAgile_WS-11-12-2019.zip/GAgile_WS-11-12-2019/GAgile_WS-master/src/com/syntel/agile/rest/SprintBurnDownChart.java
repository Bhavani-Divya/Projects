package com.syntel.agile.rest;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimeZone;
import java.util.Collections;
import java.util.Comparator;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Path("/getSprintBurnDownChart")
public class SprintBurnDownChart {

	@GET
	@Path("/{BoardId}/{SprintId}")
	public Response getSprintBurnDownChartValues(@PathParam("BoardId") String rapidViewId,
			@PathParam("SprintId") String sprintID, @Context HttpHeaders headers) throws JSONException {
		org.json.JSONObject responseJson = new org.json.JSONObject();
		org.json.JSONArray respArray = new org.json.JSONArray();
		Map<String, String> credentialMap = new LinkedHashMap<String, String>();
		for (Entry<String, List<String>> entry : headers.getRequestHeaders().entrySet()) {
			System.out.println("Key" + entry.getKey());
			if (entry.getKey().equals("cookie")) {
				credentialMap.put("Cookie", entry.getValue().get(0));
			}
			for (String str : entry.getValue()) {
				System.out.println(str);
			}
		}

		String authStringEnc = credentialMap.get("Cookie");
		Client client = Client.create();
		System.out.println("Data Received: " + rapidViewId);
		System.out.println("Data Received: " + sprintID);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		System.out.println(timestamp.getTime());
		WebResource webResource = client.resource(APIConstants.ServerName + APIConstants.ScopeChangeBurndownChart + rapidViewId
				+ APIConstants.SprintID + sprintID + APIConstants.CustomField10200 + timestamp.getTime());
		ClientResponse response = webResource.header("Content-Type", "application/json").header("Cookie", authStringEnc)
				.get(ClientResponse.class);
		String respFromJira = response.getEntity(String.class);
		System.out.println("Response from Jira .... \n" + respFromJira);
		client.destroy();
		@SuppressWarnings("unused")
		String statc, new_value, old_value, added, not_done, changeKey, spr_changeskey, spr_stat_c, spr_newvalue,
				map_newvalue;
		Double remaining, float_oldValue, float_newValue, float_map_newvalue;
		ArrayList<String> dateTime_Stamp = new ArrayList<String>();
		float lastValueInRemainingValueMap = 0f;
		ArrayList<Float> maxval_arr;
		ArrayList<String> unsorted_dateTime_Stamp = new ArrayList<String>();
		ArrayList<String> xAxis = new ArrayList<String>();
		LinkedHashMap<String, ArrayList<Double>> remainingvalue_map = new LinkedHashMap<String, ArrayList<Double>>();
		LinkedHashMap<String, String> spr_change_values = new LinkedHashMap<String, String>();
		ArrayList<String> final_Xaxis_rep = new ArrayList<String>();
		ArrayList<String> final_Xaxis_rep2 = new ArrayList<String>();
		ArrayList<Double> remaining_final = new ArrayList<Double>();
		final ArrayList<String> labels = new ArrayList<String>();
		ArrayList<Date> inBetweenDate = new ArrayList<Date>();
		ArrayList<String> inBetweenDate_strArray = new ArrayList<String>();
		ArrayList<String> inBetweenDate_strArrayWithYear = new ArrayList<String>();
		String completiontime_resp = " ";
		int weeks = 0;
		float val_map = 0;
		Date complete_date;
		try {
			JSONObject mainObj = new JSONObject(respFromJira);
			DateFormat dateFormatter = new SimpleDateFormat("dd/MM");
			DateFormat dateFormattersamp = new SimpleDateFormat("dd/MM/yy");

			dateFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));

			String starttime_resp = mainObj.getString("startTime");
			if (mainObj.has("completeTime")) {
				completiontime_resp = mainObj.getString("completeTime");
				System.out.println("!!!!!!!!!!!!!!Complete Time");
				complete_date = new Date(Long.parseLong(completiontime_resp));
			} else {
				complete_date = new Date();

			}
			Date start_date = new Date(Long.parseLong(starttime_resp));

			String startdate_str = dateFormatter.format(start_date);

			String completedate_str = dateFormatter.format(complete_date);

			System.out.println("START TIME" + startdate_str + "COMPLETE TIME" + completedate_str);

			JSONObject changes = mainObj.getJSONObject("changes");
			if (changes != null) {
				@SuppressWarnings("rawtypes")
				Iterator x = changes.keys();
				JSONArray jsonArray = new JSONArray();

				while (x.hasNext()) {
					String timestamps = (String) x.next();
					jsonArray.put(changes.get(timestamps));
					Long long_timestamp = Long.parseLong(timestamps);
					Date monthobj = new Date(long_timestamp);
					DateFormat df = new SimpleDateFormat("dd/MM");
					df.setTimeZone(TimeZone.getTimeZone("GMT"));
					String date_month = df.format(monthobj);

					xAxis.add(date_month);

					Date dateObj = new Date(long_timestamp);
					DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
					String date_timestamp = df1.format(dateObj);
					unsorted_dateTime_Stamp.add(date_timestamp);
					dateTime_Stamp.add(date_timestamp);/* } */

					if (monthobj.after(start_date) && monthobj.before(complete_date)) {
						final_Xaxis_rep2.add(df.format(monthobj));
					}
				}

				Calendar cal3 = Calendar.getInstance();
				cal3.setTime(start_date);

				Calendar cal4 = Calendar.getInstance();
				cal4.setTime(complete_date);
				while (cal3.getTime().before(cal4.getTime())) {
					// add another week
					cal3.add(Calendar.WEEK_OF_YEAR, 1);
					weeks++;
				}

				Calendar cal1 = Calendar.getInstance();
				cal1.setTime(start_date);

				Calendar cal2 = Calendar.getInstance();
				cal2.setTime(complete_date);

				while (!cal1.after(cal2)) {
					inBetweenDate.add(cal1.getTime());
					String a = dateFormatter.format(cal1.getTime());
					inBetweenDate_strArray.add(a);
					cal1.add(Calendar.DATE, 1);

				}
				if (!inBetweenDate_strArray.contains(dateFormatter.format(cal2.getTime()))) {
					inBetweenDate_strArray.add(dateFormatter.format(cal2.getTime()));
					inBetweenDate_strArrayWithYear.add(dateFormattersamp.format(cal2.getTime()));
				}

				System.out.println("!!!!!!!!!#################InBetween DATES" + inBetweenDate_strArray);
				for (int n = 0; n < final_Xaxis_rep2.size();) {
					if (n == 0) {
						final_Xaxis_rep.add(final_Xaxis_rep2.get(n));
						n++;
					} else {
						if (final_Xaxis_rep.contains(final_Xaxis_rep2.get(n))) {
							n++;
						} else {
							final_Xaxis_rep.add(final_Xaxis_rep2.get(n));
						}
					}
				}

				System.out.println("!!!!!!!!!#################JSON ARRAY LENGTH" + jsonArray.length());
				String first_elem = jsonArray.get(0).toString();
				System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!FIRST ELEMNT" + first_elem);
				for (int k = 0; k < jsonArray.length(); k++) {
					JSONArray innerarray = jsonArray.getJSONArray(k);
					for (int j = 0; j < innerarray.length(); j++) {
						JSONObject innerobj = innerarray.getJSONObject(j);
						spr_changeskey = innerobj.getString("key");

						if (innerobj.has("statC")) {
							JSONObject innerobj2 = innerobj.getJSONObject("statC");
							if (innerobj2.has("newValue")) {
								spr_newvalue = innerobj2.getString("newValue");
								spr_change_values.put(spr_changeskey, spr_newvalue);
							}

						} else {

						}
					}

				}
				if (spr_change_values.isEmpty() == true) {
					System.out.println("No issues are estimated/completed");
					responseJson.put("warningMessage", "No issues are estimated/completed");
				} else {
					for (Map.Entry<String, String> map : spr_change_values.entrySet()) {
						System.out.println("........KEY VALUE PAIR MAP" + map.getKey() + " " + map.getValue());
					}
					Collections.sort(dateTime_Stamp, new Comparator<String>() {
						DateFormat f3 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

						@Override
						public int compare(String o1, String o2) {
							try {
								return f3.parse(o1).compareTo(f3.parse(o2));
							} catch (ParseException e) {
								throw new IllegalArgumentException(e);
							}
						}
					});
					Map<String, String> newMapForValuePair = new LinkedHashMap<>();
					Map<String, String> booleanKeyValuePair = new LinkedHashMap<>();
					Map<String, String> booleanKeyValuePairForAddded = new LinkedHashMap<>();
					remaining = 0.0;
					for (int change = 0; change < dateTime_Stamp.size(); change++) {
						String date = dateTime_Stamp.get(change);
						int date_index = unsorted_dateTime_Stamp.indexOf(date);
						JSONArray timestamp_array = jsonArray.getJSONArray(date_index);
						for (int h = 0; h < timestamp_array.length(); h++) {

							System.out.println("/////////////////EACH CHANGE VALUE/////////////************"
									+ timestamp_array.get(h));

							JSONObject timestamp_innerobj = timestamp_array.getJSONObject(h);
							changeKey = timestamp_innerobj.getString("key");
							if (timestamp_innerobj.has("statC")) {
								statc = timestamp_innerobj.getString("statC");
								JSONObject statc_obj = timestamp_innerobj.getJSONObject("statC");
								if (statc_obj.has("newValue")) {
									String newValueForNewMap = statc_obj.getString("newValue");
									newMapForValuePair.put(changeKey, newValueForNewMap);
								}

								if (statc_obj.has("oldValue") && statc_obj.has("newValue")) {
									old_value = statc_obj.getString("oldValue");

									float_oldValue = Double.parseDouble(old_value);

									new_value = statc_obj.getString("newValue");
									float_newValue = Double.parseDouble(new_value);

									if (!booleanKeyValuePair.containsKey(changeKey)) {
										remaining = remaining - float_oldValue + float_newValue;
										if (remainingvalue_map.containsKey(xAxis.get(change))) {
											remaining_final = remainingvalue_map.get(xAxis.get(change));
											remaining_final.add(remaining);
										} else {
											remaining_final = new ArrayList<Double>();
											remaining_final.add(remaining);
											remainingvalue_map.put(xAxis.get(change), remaining_final);
										}
										for (Map.Entry<String, ArrayList<Double>> entry : remainingvalue_map
												.entrySet()) {
											@SuppressWarnings("unused")
											String key = entry.getKey();
											for (@SuppressWarnings("unused")
											Double value : entry.getValue()) {
											}
										}
									}
								}
								if (statc_obj.has("oldValue") && !statc_obj.has("newValue")) {

									old_value = statc_obj.getString("oldValue");

									float_oldValue = Double.parseDouble(old_value);

									remaining = remaining - float_oldValue;

									if (newMapForValuePair.containsKey(changeKey)) {
										newMapForValuePair.put(changeKey, "0");
									}

									if (remainingvalue_map.containsKey(xAxis.get(change))) {
										remaining_final = remainingvalue_map.get(xAxis.get(change));
										remaining_final.add(remaining);
									} else {
										remaining_final = new ArrayList<Double>();
										remaining_final.add(remaining);
										remainingvalue_map.put(xAxis.get(change), remaining_final);
									}
									for (Map.Entry<String, ArrayList<Double>> entry : remainingvalue_map.entrySet()) {
										@SuppressWarnings("unused")
										String key = entry.getKey();
										for (@SuppressWarnings("unused")
										Double value : entry.getValue()) {
										}
									}

								}

								if (statc_obj.has("newValue") && !statc_obj.has("oldValue")) {
									new_value = statc_obj.getString("newValue");

									if (booleanKeyValuePairForAddded.containsKey(changeKey)) {
										if (!booleanKeyValuePair.containsKey(changeKey)) {
											float_newValue = Double.parseDouble(new_value);
											remaining = remaining + float_newValue;

											if (remainingvalue_map.containsKey(xAxis.get(change))) {
												remaining_final = remainingvalue_map.get(xAxis.get(change));
												remaining_final.add(remaining);
											} else {
												remaining_final = new ArrayList<Double>();
												remaining_final.add(remaining);
												remainingvalue_map.put(xAxis.get(change), remaining_final);
											}
											for (Map.Entry<String, ArrayList<Double>> entry : remainingvalue_map
													.entrySet()) {
												@SuppressWarnings("unused")
												String key = entry.getKey();
												for (@SuppressWarnings("unused")
												Double value : entry.getValue()) {
												}
											}
										}
									}
								}

							}
							if (timestamp_innerobj.has("column")) {

								not_done = timestamp_innerobj.getString("column");
								JSONObject column_obj = timestamp_innerobj.getJSONObject("column");
								if (column_obj.has("notDone")) {

									not_done = column_obj.getString("notDone");
									if (not_done.equals("false")) {

										booleanKeyValuePair.put(changeKey, "false");
										if (newMapForValuePair.containsKey(changeKey)) {
											System.out
													.println("INTOOOOOOOOOOOOOOOOOOO newMapForValuePair  " + changeKey);
											map_newvalue = newMapForValuePair.get(changeKey).toString();
											if (booleanKeyValuePairForAddded.containsKey(changeKey)) {
												float_map_newvalue = Double.parseDouble(map_newvalue);
												remaining = remaining - float_map_newvalue;

												if (remainingvalue_map.containsKey(xAxis.get(change))) {
													remaining_final = remainingvalue_map.get(xAxis.get(change));
													remaining_final.add(remaining);
												} else {
													remaining_final = new ArrayList<Double>();
													remaining_final.add(remaining);
													remainingvalue_map.put(xAxis.get(change), remaining_final);
												}
												for (Map.Entry<String, ArrayList<Double>> entry : remainingvalue_map
														.entrySet()) {
													@SuppressWarnings("unused")
													String key = entry.getKey();
													for (@SuppressWarnings("unused")
													Double value : entry.getValue()) {
													}
												}
											}
										}
									}

									if (not_done.equals("true")) {

										if (booleanKeyValuePair.containsKey(changeKey)) {

											booleanKeyValuePair.put(changeKey, "true");

											if (newMapForValuePair.containsKey(changeKey)) {
												System.out.println(
														"INTOOOOOOOOOOOOOOOOOOO newMapForValuePair  " + changeKey);
												map_newvalue = newMapForValuePair.get(changeKey).toString();

												float_map_newvalue = Double.parseDouble(map_newvalue);
												remaining = remaining + float_map_newvalue;

												if (remainingvalue_map.containsKey(xAxis.get(change))) {
													remaining_final = remainingvalue_map.get(xAxis.get(change));
													remaining_final.add(remaining);
												} else {
													remaining_final = new ArrayList<Double>();
													remaining_final.add(remaining);
													remainingvalue_map.put(xAxis.get(change), remaining_final);
												}
												for (Map.Entry<String, ArrayList<Double>> entry : remainingvalue_map
														.entrySet()) {
													@SuppressWarnings("unused")
													String key = entry.getKey();
													for (@SuppressWarnings("unused")
													Double value : entry.getValue()) {
													}
												}

											}
										}
									}

								}
							}
							if (timestamp_innerobj.has("added")) {
								added = timestamp_innerobj.getString("added");
								if (added.equals("true")) {

									booleanKeyValuePairForAddded.put(changeKey, added);

									if (newMapForValuePair.containsKey(changeKey)) {
										if (!booleanKeyValuePair.containsKey(changeKey)) {
											System.out
													.println("INTOOOOOOOOOOOOOOOOOOO newMapForValuePair  " + changeKey);
											map_newvalue = newMapForValuePair.get(changeKey).toString();
											float_map_newvalue = Double.parseDouble(map_newvalue);
											remaining = remaining + float_map_newvalue;
											if (remainingvalue_map.containsKey(xAxis.get(change))) {
												remaining_final = remainingvalue_map.get(xAxis.get(change));
												remaining_final.add(remaining);
											} else {
												remaining_final = new ArrayList<Double>();
												remaining_final.add(remaining);
												remainingvalue_map.put(xAxis.get(change), remaining_final);
											}
										}

									}
									map_newvalue = "0";

								}
								if (added.equals("false")) {

									if (newMapForValuePair.containsKey(changeKey)) {
										System.out.println("INTOOOOOOOOOOOOOOOOOOO newMapForValuePair  " + changeKey);
										map_newvalue = newMapForValuePair.get(changeKey).toString();
										float_map_newvalue = Double.parseDouble(map_newvalue);
										remaining = remaining - float_map_newvalue;

										if (remainingvalue_map.containsKey(xAxis.get(change))) {
											remaining_final = remainingvalue_map.get(xAxis.get(change));
											remaining_final.add(remaining);
										} else {
											remaining_final = new ArrayList<Double>();
											remaining_final.add(remaining);
											remainingvalue_map.put(xAxis.get(change), remaining_final);
										}

									}
									map_newvalue = "0";

								}
							}

						}
						System.out.println("-------------------------------remainingvalue_map--------------------------"
								+ remainingvalue_map);

						System.out.println("INTOOOOOOOOOOOOOOOOOOO newMapForValuePair  " + booleanKeyValuePair);
					}
				}

				if (!remainingvalue_map.isEmpty()) {

					ArrayList<DateValueObject> wr_group = new ArrayList<>();
					ArrayList<Integer> final_value;
					float max_val = 0;
					maxval_arr = new ArrayList<Float>();
					for (Map.Entry<String, ArrayList<Double>> entry : remainingvalue_map.entrySet()) {
						String key = entry.getKey();
						List<String> indexes = new ArrayList<String>(remainingvalue_map.keySet());
						System.out.println(".......................Index from hashmap................" + key
								+ "      Position   " + indexes.indexOf(key));

						System.out.println("Final map size" + remainingvalue_map.size());
						System.out.println("map key" + key);
						final_value = new ArrayList<>();

						if (inBetweenDate_strArray.contains(key)) {
							int pos, arraypos;
							ArrayList<Float> entryVal1 = new ArrayList<>();
							arraypos = inBetweenDate_strArray.indexOf(key);
							if (arraypos == 0) {
								max_val = Collections.max(entry.getValue()).floatValue();
								System.out.println(
										"LLLLLLLLLLLISTTTTTT OF MAP" + entry.getValue() + " max value" + max_val);
								for (Double d : entry.getValue()) {
									entryVal1.add(d.floatValue());
								}
								pos = entryVal1.indexOf(max_val);
								System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!poss" + pos + " entryval1 size()    "
										+ entryVal1.size());
								if (pos == entryVal1.size() - 1) {
									System.out.print("!!!!!!!!!!!!!!!!!!!!!!!!max val else block" + max_val);
									wr_group.add(new DateValueObject(max_val, 0));
									maxval_arr.add(max_val);
								} else {
									System.out.print("!!!!!!!!!!!!!!!!!!!!!!!!'into else ");
									for (int i = pos; i < entryVal1.size(); i++) {

										System.out.print(
												"!!!!!!!!!!!!!!!!!!!!!!!!'entry value---------- " + entryVal1.get(i));
										maxval_arr.add(max_val);
										wr_group.add(new DateValueObject(entryVal1.get(i), 0));
									}
								}
							} else {
								for (Double value : entry.getValue()) {
									val_map = value.floatValue();
									final_value.add((int) val_map);
									System.out.println(
											"@--------------------------------------key" + key + "\t" + val_map);
									int a = inBetweenDate_strArray.indexOf(key);
									System.out.println("_____________________Key position" + a);
									wr_group.add(new DateValueObject((int) val_map, a));
									System.out.println(
											"_____________________Adding" + (int) val_map + " at Key position" + a);
								}
								max_val = Collections.max(final_value);
								maxval_arr.add(max_val);
							}
						} else {
							System.out.println("into else blk of inbetween dates" + "key         " + key);
							max_val = Collections.max(entry.getValue()).floatValue();
							System.out.print("!!!!!!!!!!!!!!!!!!!!!!!!max val else block" + max_val);
							wr_group.add(new DateValueObject(max_val, 0));
							maxval_arr.add(max_val);// for ideal line
						}
						if (indexes.indexOf(key) == remainingvalue_map.size() - 1) {
							System.out.println("Last valueeeeeee" + remainingvalue_map.get(key));

							lastValueInRemainingValueMap = remainingvalue_map.get(key)
									.get(remainingvalue_map.get(key).size() - 1).floatValue();
						}
						/* } */
						System.out.println("________________________MAXVAL ARRAY_______________________" + maxval_arr);
					}

					System.out.println("===================max val array" + maxval_arr + "       max value from array"
							+ Collections.max(maxval_arr));
					for (int win = 0; win < inBetweenDate_strArray.size(); win++) {
						labels.add(win, inBetweenDate_strArray.get(win));
					}
					labels.add(inBetweenDate_strArray.size(), " ");
					labels.add(inBetweenDate_strArray.size() + 1, " ");

					System.out.println(
							"Max value" + max_val + "\t" + "InBetweenArraySize" + inBetweenDate_strArray.size());
					System.out.println("NO of Weeks...................................... " + weeks);
					Date currdate = new Date();
					String d = dateFormattersamp.format(currdate);
					if (inBetweenDate_strArray.contains(d)) {// extending the remline till date
						int poss = inBetweenDate_strArrayWithYear.indexOf(d);
						if (lastValueInRemainingValueMap > 0) {
							wr_group.add(new DateValueObject(lastValueInRemainingValueMap, poss));
						}
					} else {
						if (lastValueInRemainingValueMap > 0) {
							wr_group.add(new DateValueObject(lastValueInRemainingValueMap,
									inBetweenDate_strArray.size() - 1));
						}
					}
					@SuppressWarnings("unchecked")
					ArrayList<String>[] dateList = new ArrayList[labels.size() - 1];
					for (int i = 0; i < labels.size() - 2; i++) {
						dateList[i] = new ArrayList<String>();
					}

					for (int index = 0; index < wr_group.size(); index++) {
						dateList[(int) wr_group.get(index).getDate()]
								.add(String.valueOf(wr_group.get(index).getHours()));
					}

					for (int i = 0; i < labels.size() - 2; i++) {
						org.json.JSONObject jsonElem = new org.json.JSONObject();
						jsonElem.put("RemainingHours", dateList[i]);
						jsonElem.put("Date", labels.get(i));
						respArray.put(jsonElem);
					}

					responseJson.put("Values", respArray);
				} else {
					responseJson.put(APIConstants.WarningMessage, APIConstants.NoIssues);
				}
			}
		} catch (JSONException ae) {
			ae.printStackTrace();
			JSONObject mainObj = new JSONObject(respFromJira);
			if (mainObj.has(APIConstants.ErrorMessage)) {
				responseJson.put(APIConstants.ErrorMessage, mainObj.getString(APIConstants.ErrorMessage));
			}
			if (mainObj.has(APIConstants.WarningMessage)) {
				responseJson.put(APIConstants.WarningMessage, mainObj.getString(APIConstants.WarningMessage));
			}
		}

		return Response.status(200).entity(responseJson.toString()).build();
	}
}
